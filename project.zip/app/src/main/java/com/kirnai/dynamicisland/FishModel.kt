package com.kirnai.dynamicisland

import android.graphics.Color
import java.util.Random
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Logika mancing. Semua koordinat memakai "satuan web" (panel air 268 x 66,
 * permukaan air di y = 76, bawah pill di y = 42) supaya sama dengan versi artefak.
 */
class FishModel {

    class Kind(val name: String, val len: Float, val col: Int)
    class Swimmer(var x: Float, var y: Float, var dir: Int, var tier: Int, var spd: Float)
    class Ripple(val x: Float, val t0: Long)
    class Snap(var hx: Float, var hy: Float, var vy: Float, var fx: Float, var fy: Float, var fvx: Float, val tier: Int, var up: Float)
    class Drop(var x: Float, var y: Float, var vy: Float, val tier: Int)

    companion object {
        const val CAST = 0
        const val WAIT = 1
        const val BITE = 2
        const val REEL = 3
        const val SHOW = 4
        const val SNAP = 5
        const val LEVEL_MS = 25000L

        const val PX = 16f
        const val PY = 58f
        const val PW = 268f
        const val PH = 66f
        const val SURF = 76f
        const val PILL_BOTTOM = 42f

        val kinds = listOf(
            Kind("Teri", 4.5f, Color.rgb(190, 212, 228)),
            Kind("Nila", 7.5f, Color.rgb(140, 205, 150)),
            Kind("Kakap", 11f, Color.rgb(255, 125, 105)),
            Kind("Tuna", 15f, Color.rgb(95, 145, 235)),
            Kind("Hiu raksasa", 24f, Color.rgb(150, 166, 188))
        )
        private val weights = arrayOf(
            intArrayOf(70, 30, 0, 0, 0), intArrayOf(35, 40, 25, 0, 0), intArrayOf(10, 30, 40, 20, 0),
            intArrayOf(0, 15, 35, 35, 15), intArrayOf(0, 0, 20, 40, 40)
        )
    }

    private val rnd = Random()

    var active = false
    var vis = 0f
    var state = CAST
    var sT0 = 0L
    var level = 0
    var tier = 0
    var tension = 0f
    var hookX = 200f
    var hookY = 42f
    var lost = 0
    val caught = IntArray(5)
    val swimmers = ArrayList<Swimmer>()
    val ripples = ArrayList<Ripple>()
    var snap: Snap? = null
    var drop: Drop? = null
    var targetX = 0f
    var targetY = 0f
    var targetDir = 1

    private var levelAt = 0L
    private var willSnap = false
    private var snapP = 0.5f
    private var biteAt = 3f
    private var reelD = 3f
    private var hx = 200f
    private var tickAt = 0L
    private var creakAt = 0L
    private var targetSx = 0f
    private var crossed = false

    private fun pickTier(): Int {
        val wt = weights[level.coerceIn(0, 4)]
        var r = rnd.nextInt(wt.sum())
        for (i in wt.indices) {
            r -= wt[i]
            if (r < 0) return i
        }
        return 0
    }

    private fun newSwimmer(anywhere: Boolean): Swimmer {
        val dir = if (rnd.nextBoolean()) 1 else -1
        val tr = min(level, rnd.nextInt(level + 1))
        val x = if (anywhere) PX + 10f + rnd.nextFloat() * (PW - 20f) else if (dir > 0) PX - 30f else PX + PW + 30f
        val y = SURF + 12f + rnd.nextFloat() * (PY + PH - SURF - 24f)
        return Swimmer(x, y, dir, tr, 8f + rnd.nextFloat() * 14f)
    }

    private fun ripple(x: Float, now: Long) {
        ripples.add(Ripple(x, now))
        if (ripples.size > 6) ripples.removeAt(0)
    }

    private fun beginCast(now: Long) {
        state = CAST
        sT0 = now
        tier = pickTier()
        hx = 140f + rnd.nextInt(110)
        willSnap = tier == 4 || (tier == 3 && rnd.nextFloat() < 0.4f)
        snapP = if (tier == 4) 0.45f + rnd.nextFloat() * 0.15f else 0.55f + rnd.nextFloat() * 0.2f
        biteAt = 2.2f + rnd.nextFloat() * 3f
        tension = 0f
        crossed = false
        Sfx.cast()
    }

    fun start(now: Long) {
        active = true
        level = 0
        levelAt = now + LEVEL_MS
        for (i in caught.indices) caught[i] = 0
        lost = 0
        drop = null
        snap = null
        ripples.clear()
        swimmers.clear()
        for (i in 0 until 4) swimmers.add(newSwimmer(true))
        beginCast(now)
    }

    fun stop() {
        active = false
    }

    fun levelUp(now: Long) {
        if (!active) return
        level = min(4, level + 1)
        levelAt = now + LEVEL_MS
        Sfx.levelUp()
    }

    /** ax, ay = titik tali keluar dari pill (satuan web). */
    fun update(now: Long, dt: Float, ax: Float, ay: Float) {
        vis = (vis + (if (active) 1f else -1f) * dt * 3f).coerceIn(0f, 1f)
        ripples.removeAll { now - it.t0 > 1400L }
        val d = drop
        if (d != null) {
            d.vy += 240f * dt
            d.y += d.vy * dt
            if (d.y >= SURF) {
                ripple(d.x, now)
                Sfx.splash()
                drop = null
            }
        }
        if (!active) return
        for (i in swimmers.indices) {
            val s = swimmers[i]
            s.x += s.dir * s.spd * dt
            if (s.x < PX - 40f || s.x > PX + PW + 40f) swimmers[i] = newSwimmer(false)
        }
        if (level < 4 && now >= levelAt) {
            level++
            levelAt = now + LEVEL_MS
            Sfx.levelUp()
        }
        val t = (now - sT0) / 1000f
        val depth = SURF + 14f
        when (state) {
            CAST -> {
                val p = (t / 1.1f).coerceIn(0f, 1f)
                hookX = ax + (hx - ax) * p
                hookY = ay + (depth - ay) * p - sin(p * PI.toFloat()) * 14f
                if (p >= 1f) {
                    state = WAIT
                    sT0 = now
                    ripple(hookX, now)
                    Sfx.splash()
                    targetSx = if (hx < 150f) PX + PW + 20f else PX - 20f
                    targetDir = if (hx < 150f) -1 else 1
                    targetX = targetSx
                    targetY = depth + 4f
                }
            }
            WAIT -> {
                hookX = hx
                hookY = depth + sin(t * 2f) * 1.2f
                val p = (t / biteAt).coerceIn(0f, 1f)
                val goal = hookX - targetDir * kinds[tier].len
                val e = 1f - (1f - p) * (1f - p)
                targetX = targetSx + (goal - targetSx) * e
                if (t >= biteAt) {
                    state = BITE
                    sT0 = now
                    Sfx.bite()
                    ripple(hookX, now)
                }
            }
            BITE -> {
                hookX = hx + sin(t * 50f) * 1.2f
                hookY = depth + 5f + sin(t * 24f) * 2.5f
                if (t >= 0.7f) {
                    state = REEL
                    sT0 = now
                    reelD = 2.6f + 0.45f * tier
                    tickAt = now
                    creakAt = now
                }
            }
            REEL -> {
                val p = (t / reelD).coerceIn(0f, 1f)
                val e = p * p * (3f - 2f * p)
                val fl = kinds[tier].len
                hookX = hx + ((ax - 8f) - hx) * e + sin(t * 13f) * (0.6f + tier * 0.5f)
                hookY = (depth + 5f) + (46f - (depth + 5f)) * e
                tension = (0.2f + 0.55f * p + tier * 0.04f + sin(t * 9f) * 0.1f).coerceIn(0f, 1f)
                if (!crossed && hookY + fl * 1.4f < SURF) {
                    crossed = true
                    ripple(hookX, now)
                    Sfx.splash()
                }
                if (now >= tickAt) {
                    Sfx.tick()
                    tickAt = now + 190L
                }
                if (tension > 0.62f && now >= creakAt) {
                    Sfx.creak(tension)
                    creakAt = now + 380L
                }
                if (willSnap && p >= snapP) {
                    state = SNAP
                    sT0 = now
                    tension = 1f
                    lost++
                    Sfx.snap()
                    val dir = if (rnd.nextBoolean()) -1f else 1f
                    snap = Snap(hookX, hookY, -40f, hookX, hookY + fl * 1.1f, dir * (40f + tier * 6f), tier, hookY)
                } else if (p >= 1f) {
                    state = SHOW
                    sT0 = now
                    caught[tier]++
                    Sfx.catchFish(tier)
                }
            }
            SHOW -> {
                hookX = ax - 8f + sin(t * 3f) * 1.5f
                hookY = 46f
                if (t >= 2.3f) {
                    drop = Drop(hookX, hookY + kinds[tier].len * 1.2f, 0f, tier)
                    beginCast(now)
                }
            }
            SNAP -> {
                val s = snap
                if (s != null) {
                    s.vy += 260f * dt
                    s.hy += s.vy * dt
                    s.up = max(ay + 2f, s.up - 70f * dt)
                    s.fy += 12f * dt
                    s.fx += s.fvx * dt
                }
                if (t >= 2.4f) {
                    snap = null
                    beginCast(now)
                }
            }
        }
    }
}
