package com.kirnai.dynamicisland

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.sin

/**
 * Soket di tepi atas layar dengan kabel dan colokan yang berayun.
 * Jendela ini dipasang SEBELUM pill supaya pill menutupi ujung colokan.
 * Tidak bisa disentuh.
 */
class PlugOverlay(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = ctx.resources.displayMetrics.density
    private val view = PlugView(ctx)
    private var attached = false

    private fun dp(v: Float): Float = v * density

    /** Pusat kepala colokan (px, relatif ke tengah layar dan tepi atas) saat menggantung bebas. */
    val pivotY: Float get() = -dp(3f)
    val cableLen: Float get() = dp(19f)

    fun show() {
        if (attached) return
        val lp = WindowManager.LayoutParams(
            dp(90f).toInt(), dp(64f).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(view, lp)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    fun hide() {
        if (!attached) return
        try {
            wm.removeView(view)
        } catch (e: Exception) {
        }
        attached = false
    }

    fun setVisible(v: Boolean) {
        view.visibility = if (v) View.VISIBLE else View.INVISIBLE
    }

    /** hx, hy = pusat kepala (px dari tengah layar / dari atas). */
    fun update(th: Float, k: Float, hx: Float, hy: Float, charging: Boolean, docked: Boolean, flash: Float) {
        view.th = th
        view.k = k
        view.hx = hx
        view.hy = hy
        view.charging = charging
        view.docked = docked
        view.flash = flash
        view.invalidate()
    }

    private inner class PlugView(c: Context) : View(c) {
        var th = 0f
        var k = 1f
        var hx = 0f
        var hy = 0f
        var charging = false
        var docked = true
        var flash = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()
        private val path = Path()

        override fun onDraw(c: Canvas) {
            val cx = width / 2f
            val now = SystemClock.uptimeMillis()
            // soket
            p.style = Paint.Style.FILL
            p.color = Color.rgb(16, 22, 31)
            r.set(cx - dp(10f), -dp(6f), cx + dp(10f), dp(3.2f))
            c.drawRoundRect(r, dp(2.2f), dp(2.2f), p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = dp(0.5f)
            p.color = Color.rgb(43, 57, 72)
            c.drawRoundRect(r, dp(2.2f), dp(2.2f), p)
            p.style = Paint.Style.FILL
            p.color = Color.rgb(5, 8, 12)
            r.set(cx - dp(4.2f), dp(1.4f), cx - dp(1.8f), dp(2.5f))
            c.drawRoundRect(r, dp(0.5f), dp(0.5f), p)
            r.set(cx + dp(1.8f), dp(1.4f), cx + dp(4.2f), dp(2.5f))
            c.drawRoundRect(r, dp(0.5f), dp(0.5f), p)
            // led
            p.color = if (docked) {
                if (charging) Color.argb((255 * (0.55f + 0.45f * sin(now / 260f))).toInt().coerceIn(0, 255), 80, 230, 255)
                else Color.rgb(61, 255, 139)
            } else Color.argb(130, 255, 82, 82)
            c.drawCircle(cx + dp(7f), dp(1.4f), dp(0.9f), p)

            val px = cx + hx
            // kabel
            if (k < 0.97f) {
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = dp(1.4f)
                p.color = Color.rgb(26, 35, 46)
                path.reset()
                path.moveTo(cx, dp(2f))
                path.quadTo(cx + hx * 0.2f, (dp(2f) + hy) / 2f + dp(1f), px, hy - dp(2.5f))
                c.drawPath(path, p)
                p.strokeWidth = dp(0.45f)
                p.color = Color.argb(90, 160, 185, 210)
                c.drawPath(path, p)
            }
            // kepala colokan
            c.save()
            c.translate(px, hy)
            c.rotate(Math.toDegrees((th * (1f - k)).toDouble()).toFloat())
            p.style = Paint.Style.FILL
            p.color = Color.rgb(197, 208, 220)
            r.set(-dp(3.8f), -dp(4.4f), dp(3.8f), dp(-0.6f))
            c.drawRoundRect(r, dp(1.2f), dp(1.2f), p)
            p.color = Color.rgb(126, 141, 157)
            r.set(-dp(3.8f), -dp(1.8f), dp(3.8f), dp(-0.6f))
            c.drawRect(r, p)
            p.color = Color.rgb(232, 238, 245)
            c.drawRect(-dp(2.3f), dp(-0.6f), -dp(1.2f), dp(2.8f), p)
            c.drawRect(dp(1.2f), dp(-0.6f), dp(2.3f), dp(2.8f), p)
            c.restore()
            if (flash > 0.02f) {
                p.color = Color.argb((200 * flash).toInt().coerceIn(0, 255), 255, 232, 140)
                c.drawCircle(cx, dp(3f), dp(7f) * (1.2f - flash * 0.4f), p)
            }
        }
    }
}
