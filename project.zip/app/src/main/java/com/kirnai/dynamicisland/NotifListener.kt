package com.kirnai.dynamicisland

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Hanya menghitung jumlah notifikasi yang masuk (untuk membuat robot pusing).
 * Isi notifikasi tidak dibaca dan tidak disimpan.
 */
class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (sbn.packageName == packageName || sbn.isOngoing) return
        IslandAccessibility.instance?.onNotification()
    }
}
