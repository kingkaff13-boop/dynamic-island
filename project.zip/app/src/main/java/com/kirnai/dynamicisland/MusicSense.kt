package com.kirnai.dynamicisland

import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Mendengarkan campuran audio HP (musik, video) lewat Visualizer, lalu menebak suasananya.
 * Hasilnya perkiraan. Tidak merekam atau menyimpan suara; hanya menghitung kerasnya.
 * Butuh izin Rekam audio.
 */
class MusicSense(
    private val onMood: (Int) -> Unit,   // 0 = diam, 1 = semangat, 2 = sedih, 3 = aneh, 4 = santai
    private val onBeat: () -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private var vis: Visualizer? = null
    private var rateHz = 20f
    private val n = 200
    private val env = FloatArray(n)
    private var head = 0
    private var filled = 0
    private var lastBeat = 0L
    private var meanOnset = 0.0001f
    private var mood = 0
    private var pending = 0
    private var pendingCount = 0
    private var running = false

    private val analyze = object : Runnable {
        override fun run() {
            if (!running) return
            runAnalysis()
            h.postDelayed(this, 1000L)
        }
    }

    fun start(): Boolean {
        if (running) return true
        return try {
            val v = Visualizer(0)
            v.enabled = false
            v.captureSize = Visualizer.getCaptureSizeRange()[0]
            val rate = Visualizer.getMaxCaptureRate() / 2
            rateHz = rate / 1000f
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vz: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                    if (waveform == null) return
                    var sum = 0f
                    for (b in waveform) {
                        val x = ((b.toInt() and 0xFF) - 128) / 128f
                        sum += x * x
                    }
                    val rms = sqrt(sum / waveform.size)
                    h.post { push(rms) }
                }

                override fun onFftDataCapture(vz: Visualizer?, fft: ByteArray?, samplingRate: Int) {}
            }, rate, true, false)
            v.enabled = true
            vis = v
            running = true
            head = 0
            filled = 0
            h.postDelayed(analyze, 1000L)
            true
        } catch (e: Exception) {
            vis = null
            false
        }
    }

    fun stop() {
        running = false
        h.removeCallbacks(analyze)
        try {
            vis?.enabled = false
            vis?.release()
        } catch (e: Exception) {
        }
        vis = null
        mood = 0
        pending = 0
        pendingCount = 0
    }

    private fun push(rms: Float) {
        if (!running) return
        val prev = env[(head + n - 1) % n]
        env[head] = rms
        head = (head + 1) % n
        if (filled < n) filled++
        val onset = max(0f, rms - prev)
        meanOnset = meanOnset * 0.98f + onset * 0.02f
        val now = System.currentTimeMillis()
        if (rms > 0.02f && onset > meanOnset * 2.2f + 0.01f && now - lastBeat > 280L) {
            lastBeat = now
            onBeat()
        }
    }

    private var winLen = 0

    private fun at(i: Int): Float = env[(head - winLen + i + n * 2) % n]

    private fun runAnalysis() {
        if (filled < (rateHz * 4f).toInt()) return
        val len = min(filled, (rateHz * 6f).toInt())
        winLen = len
        // kalau 1,5 detik terakhir hampir sunyi, musik dianggap berhenti
        var tail = 0f
        val tl = max(1, (rateHz * 1.5f).toInt())
        for (i in len - tl until len) tail += at(i)
        tail /= tl
        var mean = 0f
        for (i in 0 until len) mean += at(i)
        mean /= len
        var found = 0
        if (mean >= 0.015f && tail >= 0.01f) {
            // onset
            val o = FloatArray(len)
            for (i in 1 until len) o[i] = max(0f, at(i) - at(i - 1))
            var e0 = 0f
            for (i in 0 until len) e0 += o[i] * o[i]
            val minLag = max(2, (rateHz * 0.3f).toInt())
            val maxLag = (rateHz * 1.3f).toInt().coerceAtMost(len / 2)
            val r = FloatArray(maxLag + 1)
            var best = 0f
            var bestLag = 0
            if (e0 > 1e-8f) {
                for (lag in minLag..maxLag) {
                    var s = 0f
                    for (i in lag until len) s += o[i] * o[i - lag]
                    r[lag] = s / e0
                    if (r[lag] > best) {
                        best = r[lag]
                        bestLag = lag
                    }
                }
                // ambil puncak terpendek yang kuat (hindari tempo setengahnya)
                for (lag in minLag + 1 until maxLag) {
                    if (r[lag] >= best * 0.8f && r[lag] >= r[lag - 1] && r[lag] >= r[lag + 1]) {
                        bestLag = lag
                        break
                    }
                }
            }
            var act = 0f
            var pauses = 0
            for (i in 0 until len) {
                act += abs(at(i) - mean)
                if (at(i) < mean * 0.25f) pauses++
            }
            act /= len
            val pauseRatio = pauses.toFloat() / len
            val bpm = if (bestLag > 0) 60f * rateHz / bestLag else 0f
            // Musik: irama teratur dan hampir tanpa jeda. Orang bicara (berita, video obrolan)
            // punya banyak jeda dan tidak punya irama tetap, jadi diabaikan.
            found = if (pauseRatio <= 0.08f && bpm in 60f..190f && best >= 0.38f) {
                if (bpm >= 105f) 1 else if (bpm < 80f) 2 else 4
            } else if (pauseRatio <= 0.04f && best in 0.24f..0.38f && act > 0.04f) 3 else 0
        }
        // masuk butuh 3 hasil sama berturut-turut, keluar (tidak ada musik) cukup 2
        if (found == pending) pendingCount++ else { pending = found; pendingCount = 1 }
        val need = if (pending == 0) 2 else 3
        if (pendingCount >= need && pending != mood) {
            mood = pending
            onMood(mood)
        }
    }
}
