package com.kirnai.dynamicisland

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Layanan ini hanya dipakai untuk mendapatkan "jendela" yang bisa digambar
 * di atas status bar. Tidak membaca atau mengontrol isi layar.
 */
class IslandAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: IslandAccessibility? = null
    }

    private var overlay: RobotOverlay? = null
    private var brain: RobotBrain? = null
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        stopRobot()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopRobot()
        instance = null
        super.onDestroy()
    }

    /** Dipanggil saat pengaturan berubah. */
    fun refresh() {
        if (instance == null) return
        if (!prefs.getBoolean(KEY_ENABLED, true)) {
            stopRobot()
            return
        }
        if (overlay == null) startRobot() else overlay?.applySettings()
    }

    fun play(a: Act) {
        brain?.play(a, null, true)
    }

    private fun startRobot() {
        val o = RobotOverlay(this, { brain?.onTap() }, { brain?.onLongPress() })
        overlay = o
        o.show()
        val b = RobotBrain(this, o)
        brain = b
        b.start()
    }

    private fun stopRobot() {
        brain?.stop()
        brain = null
        overlay?.hide()
        overlay = null
    }
}
