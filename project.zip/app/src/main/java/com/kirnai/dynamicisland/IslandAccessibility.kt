package com.kirnai.dynamicisland

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Layanan ini hanya menyediakan "jendela" overlay yang bisa digambar
 * di atas status bar. Tidak membaca atau mengontrol isi layar.
 */
class IslandAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: IslandAccessibility? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        IslandListener.instance?.refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        IslandListener.instance?.refresh()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
