package com.kirnai.dynamicisland

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/** Jadwal sholat offline (metode Kemenag, perkiraan). Hasil dalam menit sejak 00:00 waktu setempat. */
object Prayer {

    class City(val name: String, val lat: Double, val lng: Double, val tz: Int)

    val cities = listOf(
        City("Jakarta", -6.2088, 106.8456, 7), City("Bandung", -6.9175, 107.6191, 7),
        City("Surabaya", -7.2575, 112.7521, 7), City("Yogyakarta", -7.7956, 110.3695, 7),
        City("Semarang", -6.9667, 110.4167, 7), City("Medan", 3.5952, 98.6722, 7),
        City("Banda Aceh", 5.5483, 95.3238, 7), City("Padang", -0.9471, 100.4172, 7),
        City("Pekanbaru", 0.5071, 101.4478, 7), City("Batam", 1.0456, 104.0305, 7),
        City("Palembang", -2.9761, 104.7754, 7), City("Pontianak", -0.0263, 109.3425, 7),
        City("Banjarmasin", -3.3186, 114.5944, 8), City("Balikpapan", -1.2379, 116.8529, 8),
        City("Makassar", -5.1477, 119.4327, 8), City("Manado", 1.4748, 124.8421, 8),
        City("Denpasar", -8.6705, 115.2126, 8), City("Mataram", -8.5833, 116.1167, 8),
        City("Kupang", -10.1772, 123.607, 8), City("Ambon", -3.6954, 128.1814, 9),
        City("Jayapura", -2.5337, 140.7181, 9)
    )

    val names = listOf("Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya")

    private const val RAD = PI / 180.0
    private fun sinD(a: Double) = sin(a * RAD)
    private fun cosD(a: Double) = cos(a * RAD)
    private fun tanD(a: Double) = tan(a * RAD)
    private fun acosD(x: Double) = acos(x.coerceIn(-1.0, 1.0)) / RAD
    private fun acotD(x: Double) = atan(1.0 / x) / RAD
    private fun fixA(a: Double) = a - 360.0 * floor(a / 360.0)
    private fun fixH(a: Double) = a - 24.0 * floor(a / 24.0)

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0
        var m = m0
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    /** Mengembalikan 5 waktu: Subuh, Dzuhur, Ashar, Maghrib, Isya (menit sejak tengah malam). */
    fun times(y: Int, m: Int, d: Int, city: City): DoubleArray {
        val lat = city.lat
        val lng = city.lng
        val jd = julian(y, m, d) - lng / (15.0 * 24.0)

        fun decl(j: Double): Double {
            val dd = j - 2451545.0
            val g = fixA(357.529 + 0.98560028 * dd)
            val q = fixA(280.459 + 0.98564736 * dd)
            val l = fixA(q + 1.915 * sinD(g) + 0.020 * sinD(2 * g))
            val e = 23.439 - 0.00000036 * dd
            return asin(sinD(e) * sinD(l)) / RAD
        }

        fun eqt(j: Double): Double {
            val dd = j - 2451545.0
            val g = fixA(357.529 + 0.98560028 * dd)
            val q = fixA(280.459 + 0.98564736 * dd)
            val l = fixA(q + 1.915 * sinD(g) + 0.020 * sinD(2 * g))
            val e = 23.439 - 0.00000036 * dd
            val ra = fixH(atan2(cosD(e) * sinD(l), cosD(l)) / RAD / 15.0)
            return q / 15.0 - ra
        }

        fun midDay(t: Double) = fixH(12.0 - eqt(jd + t))
        fun angTime(ang: Double, t: Double, ccw: Boolean): Double {
            val dc = decl(jd + t)
            val tt = acosD((-sinD(ang) - sinD(dc) * sinD(lat)) / (cosD(dc) * cosD(lat))) / 15.0
            return midDay(t) + (if (ccw) -tt else tt)
        }

        fun asrTime(t: Double): Double {
            val dc = decl(jd + t)
            return angTime(-acotD(1.0 + tanD(abs(lat - dc))), t, false)
        }

        var fajr = 5.0
        var sunrise = 6.0
        var dhuhr = 12.0
        var asr = 13.0
        var sunset = 18.0
        var isha = 18.0
        repeat(2) {
            val pf = fajr / 24.0
            val ps = sunrise / 24.0
            val pd = dhuhr / 24.0
            val pa = asr / 24.0
            val pu = sunset / 24.0
            val pi2 = isha / 24.0
            fajr = angTime(20.0, pf, true)
            sunrise = angTime(0.833, ps, true)
            dhuhr = midDay(pd)
            asr = asrTime(pa)
            sunset = angTime(0.833, pu, false)
            isha = angTime(18.0, pi2, false)
        }
        val adj = city.tz - lng / 15.0
        val ih = 2.0 / 60.0
        return doubleArrayOf(
            (fajr + adj + ih) * 60.0,
            (dhuhr + adj + ih) * 60.0,
            (asr + adj + ih) * 60.0,
            (sunset + adj + ih) * 60.0,
            (isha + adj + ih) * 60.0
        )
    }
}
