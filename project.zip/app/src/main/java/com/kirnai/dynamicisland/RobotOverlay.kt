package com.kirnai.dynamicisland

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.max
import kotlin.math.min

/**
 * Jendela overlay (di atas status bar) yang memuat RobotView.
 * Semua fungsi harus dipanggil dari main thread.
 */
class RobotOverlay(
    private val ctx: Context,
    private val tapCb: () -> Unit,
    private val longCb: () -> Unit
) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val density = ctx.resources.displayMetrics.density
    private val view = RobotView(ctx)

    private var params: WindowManager.LayoutParams? = null
    private var attached = false
    private var fraction = 0f
    private var animator: ValueAnimator? = null
    private var fishing = false

    private fun dp(v: Int): Int = (v * density).toInt()
    private fun idleW(): Int = dp(prefs.getInt(KEY_W, 115))
    private fun idleH(): Int = dp(prefs.getInt(KEY_H, 32))
    private fun screenW(): Int = ctx.resources.displayMetrics.widthPixels
    private fun expW(): Int = max(idleW(), min(screenW() - dp(24), dp(300)))
    private fun touchOn(): Boolean = prefs.getBoolean(KEY_TOUCH, true)

    private fun flags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchOn() || fishing) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private val detector = GestureDetector(
        ctx,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                tapCb()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                longCb()
            }
        }
    )

    init {
        view.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            true
        }
    }

    fun show() {
        if (attached) {
            applySettings()
            return
        }
        val lp = WindowManager.LayoutParams(
            idleW(),
            idleH(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags(),
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(prefs.getInt(KEY_TOP, 4))
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        params = lp
        fraction = 0f
        view.baseH = idleH().toFloat()
        applyStyle()
        try {
            wm.addView(view, lp)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    fun hide() {
        animator?.cancel()
        if (attached) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
            }
            attached = false
        }
        fraction = 0f
    }

    /** Dipanggil setelah pengaturan (posisi, ukuran, sentuh) berubah. */
    fun applySettings() {
        val lp = params ?: return
        if (!attached) return
        lp.flags = flags()
        lp.y = dp(prefs.getInt(KEY_TOP, 4))
        view.baseH = idleH().toFloat()
        applyStyle()
        applyFraction(fraction)
        view.invalidate()
    }

    fun setAct(a: Act, badge: String?) {
        view.setAct(a, badge)
        animateTo(a.wide)
    }

    fun blink() = view.blink()

    /** Membaca gaya robot (warna, bentuk mata, nama) dari pengaturan. */
    fun applyStyle() {
        view.colorIdx = prefs.getInt(KEY_COLOR, 0)
        view.shapeIdx = prefs.getInt(KEY_SHAPE, 0)
        view.robotName = prefs.getString(KEY_NAME, "Beepo") ?: "Beepo"
    }

    fun setExtras(prayer: String? = null, volUp: Boolean? = null, focusEnd: Long? = null) {
        if (prayer != null) view.prayerName = prayer
        if (volUp != null) view.volUp = volUp
        if (focusEnd != null) view.focusEndMs = focusEnd
    }

    fun setTorch(on: Boolean) {
        view.torchOn = on
    }

    fun setAirplane(on: Boolean) {
        view.airplane = on
    }

    fun setFishing(on: Boolean) {
        if (fishing == on) return
        fishing = on
        if (on) view.startFishing() else view.stopFishing()
        applySettings()
    }

    fun fishLevelUp() = view.fishLevelUp()
    fun isFishing(): Boolean = fishing

    fun lookAt(x: Float, y: Float) = view.lookAt(x, y)

    private fun applyFraction(f: Float) {
        val lp = params ?: return
        fraction = f
        val w = idleW() + ((expW() - idleW()) * f).toInt()
        lp.width = min(w, screenW())
        lp.height = if (fishing) view.fishingHeight(lp.width.toFloat()) else idleH()
        if (attached) {
            try {
                wm.updateViewLayout(view, lp)
            } catch (e: Exception) {
            }
        }
    }

    private fun animateTo(target: Float) {
        animator?.cancel()
        if (!attached || target == fraction) return
        val a = ValueAnimator.ofFloat(fraction, target)
        a.duration = 380
        a.interpolator = if (target > fraction) {
            OvershootInterpolator(0.8f)
        } else {
            AccelerateDecelerateInterpolator()
        }
        a.addUpdateListener { applyFraction(it.animatedValue as Float) }
        animator = a
        a.start()
    }
}
