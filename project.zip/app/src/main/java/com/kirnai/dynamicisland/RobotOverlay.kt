package com.kirnai.dynamicisland

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.max
import kotlin.math.min

/**
 * Jendela overlay (di atas status bar) yang memuat RobotView.
 * Semua fungsi harus dipanggil dari main thread.
 */
class RobotOverlay(
    private val ctx: Context,
    private val tapCb: () -> Unit,
    private val longCb: () -> Unit,
    private val gestureCb: (Int) -> Unit = {}
) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val density = ctx.resources.displayMetrics.density
    private val view = RobotView(ctx)
    val ai = AiOverlay(ctx)
    private var offF = 0f
    private var offAnim: ValueAnimator? = null
    private var offOn = false

    private var params: WindowManager.LayoutParams? = null
    private var attached = false
    private var fraction = 0f
    private var animator: ValueAnimator? = null
    private var fishing = false
    private var fishTouch = false
    private var boosterOn = false
    val plug = PlugOverlay(ctx)
    var roam: Roam? = null
    private var exOn = false
    private var circleTaps = 0
    private var circleHit = false
    private val circleRun = Runnable {
        val n = circleTaps
        circleTaps = 0
        ai.circleCb?.invoke(n)
    }
    private var roamActive = false
    private var roamX = 0
    private var roamY = Int.MIN_VALUE

    private fun dp(v: Int): Int = (v * density).toInt()
    private fun idleW(): Int = dp(prefs.getInt(KEY_W, 115))
    private fun idleH(): Int = dp(prefs.getInt(KEY_H, 32))
    private fun screenW(): Int = ctx.resources.displayMetrics.widthPixels
    private fun expW(): Int = max(idleW(), min(screenW() - dp(24), (idleW() * 1.63f).toInt()))
    private fun roamEnabled(): Boolean = prefs.getBoolean(KEY_ROAM, true)

    /** Tepi atas pill saat menempel di colokan (px). Sedikit turun supaya colokan kelihatan. */
    fun dockTop(): Int = dp(prefs.getInt(KEY_TOP, 4)) + (if (roamEnabled()) dp(8) else 0)

    /** Lebar tambahan di kiri jendela untuk bulatan AI (px). */
    fun leftExtra(): Int = if (exOn) (idleH() * 1.2f).toInt() else 0

    fun curW(): Int = (params?.width ?: idleW()) - leftExtra()
    private fun posX(): Int = roamX - leftExtra() / 2

    fun curH(): Int = params?.height ?: idleH()
    fun aiCircleOn(): Boolean = ai.isOn()
    private fun touchOn(): Boolean = prefs.getBoolean(KEY_TOUCH, true)

    private fun flags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if ((!touchOn() || (fishing && !fishTouch)) && !roamActive) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    init {
        ai.stateCb = { st ->
            view.aiState = st
            if (st != AiOverlay.OFF) {
                exOn = true
                applyFraction(fraction)
            } else {
                uiHandler.postDelayed({
                    if (!ai.isOn()) {
                        exOn = false
                        applyFraction(fraction)
                    }
                }, 700L)
            }
        }
    }

    private val detector = GestureDetector(
        ctx,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                tapCb()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                longCb()
            }
        }
    )

    private val uiHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val holdRun = Runnable { gestureCb(3) }
    private var lastX = 0f
    private var swipeDir = 0
    private var swipeRev = 0

    init {
        view.setOnTouchListener { _, ev ->
            val r = roam
            if (roamActive && r != null) {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> r.grab(ev.rawX, ev.rawY)
                    MotionEvent.ACTION_MOVE -> r.dragMove(ev.rawX, ev.rawY)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> r.release()
                }
                return@setOnTouchListener true
            }
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) circleHit = exOn && ev.x < view.leftExtra && view.leftExtra > 0
            if (circleHit) {
                if (ev.actionMasked == MotionEvent.ACTION_UP) {
                    circleTaps++
                    uiHandler.removeCallbacks(circleRun)
                    uiHandler.postDelayed(circleRun, 380L)
                }
                return@setOnTouchListener true
            }
            detector.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = ev.x
                    swipeDir = 0
                    swipeRev = 0
                    uiHandler.removeCallbacks(holdRun)
                    uiHandler.postDelayed(holdRun, 1700L)
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    uiHandler.removeCallbacks(holdRun)
                    gestureCb(2)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.x - lastX
                    if (Math.abs(dx) > 7f * density) {
                        val d = if (dx > 0f) 1 else -1
                        if (swipeDir != 0 && d != swipeDir) swipeRev++
                        swipeDir = d
                        lastX = ev.x
                        if (swipeRev >= 3) {
                            swipeRev = 0
                            uiHandler.removeCallbacks(holdRun)
                            gestureCb(1)
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> uiHandler.removeCallbacks(holdRun)
            }
            true
        }
    }

    fun setMood(m: Float) {
        view.mood = m
    }

    fun setToss(b: Boolean) {
        view.toss = b
    }

    fun show() {
        if (attached) {
            applySettings()
            return
        }
        val lp = WindowManager.LayoutParams(
            idleW(),
            idleH(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags(),
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dockTop()
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        params = lp
        fraction = 0f
        view.baseH = idleH().toFloat()
        applyStyle()
        if (roamEnabled()) plug.show()
        try {
            wm.addView(view, lp)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
        if (attached) {
            ai.show()
            pushGeometry()
        }
    }

    fun hide() {
        animator?.cancel()
        offAnim?.cancel()
        ai.hide()
        plug.hide()
        if (attached) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
            }
            attached = false
        }
        fraction = 0f
    }

    /** Dipanggil setelah pengaturan (posisi, ukuran, sentuh) berubah. */
    fun applySettings() {
        val lp = params ?: return
        if (!attached) return
        lp.flags = flags()
        if (!roamActive) lp.y = dockTop()
        if (roamEnabled()) plug.show() else plug.hide()
        view.baseH = idleH().toFloat()
        applyStyle()
        applyFraction(fraction)
        view.invalidate()
    }

    fun setAct(a: Act, badge: String?) {
        view.setAct(a, badge)
        animateTo(a.wide)
    }

    fun blink() = view.blink()

    /** Membaca gaya robot (warna, bentuk mata, nama) dari pengaturan. */
    fun applyStyle() {
        view.colorIdx = prefs.getInt(KEY_COLOR, 0)
        view.shapeIdx = prefs.getInt(KEY_SHAPE, 0)
        view.robotName = prefs.getString(KEY_NAME, "Beepo") ?: "Beepo"
        val g = prefs.getBoolean(KEY_GLASS, true)
        val lvl = prefs.getInt(KEY_GLASS_LVL, 55) / 100f
        view.glassOn = g
        view.glassLvl = lvl
        ai.setGlass(g && !boosterOn, lvl)
    }

    fun isOff(): Boolean = offOn

    /** Robot dimatikan: pill mengecil jadi titik redup, atau dihidupkan lagi. */
    fun setOff(on: Boolean) {
        offOn = on
        view.offMode = on
        offAnim?.cancel()
        val a = ValueAnimator.ofFloat(offF, if (on) 1f else 0f)
        a.duration = 450
        a.interpolator = AccelerateDecelerateInterpolator()
        a.addUpdateListener {
            offF = it.animatedValue as Float
            applyFraction(fraction)
        }
        offAnim = a
        a.start()
    }

    /** Booster anti-lag: kaca dimatikan (pill polos hitam) supaya ringan saat main game. */
    fun setBooster(on: Boolean) {
        if (boosterOn == on) return
        boosterOn = on
        view.booster = on
        applyStyle()
        view.invalidate()
    }

    /** Selama mancing otomatis, pill boleh diketuk (6x untuk berhenti). */
    fun setFishTouch(on: Boolean) {
        if (fishTouch == on) return
        fishTouch = on
        val lp = params ?: return
        if (!attached) return
        lp.flags = flags()
        try { wm.updateViewLayout(view, lp) } catch (e: Exception) {}
    }

    fun setSleepMode(m: Int) {
        view.sleepMode = m
    }

    fun setPriv(on: Boolean) {
        view.privMode = on
    }

    fun setSpeaking(on: Boolean) {
        view.speaking = on
    }

    private fun pushGeometry() {
        val lp = params ?: return
        ai.setPill(lp.width - leftExtra(), lp.height, lp.y, roamX)
    }

    /** Roam mulai/selesai jalan-jalan: jendela jadi bisa disentuh dan digeser. */
    fun setRoamActive(on: Boolean) {
        if (roamActive == on) return
        roamActive = on
        val lp = params ?: return
        if (!attached) return
        lp.flags = flags()
        if (!on) {
            roamX = 0
            lp.x = posX()
            lp.y = dockTop()
            roamY = Int.MIN_VALUE
            view.rotation = 0f
        }
        try { wm.updateViewLayout(view, lp) } catch (e: Exception) {}
        pushGeometry()
    }

    fun roamPose(x: Int, y: Int, rotDeg: Float, bat: Float, vis: Float, dead: Boolean, conf: Boolean, lookX: Float, lookY: Float) {
        view.roamBat = bat
        view.roamVis = vis
        view.roamDead = dead
        view.roamConf = conf
        view.rotation = rotDeg
        if (dead) view.invalidate()
        val lp = params ?: return
        if (!attached) return
        if (x != roamX || y != roamY) {
            roamX = x
            roamY = y
            lp.x = posX()
            lp.y = y
            try { wm.updateViewLayout(view, lp) } catch (e: Exception) {}
            pushGeometry()
        }
        if (vis > 0.02f) {
            view.lookAt(lookX, lookY)
            view.invalidate()
        }
    }

    fun setExtras(prayer: String? = null, volUp: Boolean? = null, focusEnd: Long? = null) {
        if (prayer != null) view.prayerName = prayer
        if (volUp != null) view.volUp = volUp
        if (focusEnd != null) view.focusEndMs = focusEnd
    }

    fun musicBeat() = view.onBeat()

    fun musicBpm(b: Float) {
        view.musicBpm = b
    }

    fun gameState(mode: Int, phase: String, pos: Int = 0, len: Int = 0, score: Int = 0, count: Int = 3, robot: Int = 0, result: String = "") {
        view.gameMode = mode
        view.gamePhase = phase
        view.gamePos = pos
        view.gameLen = len
        view.gameScore = score
        view.gameCount = count
        view.gameRobot = robot
        view.gameResult = result
        view.gamePhaseChanged()
    }

    fun setTorch(on: Boolean) {
        view.torchOn = on
    }

    fun setAirplane(on: Boolean) {
        view.airplane = on
    }

    fun setFishing(on: Boolean) {
        if (fishing == on) return
        fishing = on
        if (on) view.startFishing() else view.stopFishing()
        applySettings()
    }

    fun fishLevelUp() = view.fishLevelUp()
    fun isFishing(): Boolean = fishing

    fun lookAt(x: Float, y: Float) = view.lookAt(x, y)

    private fun applyFraction(f: Float) {
        val lp = params ?: return
        fraction = f
        val w0 = idleW() + ((expW() - idleW()) * f).toInt()
        val dot = dp(44)
        val w = (w0 + (dot - w0) * offF).toInt()
        val ex = leftExtra()
        view.leftExtra = ex
        lp.width = min(w, screenW()) + ex
        lp.x = posX()
        lp.height = if (fishing) view.fishingHeight(lp.width.toFloat()) else idleH()
        if (attached) {
            try {
                wm.updateViewLayout(view, lp)
            } catch (e: Exception) {
            }
            pushGeometry()
        }
    }

    private fun animateTo(target: Float) {
        animator?.cancel()
        if (!attached || target == fraction) return
        val a = ValueAnimator.ofFloat(fraction, target)
        a.duration = 380
        a.interpolator = if (target > fraction) {
            OvershootInterpolator(0.8f)
        } else {
            AccelerateDecelerateInterpolator()
        }
        a.addUpdateListener { applyFraction(it.animatedValue as Float) }
        animator = a
        a.start()
    }
}
