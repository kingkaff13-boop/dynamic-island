package com.kirnai.dynamicisland

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Mendengarkan notifikasi masuk dan menampilkannya di pill.
 * Service ini dijaga hidup oleh sistem selama akses notifikasi aktif.
 * Jika layanan aksesibilitas aktif, pill digambar di atas status bar.
 */
class IslandListener : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: IslandListener? = null
    }

    private var overlay: IslandOverlay? = null
    private var overlayCtx: Context? = null
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        refresh()
    }

    override fun onListenerDisconnected() {
        overlay?.hide()
        overlay = null
        overlayCtx = null
        instance = null
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        overlay?.hide()
        overlay = null
        overlayCtx = null
        instance = null
        super.onDestroy()
    }

    private fun ensureOverlay(): IslandOverlay {
        val a11y = IslandAccessibility.instance
        val wanted: Context = a11y ?: this
        val current = overlay
        if (current != null && overlayCtx === wanted) return current
        current?.hide()
        val created = IslandOverlay(wanted, a11y != null)
        overlay = created
        overlayCtx = wanted
        return created
    }

    /** Tampilkan/sembunyikan pill sesuai pengaturan. */
    fun refresh() {
        if (instance == null) return
        val o = ensureOverlay()
        if (prefs.getBoolean(KEY_ENABLED, true)) {
            o.show()
            o.applySettings()
        } else {
            o.hide()
        }
    }

    fun demo() {
        overlay?.showMessage("Pesan baru", "Ini contoh notifikasi Dynamic Island", null)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (!prefs.getBoolean(KEY_ENABLED, true)) return
        if (sbn.packageName == packageName) return

        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return

        val extras = n.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)
        if (title.isNullOrBlank() && text.isNullOrBlank()) return

        val icon = try {
            n.smallIcon?.loadDrawable(this)
        } catch (e: Exception) {
            null
        }
        val shownTitle = if (title.isNullOrBlank()) appLabel(sbn.packageName) else title
        overlay?.showMessage(shownTitle, text, icon)
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}
