package com.kirnai.dynamicisland

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Suara robot buatan sendiri (sintesis, tanpa file audio, offline).
 * Rumusnya sama dengan versi artefak: osilator, vibrato, ring modulator, filter,
 * distorsi, dan envelope eksponensial. Suara aksi dipotong saat aksi baru dimulai.
 */
object Sfx {

    private const val SR = 32000
    private const val SINE = 0
    private const val SQUARE = 1
    private const val SAW = 2
    private const val TRI = 3
    private const val NOISE = 4
    private const val BAND = 0
    private const val LOW = 1
    private const val HIGH = 2

    @Volatile var enabled = true
    @Volatile var volume = 0.7f

    private val rnd = Random()
    private val voiceTracks = ArrayList<AudioTrack>()

    private class Note(
        val f: Float, val f2: Float, val d: Float, val at: Float, val type: Int, val v: Float,
        val att: Float, val lp: Float, val vib: Float, val vibd: Float, val ring: Float, val dist: Float,
        val ft: Int, val q: Float
    )

    private class Snd {
        val notes = ArrayList<Note>()

        fun t(
            f: Float, f2: Float = 0f, d: Float = .15f, at: Float = 0f, type: Int = SQUARE, v: Float = .15f,
            att: Float = .008f, lp: Float = 0f, vib: Float = 0f, vibd: Float = -1f, ring: Float = 0f, dist: Float = 0f
        ) {
            notes.add(Note(f, f2, d, at, type, v, att, lp, vib, if (vibd < 0f) f * 0.03f else vibd, ring, dist, BAND, .7f))
        }

        /** Derau lewat filter. ff2 > 0: frekuensi filter menyapu dari ff ke ff2. */
        fun n(d: Float = .1f, at: Float = 0f, ff: Float = 1000f, ft: Int = BAND, q: Float = .8f, v: Float = .1f, att: Float = .004f, ff2: Float = 0f) {
            notes.add(Note(ff, ff2, d, at, NOISE, v, att, 0f, 0f, 0f, 0f, 0f, ft, q))
        }

        fun bell(f: Float, at: Float) {
            t(f, d = 2.4f, at = at, type = SINE, v = .14f, att = .01f)
            t(f * 2.01f, d = 1.6f, at = at, type = SINE, v = .05f)
            t(f * 3f, d = 1.0f, at = at, type = SINE, v = .025f)
        }
    }

    // ---------- filter biquad ----------

    private class Biquad(type: Int, freq: Float, q: Float) {
        private var b0 = 0f
        private var b1 = 0f
        private var b2 = 0f
        private var a1 = 0f
        private var a2 = 0f
        private var x1 = 0f
        private var x2 = 0f
        private var y1 = 0f
        private var y2 = 0f

        init { set(type, freq, q) }

        fun set(type: Int, freq: Float, q: Float) {
            val fr = freq.coerceIn(20f, SR * 0.45f)
            val w0 = (2.0 * PI * fr / SR).toFloat()
            val c = cos(w0)
            val al = sin(w0) / (2f * q.coerceAtLeast(0.1f))
            val a0 = 1f + al
            when (type) {
                LOW -> { b0 = (1f - c) / 2f; b1 = 1f - c; b2 = (1f - c) / 2f }
                HIGH -> { b0 = (1f + c) / 2f; b1 = -(1f + c); b2 = (1f + c) / 2f }
                else -> { b0 = al; b1 = 0f; b2 = -al }
            }
            a1 = -2f * c / a0
            a2 = (1f - al) / a0
            b0 /= a0; b1 /= a0; b2 /= a0
        }

        fun process(x: Float): Float {
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1; x1 = x; y2 = y1; y1 = y
            return y
        }
    }

    private fun distort(x: Float, k: Float): Float {
        val xx = x.coerceIn(-1f, 1f)
        return (3f + k) * xx * 20f * (PI.toFloat() / 180f) / (PI.toFloat() + k * abs(xx))
    }

    private fun render(list: List<Note>): ShortArray {
        var total = 0f
        for (x in list) total = maxOf(total, x.at + x.d)
        val len = ((total + 0.08f) * SR).toInt()
        val buf = FloatArray(len)
        for (x in list) {
            val s0 = (x.at * SR).toInt()
            val cnt = (x.d * SR).toInt()
            var phase = 0.0
            val lpF = if (x.type != NOISE && x.lp > 0f) Biquad(LOW, x.lp, 0.7f) else null
            val nf = if (x.type == NOISE) Biquad(x.ft, x.f, x.q) else null
            val att = x.att.coerceAtMost(x.d * 0.9f).coerceAtLeast(0.001f)
            val lo = 0.0001f
            val hi = x.v.coerceAtLeast(lo * 2f)
            val riseK = ln(hi / lo)
            val fallK = ln(lo / hi)
            for (i in 0 until cnt) {
                val idx = s0 + i
                if (idx >= len) break
                val ts = i.toFloat() / SR
                val p = i.toFloat() / cnt
                var s: Float
                if (x.type == NOISE) {
                    if (x.f2 > 0f && (i and 63) == 0) nf!!.set(x.ft, (x.f * (x.f2 / x.f).toDouble().pow(p.toDouble())).toFloat(), x.q)
                    s = nf!!.process(rnd.nextFloat() * 2f - 1f)
                } else {
                    var f = x.f
                    if (x.f2 > 0f) f = (x.f * (x.f2 / x.f).toDouble().pow(p.toDouble())).toFloat()
                    if (x.vib > 0f) f += (sin(2.0 * PI * x.vib * ts) * x.vibd).toFloat()
                    phase += 2.0 * PI * f / SR
                    val ph = phase % (2.0 * PI)
                    s = when (x.type) {
                        SINE -> sin(ph).toFloat()
                        SQUARE -> if (ph < PI) 1f else -1f
                        SAW -> (ph / PI - 1.0).toFloat()
                        else -> (if (ph < PI) ph / PI * 2.0 - 1.0 else 3.0 - ph / PI * 2.0).toFloat()
                    }
                    if (lpF != null) s = lpF.process(s)
                    if (x.dist > 0f) s = distort(s, x.dist)
                    if (x.ring > 0f) s *= sin(2.0 * PI * x.ring * ts).toFloat()
                }
                val env = if (ts < att) lo * exp(riseK * ts / att)
                else hi * exp(fallK * (ts - att) / (x.d - att).coerceAtLeast(0.001f))
                buf[idx] += s * env
            }
        }
        val out = ShortArray(len)
        for (i in 0 until len) out[i] = (tanh(buf[i] * 1.15f) * 30000f).toInt().toShort()
        return out
    }

    private fun play(list: List<Note>, ui: Boolean) {
        if (!enabled) return
        val vol = volume
        Thread {
            try {
                val data = render(list)
                if (data.isEmpty()) return@Thread
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val fmt = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
                val track = AudioTrack(
                    attrs, fmt, data.size * 2, AudioTrack.MODE_STATIC,
                    AudioManager.AUDIO_SESSION_ID_GENERATE
                )
                track.write(data, 0, data.size)
                track.setVolume(vol)
                if (!ui) synchronized(voiceTracks) { voiceTracks.add(track) }
                track.play()
                Thread.sleep((data.size * 1000L / SR) + 250L)
                if (!ui) synchronized(voiceTracks) { voiceTracks.remove(track) }
                try { track.release() } catch (e: Exception) {}
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun go(ui: Boolean = false, f: Snd.() -> Unit) {
        if (!enabled) return
        val s = Snd()
        s.f()
        play(s.notes, ui)
    }

    /** Memotong suara aksi sebelumnya (dipanggil saat aksi baru dimulai). */
    fun newVoice() {
        synchronized(voiceTracks) {
            for (t in voiceTracks) {
                try {
                    t.setVolume(0f)
                    t.stop()
                } catch (e: Exception) {
                }
            }
            voiceTracks.clear()
        }
    }

    fun forAct(a: Act, volUp: Boolean = true, toss: Boolean = true) {
        when (a) {
            Act.HAPPY, Act.HELLO -> go {
                val fs = floatArrayOf(660f, 830f, 990f, 1320f)
                for (i in 0 until 4) t(fs[i], d = if (i < 3) .09f else .28f, at = i * .085f, type = SQUARE, lp = 3200f, v = .10f, vib = if (i == 3) 9f else 0f, vibd = 18f)
                t(330f, 660f, .4f, 0f, TRI, .08f)
            }
            Act.SAD -> go {
                t(520f, 300f, 1.0f, 0f, SAW, .12f, lp = 900f, vib = 5.5f, vibd = 16f)
                t(430f, 240f, 1.2f, .7f, SAW, .10f, lp = 700f, vib = 5f, vibd = 14f)
                t(700f, 520f, .5f, 2.0f, TRI, .05f, vib = 7f, vibd = 10f)
            }
            Act.ANGRY -> go {
                t(95f, 60f, .9f, 0f, SAW, .22f, lp = 700f, ring = 34f, dist = 40f)
                t(130f, 80f, .7f, 1.0f, SQUARE, .18f, lp = 600f, ring = 46f, dist = 30f)
                n(d = .25f, at = 1.8f, ff = 2500f, q = .8f, v = .12f)
                t(70f, 55f, 1.2f, 2.2f, SAW, .2f, lp = 500f, ring = 28f, dist = 30f)
            }
            Act.ANNOYED -> go {
                t(210f, 150f, .4f, 0f, SAW, .13f, lp = 650f, ring = 30f)
                t(190f, 140f, .35f, .55f, SAW, .11f, lp = 600f, ring = 30f)
            }
            Act.SURPRISE -> go {
                t(380f, 1500f, .16f, 0f, SQUARE, .12f, lp = 4000f)
                t(1500f, 1200f, .09f, .18f, TRI, .10f)
            }
            Act.LAUGH -> go {
                for (i in 0 until 5) t((if (i % 2 == 1) 520f else 660f) + i * 18f, d = .085f, at = i * .125f, type = SQUARE, lp = 2400f, v = .11f)
                t(700f, 500f, .3f, .65f, TRI, .06f, vib = 12f, vibd = 20f)
            }
            Act.WINK -> go {
                t(900f, 1400f, .1f, 0f, SQUARE, .09f, lp = 3500f)
                t(1400f, 1000f, .08f, .12f, TRI, .08f)
            }
            Act.SLEEPY -> go {
                t(320f, 170f, 1.7f, 0f, SINE, .14f, att = .4f, vib = .9f, vibd = 25f)
                n(d = .7f, at = 2.3f, ff = 260f, ft = LOW, v = .22f, att = .25f)
                n(d = .7f, at = 3.5f, ff = 240f, ft = LOW, v = .2f, att = .25f)
                t(1000f, 780f, .5f, 4.6f, TRI, .04f)
            }
            Act.CONFUSED -> go {
                t(420f, 330f, .4f, 0f, TRI, .12f, vib = 7f, vibd = 16f)
                t(360f, 760f, .5f, .5f, SQUARE, .09f, lp = 2200f)
            }
            Act.PEEK -> go {
                t(600f, 500f, .15f, 0f, TRI, .06f)
                t(520f, 640f, .2f, .9f, TRI, .06f)
                t(640f, 520f, .15f, 1.9f, TRI, .05f)
            }
            Act.HOT -> go {
                n(d = 3.2f, ff = 700f, q = .6f, v = .06f, att = .6f)
                t(260f, 820f, 1.6f, 0f, SAW, .06f, att = .3f, lp = 1800f)
                for (i in 0 until 6) t(1900f, d = .07f, at = 1.7f + i * .22f, type = SQUARE, lp = 3000f, v = .07f)
            }
            Act.PHOTO -> go {
                t(300f, 900f, .2f, 0f, TRI, .08f)
                val at = floatArrayOf(.5f, 1.15f, 1.8f)
                for (i in 0 until 3) t(if (i < 2) 880f else 1320f, d = .1f, at = at[i], type = SQUARE, lp = 3000f, v = .1f)
                n(d = .06f, at = 2.55f, ff = 3500f, ft = HIGH, v = .3f)
                n(d = .05f, at = 2.62f, ff = 1800f, ft = HIGH, v = .2f)
                t(1000f, 1500f, .12f, 2.8f, SQUARE, .08f, lp = 3500f)
                t(1500f, 2000f, .16f, 2.94f, SQUARE, .08f, lp = 3500f)
            }
            Act.DANCE -> go {
                val step = 0.2727f
                val mel = floatArrayOf(440f, 523f, 587f, 659f, 587f, 523f, 440f, 392f)
                for (i in 0 until 25) {
                    t(160f, 45f, .2f, i * step, SINE, .3f)
                    n(d = .05f, at = i * step + step / 2f, ff = 6000f, ft = HIGH, v = .07f)
                    t(mel[i % 8], d = .2f, at = i * step, type = TRI, v = .1f, ring = if (i % 4 == 3) 60f else 0f)
                }
            }
            Act.EXERCISE -> go {
                t(600f, d = .1f, type = SQUARE, lp = 3000f, v = .08f)
                t(900f, d = .14f, at = .12f, type = SQUARE, lp = 3000f, v = .08f)
                for (k in 0 until 20) t(if (k % 4 == 3) 1100f else 800f, d = .04f, at = 2f + k, type = SQUARE, lp = 2000f, v = .03f)
                for (j in 0 until 5) t(1200f, d = .25f, at = 2f + 4f * j, type = TRI, v = .09f)
                val fs = floatArrayOf(784f, 988f, 1175f, 1568f)
                for (i in 0 until 4) t(fs[i], d = .14f, at = 22f + i * .1f, type = SQUARE, v = .08f, lp = 3000f)
            }
            Act.HEADSET -> go {
                n(d = .03f, ff = 2500f, ft = HIGH, v = .2f)
                t(300f, d = .06f, type = SQUARE, lp = 1500f, v = .1f)
                val a = floatArrayOf(523f, 659f, 784f, 1047f)
                for (i in 0 until 4) t(a[i], d = .12f, at = .12f + i * .09f, type = SQUARE, lp = 3000f, v = .07f)
                val mel = floatArrayOf(659f, 784f, 880f, 784f, 659f, 523f)
                for (i in 0 until 6) t(mel[i], d = .22f, at = 1f + i * .3f, type = TRI, v = .07f)
            }
            Act.VOLUME -> go {
                val f = if (volUp) floatArrayOf(600f, 800f, 1000f) else floatArrayOf(1000f, 800f, 600f)
                for (i in 0 until 3) t(f[i], d = .09f, at = i * .1f, type = SQUARE, lp = 3000f, v = .08f)
            }
            Act.ADZAN -> go {
                val a = floatArrayOf(392f, 523f, 659f)
                for (i in 0 until 3) bell(a[i], i * 0.9f)
                val b = floatArrayOf(659f, 523f, 392f)
                for (i in 0 until 3) bell(b[i], 4.6f + i * 0.9f)
            }
            Act.DIZZY -> go {
                for (i in 0 until 3) {
                    t(700f, 380f, .55f, i * 1.1f, SINE, .12f, vib = 6f, vibd = 40f)
                    t(380f, 720f, .55f, i * 1.1f + .55f, SINE, .12f, vib = 6f, vibd = 40f)
                }
            }
            Act.YAWN -> go {
                t(420f, 180f, 1.3f, 0f, SINE, .13f, att = .3f, vib = 5f, vibd = 14f)
                n(d = .7f, at = 1.2f, ff = 300f, ft = LOW, v = .15f, att = .2f)
            }
            Act.MORNING -> go {
                val a = floatArrayOf(523f, 659f, 784f, 1047f)
                for (i in 0 until 4) t(a[i], d = .2f, at = i * .14f, type = TRI, v = .11f)
                val b = floatArrayOf(2200f, 2600f, 2300f, 2800f)
                for (i in 0 until 4) t(b[i], b[i] * 1.2f, .07f, .7f + i * .1f, SINE, .05f)
            }
            Act.MISS -> go {
                t(620f, 420f, .7f, 0f, SINE, .1f, vib = 6f, vibd = 12f)
                t(560f, 360f, .8f, 1.0f, SINE, .09f, vib = 6f, vibd = 12f)
            }
            Act.REUNION -> go {
                val a = floatArrayOf(660f, 830f, 990f, 1320f, 1660f)
                for (i in 0 until 5) t(a[i], d = .1f, at = i * .07f, type = SQUARE, lp = 3200f, v = .09f)
                t(330f, 990f, .5f, 0f, TRI, .08f)
            }
            Act.REST -> go {
                t(880f, d = .9f, type = SINE, v = .1f)
                t(660f, d = 1.1f, at = .5f, type = SINE, v = .09f)
            }
            Act.BUG -> go {
                for (i in 0 until 14) t(2200f + rnd.nextInt(600), d = .02f, at = .2f + i * .38f, type = SQUARE, v = .03f)
                t(900f, 300f, .12f, 5.9f, SQUARE, .1f)
            }
            Act.BALL -> go {
                for (i in 0 until 7) t(320f, 140f, .16f, i * .98f, SINE, .12f)
            }
            Act.TOSS -> go {
                n(d = .4f, at = 1.3f, ff = 500f, ff2 = 1800f, q = 1f, v = .07f)
                if (toss) {
                    t(1200f, d = .1f, at = 2.6f, type = TRI, v = .1f)
                    t(1700f, d = .15f, at = 2.72f, type = TRI, v = .1f)
                } else {
                    t(150f, 80f, .2f, 2.6f, SINE, .14f)
                    t(200f, 150f, .35f, 3.0f, SAW, .07f, lp = 500f)
                }
            }
            Act.TICKLE -> go {
                for (i in 0 until 8) t(700f + (i % 2) * 160f + i * 14f, d = .07f, at = i * .1f, type = SQUARE, lp = 2600f, v = .09f)
            }
            Act.CUDDLE -> go {
                t(70f, d = 3f, type = SAW, lp = 260f, v = .1f, ring = 24f, att = .5f)
                t(520f, 640f, .5f, .2f, SINE, .05f, vib = 5f, vibd = 8f)
            }
            Act.WEAK -> go {
                t(300f, 120f, 1.3f, 0f, SAW, .1f, lp = 600f, vib = 4f, vibd = 12f)
                t(900f, d = .1f, at = 2.0f, type = SQUARE, v = .07f)
                t(900f, d = .1f, at = 3.0f, type = SQUARE, v = .07f)
            }
            Act.REVIVE -> go {
                t(200f, 1200f, .5f, 0f, SAW, .1f, lp = 3000f)
                val a = floatArrayOf(660f, 880f, 1320f)
                for (i in 0 until 3) t(a[i], d = .12f, at = .5f + i * .1f, type = SQUARE, lp = 3200f, v = .1f)
            }
            else -> {}
        }
    }

    // ---------- suara kejadian dan UI ----------

    fun ping() = go(true) { t(1250f, 1500f, .12f, 0f, TRI, .07f) }
    fun recover() = go(true) { t(500f, 260f, .5f, 0f, SINE, .08f, att = .1f) }
    fun torchOn() = go(true) {
        n(d = .03f, ff = 3000f, ft = HIGH, v = .2f)
        t(500f, 2400f, .28f, .04f, TRI, .09f, vib = 20f, vibd = 60f)
        t(3200f, d = .2f, at = .2f, type = SINE, v = .04f)
    }
    fun torchOff() = go(true) {
        n(d = .03f, ff = 2000f, ft = HIGH, v = .18f)
        t(1200f, 450f, .16f, .03f, TRI, .08f)
    }
    fun charger() = go(true) {
        t(520f, d = .07f, type = SQUARE, v = .1f, lp = 3000f)
        t(780f, d = .14f, at = .09f, type = SQUARE, v = .1f, lp = 3000f)
        n(d = .08f, at = .2f, ff = 4000f, ft = HIGH, v = .1f)
        t(1040f, d = .12f, at = .24f, type = SQUARE, v = .09f, lp = 3000f)
    }
    fun lowBatt() = go(true) {
        t(440f, 300f, .5f, 0f, SAW, .1f, lp = 900f, vib = 5f, vibd = 12f)
        for (i in 0 until 3) t(1000f, d = .08f, at = .8f + i * .2f, type = SQUARE, v = .07f, lp = 2500f)
    }
    fun wifiOff() = go(true) {
        val a = floatArrayOf(900f, 700f, 500f)
        for (i in 0 until 3) t(a[i], a[i] * .8f, .15f, i * .17f, TRI, .09f)
    }
    fun wifiOn() = go(true) {
        val a = floatArrayOf(500f, 700f, 900f)
        for (i in 0 until 3) t(a[i], a[i] * 1.15f, .12f, i * .1f, SQUARE, .07f, lp = 3000f)
    }
    fun focusStart() = go(true) {
        t(700f, d = .08f, type = SQUARE, lp = 3000f, v = .08f)
        t(1050f, d = .14f, at = .1f, type = SQUARE, lp = 3000f, v = .08f)
    }
    fun focusDone() = go(true) {
        val a = floatArrayOf(784f, 988f, 1175f, 1568f, 1175f, 1568f)
        for (i in 0 until 6) t(a[i], d = .16f, at = i * .12f, type = SQUARE, lp = 3200f, v = .08f)
    }
    fun good() = go(true) {
        val a = floatArrayOf(660f, 880f, 1320f)
        for (i in 0 until 3) t(a[i], d = .1f, at = i * .08f, type = SQUARE, lp = 3200f, v = .09f)
    }
    fun bad() = go(true) { t(330f, 140f, .5f, 0f, SAW, .12f, lp = 700f, vib = 6f, vibd = 14f) }
    fun beep(f: Float) = go(true) { t(f, d = .3f, type = TRI, v = .14f) }
    fun cue(mood: Int) = go(true) {
        when (mood) {
            1 -> t(600f, 1200f, .14f, 0f, SQUARE, .06f, lp = 3000f)
            2 -> t(500f, 330f, .5f, 0f, SINE, .07f)
            3 -> t(380f, 620f, .35f, 0f, TRI, .07f, vib = 7f, vibd = 12f)
            4 -> t(660f, 700f, .3f, 0f, SINE, .05f)
        }
    }
    fun planeOn() = go(true) { t(880f, d = .16f, type = SINE, v = .12f); t(1320f, d = .3f, at = .14f, type = SINE, v = .1f) }
    fun planeOff() = go(true) { t(1320f, d = .16f, type = SINE, v = .12f); t(880f, d = .3f, at = .14f, type = SINE, v = .1f) }
    fun planePass() = go(true) { n(d = 1.5f, ff = 250f, ff2 = 1100f, q = 1.4f, v = .06f, att = .5f); t(110f, 190f, 1.5f, 0f, SINE, .05f, att = .5f) }
    fun cast() = go(true) { n(d = .35f, ff = 500f, ff2 = 2200f, q = 1.2f, v = .08f); t(520f, 220f, .3f, 0f, TRI, .07f) }
    fun splash() = go(true) { n(d = .32f, ff = 2200f, ft = LOW, v = .16f); t(340f, 110f, .22f, 0f, SINE, .09f) }
    fun bite() = go(true) { t(880f, d = .09f, type = SQUARE, lp = 3000f, v = .09f); t(1320f, d = .14f, at = .11f, type = SQUARE, lp = 3000f, v = .09f) }
    fun tick() = go(true) { t(1900f, d = .025f, type = SQUARE, lp = 4000f, v = .045f) }
    fun creak(k: Float) = go(true) { t(130f + 90f * k, 160f + 110f * k, .3f, 0f, SAW, .05f + .03f * k, lp = 520f, ring = 38f) }
    fun snap() = go(true) {
        n(d = .09f, ff = 3000f, ft = HIGH, q = .6f, v = .3f)
        t(2400f, 180f, .18f, 0f, SQUARE, .1f, lp = 4000f)
        t(460f, 220f, .9f, .5f, SAW, .1f, lp = 800f, vib = 5f, vibd = 14f)
    }
    fun levelUp() = go(true) { t(440f, 660f, .18f, 0f, TRI, .1f); t(880f, d = .22f, at = .16f, type = TRI, v = .09f) }
    fun catchFish(tier: Int) = go(true) {
        val base = floatArrayOf(660f, 700f, 560f, 480f, 392f)[tier.coerceIn(0, 4)]
        val cnt = 3 + tier
        for (i in 0 until cnt) t(base * 1.122f.pow(i * 2), d = .11f, at = i * .09f, type = SQUARE, lp = 3200f, v = .09f)
        if (tier >= 3) t(base * .5f, base, .5f, cnt * .09f, SAW, .1f, lp = 1200f)
    }
    fun test() = go(true) { t(900f, 1400f, .1f, 0f, SQUARE, .09f, lp = 3500f); t(1400f, 1000f, .08f, .12f, TRI, .08f) }
}
