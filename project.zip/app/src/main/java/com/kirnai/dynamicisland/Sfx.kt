package com.kirnai.dynamicisland

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Suara robot buatan sendiri (sintesis, tanpa file audio, offline).
 * Tiap suara dirender jadi PCM lalu diputar lewat AudioTrack di thread terpisah.
 */
object Sfx {

    private const val SR = 22050
    private const val SINE = 0
    private const val SQUARE = 1
    private const val SAW = 2
    private const val TRI = 3
    private const val NOISE = 4

    @Volatile var enabled = true
    @Volatile var volume = 0.7f

    private val rnd = Random()

    private class N(
        val f: Float, val f2: Float, val d: Float, val at: Float,
        val type: Int, val v: Float, val vib: Float, val vibd: Float, val ring: Float
    )

    private fun n(
        f: Float, f2: Float = 0f, d: Float = 0.15f, at: Float = 0f, type: Int = SQUARE,
        v: Float = 0.15f, vib: Float = 0f, vibd: Float = 0f, ring: Float = 0f
    ) = N(f, f2, d, at, type, v, vib, vibd, ring)

    private fun render(list: List<N>): ShortArray {
        var total = 0f
        for (x in list) total = maxOf(total, x.at + x.d)
        val len = ((total + 0.06f) * SR).toInt()
        val buf = FloatArray(len)
        for (x in list) {
            val s0 = (x.at * SR).toInt()
            val cnt = (x.d * SR).toInt()
            var phase = 0.0
            var lp = 0f
            for (i in 0 until cnt) {
                val idx = s0 + i
                if (idx >= len) break
                val p = i.toFloat() / cnt
                val ts = i.toFloat() / SR
                var f = x.f
                if (x.f2 > 0f) f = (x.f * (x.f2 / x.f).toDouble().pow(p.toDouble())).toFloat()
                if (x.vib > 0f) f += (sin(2.0 * PI * x.vib * ts) * x.vibd).toFloat()
                phase += 2.0 * PI * f / SR
                var s: Float
                if (x.type == NOISE) {
                    val a = min(1f, (2.0 * PI * f / SR).toFloat())
                    lp += a * ((rnd.nextFloat() * 2f - 1f) - lp)
                    s = lp * 2.2f
                } else {
                    val ph = phase % (2.0 * PI)
                    s = when (x.type) {
                        SINE -> sin(ph).toFloat()
                        SQUARE -> if (ph < PI) 0.8f else -0.8f
                        SAW -> (ph / PI - 1.0).toFloat()
                        else -> (if (ph < PI) ph / PI * 2.0 - 1.0 else 3.0 - ph / PI * 2.0).toFloat()
                    }
                    if (x.ring > 0f) s *= sin(2.0 * PI * x.ring * ts).toFloat()
                }
                val att = min(1f, ts / 0.008f)
                val env = att * (1f - p) * (1f - p)
                buf[idx] += s * env * x.v
            }
        }
        val out = ShortArray(len)
        for (i in 0 until len) {
            val v = buf[i].coerceIn(-1f, 1f)
            out[i] = (v * 30000f).toInt().toShort()
        }
        return out
    }

    private fun play(list: List<N>) {
        if (!enabled) return
        val vol = volume
        Thread {
            try {
                val data = render(list)
                if (data.isEmpty()) return@Thread
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val fmt = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
                val track = AudioTrack(
                    attrs, fmt, data.size * 2, AudioTrack.MODE_STATIC,
                    AudioManager.AUDIO_SESSION_ID_GENERATE
                )
                track.write(data, 0, data.size)
                track.setVolume(vol)
                track.play()
                Thread.sleep((data.size * 1000L / SR) + 250L)
                track.release()
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun seq(vararg l: N) = play(l.toList())

    fun forAct(a: Act) {
        when (a) {
            Act.HAPPY, Act.HELLO -> seq(
                n(660f, d = .09f, at = 0f, v = .10f), n(830f, d = .09f, at = .085f, v = .10f),
                n(990f, d = .09f, at = .17f, v = .10f),
                n(1320f, d = .28f, at = .255f, v = .10f, vib = 9f, vibd = 18f),
                n(330f, 660f, .4f, 0f, TRI, .08f)
            )
            Act.SAD -> seq(
                n(520f, 300f, 1.0f, 0f, SAW, .12f, 5.5f, 16f), n(430f, 240f, 1.2f, .7f, SAW, .10f, 5f, 14f),
                n(700f, 520f, .5f, 2.0f, TRI, .05f, 7f, 10f)
            )
            Act.ANGRY -> seq(
                n(95f, 60f, .9f, 0f, SAW, .2f, ring = 34f), n(130f, 80f, .7f, 1.0f, SQUARE, .16f, ring = 46f),
                n(2500f, d = .25f, at = 1.8f, type = NOISE, v = .1f), n(70f, 55f, 1.2f, 2.2f, SAW, .18f, ring = 28f)
            )
            Act.ANNOYED -> seq(
                n(210f, 150f, .4f, 0f, SAW, .13f, ring = 30f), n(190f, 140f, .35f, .55f, SAW, .11f, ring = 30f)
            )
            Act.SURPRISE -> seq(n(380f, 1500f, .16f, 0f, SQUARE, .12f), n(1500f, 1200f, .09f, .18f, TRI, .10f))
            Act.LAUGH -> seq(
                n(660f, d = .085f, at = 0f, v = .11f), n(538f, d = .085f, at = .125f, v = .11f),
                n(696f, d = .085f, at = .25f, v = .11f), n(574f, d = .085f, at = .375f, v = .11f),
                n(732f, d = .085f, at = .5f, v = .11f), n(700f, 500f, .3f, .65f, TRI, .06f, 12f, 20f)
            )
            Act.WINK -> seq(n(900f, 1400f, .1f, 0f, SQUARE, .09f), n(1400f, 1000f, .08f, .12f, TRI, .08f))
            Act.SLEEPY -> seq(
                n(320f, 170f, 1.7f, 0f, SINE, .14f, .9f, 25f),
                n(260f, d = .7f, at = 2.3f, type = NOISE, v = .2f), n(240f, d = .7f, at = 3.5f, type = NOISE, v = .18f)
            )
            Act.CONFUSED -> seq(
                n(400f, 700f, .22f, 0f, TRI, .11f), n(700f, 380f, .25f, .25f, TRI, .11f), n(520f, 820f, .3f, .55f, TRI, .1f)
            )
            Act.PEEK -> seq(n(500f, 700f, .12f, 0f, SINE, .09f), n(700f, 500f, .12f, .2f, SINE, .09f))
            Act.HOT -> seq(
                n(900f, d = .05f, at = 0f, v = .08f), n(900f, d = .05f, at = .1f, v = .08f),
                n(900f, d = .05f, at = .2f, v = .08f), n(1200f, d = 1.4f, at = .3f, type = NOISE, v = .1f)
            )
            Act.PHOTO -> seq(
                n(700f, d = .06f, at = .5f, v = .08f), n(700f, d = .06f, at = 1.15f, v = .08f),
                n(700f, d = .06f, at = 1.8f, v = .08f), n(1100f, d = .05f, at = 2.55f, v = .12f),
                n(3000f, d = .1f, at = 2.55f, type = NOISE, v = .18f)
            )
            Act.DANCE -> seq(
                n(330f, d = .12f, at = 0f, v = .1f), n(392f, d = .12f, at = .45f, v = .1f),
                n(494f, d = .12f, at = .9f, v = .1f), n(392f, d = .12f, at = 1.35f, v = .1f),
                n(330f, d = .12f, at = 1.8f, v = .1f), n(494f, d = .12f, at = 2.25f, v = .1f),
                n(660f, d = .25f, at = 2.7f, v = .1f)
            )
            Act.EXERCISE -> seq(n(660f, d = .1f, at = 0f, v = .1f), n(880f, d = .16f, at = .12f, v = .1f))
            Act.HEADSET -> seq(n(520f, d = .1f, at = 0f, type = TRI, v = .11f), n(780f, d = .18f, at = .1f, type = TRI, v = .11f))
            Act.VOLUME -> seq(n(600f, d = .08f, type = SINE, v = .1f))
            Act.ADZAN -> seq(
                n(784f, d = 1.4f, at = 0f, type = SINE, v = .14f), n(1568f, d = 1.0f, at = 0f, type = SINE, v = .04f),
                n(659f, d = 1.6f, at = 1.2f, type = SINE, v = .13f), n(1318f, d = 1.1f, at = 1.2f, type = SINE, v = .04f),
                n(523f, d = 2.2f, at = 2.5f, type = SINE, v = .13f), n(1046f, d = 1.4f, at = 2.5f, type = SINE, v = .04f)
            )
            Act.DIZZY -> seq(
                n(300f, 600f, .5f, 0f, SINE, .1f, 6f, 60f), n(600f, 300f, .5f, .5f, SINE, .1f, 6f, 60f),
                n(300f, 600f, .5f, 1.0f, SINE, .1f, 6f, 60f)
            )
            else -> {}
        }
    }

    fun charger() = seq(n(520f, d = .09f, v = .1f), n(780f, d = .12f, at = .09f, v = .1f), n(1040f, d = .18f, at = .2f, v = .1f))
    fun lowBatt() = seq(n(440f, 330f, .3f, 0f, SAW, .1f), n(330f, 220f, .4f, .35f, SAW, .1f))
    fun wifiOn() = seq(n(700f, d = .08f, v = .09f), n(900f, d = .08f, at = .09f, v = .09f), n(1200f, d = .12f, at = .18f, v = .09f))
    fun wifiOff() = seq(n(900f, 400f, .35f, 0f, SAW, .09f))
    fun torchOn() = seq(n(600f, 1500f, .22f, 0f, TRI, .11f))
    fun torchOff() = seq(n(1500f, 500f, .22f, 0f, TRI, .1f))
    fun planeOn() = seq(n(880f, d = .16f, type = SINE, v = .12f), n(1320f, d = .3f, at = .14f, type = SINE, v = .1f))
    fun planeOff() = seq(n(1320f, d = .16f, type = SINE, v = .12f), n(880f, d = .3f, at = .14f, type = SINE, v = .1f))
    fun planePass() = seq(n(700f, 2400f, 1.5f, 0f, NOISE, .09f), n(110f, 190f, 1.5f, 0f, SINE, .05f))
    fun cast() = seq(n(500f, 2200f, .35f, 0f, NOISE, .08f), n(520f, 220f, .3f, 0f, TRI, .07f))
    fun splash() = seq(n(2200f, d = .32f, type = NOISE, v = .16f), n(340f, 110f, .22f, 0f, SINE, .09f))
    fun bite() = seq(n(880f, d = .09f, v = .09f), n(1320f, d = .14f, at = .11f, v = .09f))
    fun tick() = seq(n(1900f, d = .025f, v = .045f))
    fun creak(k: Float) = seq(n(130f + 90f * k, 160f + 110f * k, .3f, 0f, SAW, .05f + .03f * k, ring = 38f))
    fun snap() = seq(
        n(5000f, d = .09f, type = NOISE, v = .3f), n(2400f, 180f, .18f, 0f, SQUARE, .1f),
        n(460f, 220f, .9f, .5f, SAW, .1f, 5f, 14f)
    )
    fun levelUp() = seq(n(440f, 660f, .18f, 0f, TRI, .1f), n(880f, d = .22f, at = .16f, type = TRI, v = .09f))
    fun catchFish(tier: Int) {
        val base = floatArrayOf(660f, 700f, 560f, 480f, 392f)[tier.coerceIn(0, 4)]
        val list = ArrayList<N>()
        val cnt = 3 + tier
        for (i in 0 until cnt) {
            list.add(n(base * 1.122f.pow(i * 2), d = .11f, at = i * .09f, v = .09f))
        }
        if (tier >= 3) list.add(n(base * .5f, base, .5f, cnt * .09f, SAW, .1f))
        play(list)
    }
    fun test() = seq(n(900f, 1400f, .1f, 0f, SQUARE, .09f), n(1400f, 1000f, .08f, .12f, TRI, .08f))
}
