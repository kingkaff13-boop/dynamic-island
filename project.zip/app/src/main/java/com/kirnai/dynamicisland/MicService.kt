package com.kirnai.dynamicisland

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Layanan latar depan kecil agar Android mengizinkan mikrofon tetap dipakai
 * saat asisten AI aktif. Hanya jalan selama asisten AI menyala.
 */
class MicService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel("ai_mic", "Asisten AI", NotificationManager.IMPORTANCE_MIN))
            }
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "ai_mic") else Notification.Builder(this)
            val n = b.setContentTitle("Asisten AI aktif")
                .setContentText("Robot sedang mendengarkan. Ketuk robot 5x untuk mematikan.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(7, n)
            }
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object {
        fun start(ctx: Context) {
            try {
                val i = Intent(ctx, MicService::class.java)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, MicService::class.java))
            } catch (e: Exception) {
            }
        }
    }
}
