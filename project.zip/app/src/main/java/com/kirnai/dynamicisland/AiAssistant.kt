package com.kirnai.dynamicisland

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale
import java.util.Random

/**
 * Asisten AI: mendengar (SpeechRecognizer), berpikir (Gemini), bicara (TextToSpeech).
 * Kalimat dibuat oleh Gemini, bukan kalimat jadi. Kalimat cadangan hanya dipakai
 * kalau Gemini tidak bisa dihubungi. Semua fungsi publik dipanggil dari main thread.
 */
class AiAssistant(
    private val ctx: Context,
    private val overlay: RobotOverlay,
    private val host: Host
) {
    interface Host {
        fun play(a: Act)
        /** Boleh bicara sekarang? (layar nyala, tidak sholat/telepon/pribadi, robot hidup) */
        fun canTalk(): Boolean
        fun category(): String
        fun musicPlaying(): Boolean
        fun mood(): Float
    }

    private val h = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val rnd = Random()

    var active = false
        private set
    private var suspended = false
    private var thinking = false
    private var speaking = false
    private var listening = false
    private var micDenied = false
    private var paused = false

    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var peakRms = -10f
    private var lastInteract = 0L
    private var nextProAt = 0L
    private var gen = 0

    private val history = ArrayList<Pair<String, String>>()
    private val recent = ArrayList<String>()

    private fun name(): String = prefs.getString(KEY_NAME, "Beepo") ?: "Beepo"

    // ---------- hidup / mati ----------

    fun toggle() {
        if (active) deactivate(true) else activate()
    }

    fun activate() {
        if (active) return
        active = true
        suspended = false
        paused = false
        micDenied = false
        history.clear()
        MicService.start(ctx)
        initTts()
        Sfx.aiOn()
        overlay.ai.setState(AiOverlay.LISTEN)
        scheduleNextPro(true)
        h.postDelayed({ if (active) ask("hello", "") }, 600L)
        h.post(proRun)
    }

    fun deactivate(sound: Boolean) {
        if (!active) return
        active = false
        gen++
        h.removeCallbacksAndMessages(null)
        stopListening()
        try { tts?.stop() } catch (e: Exception) {}
        speaking = false
        thinking = false
        overlay.setSpeaking(false)
        overlay.ai.setState(AiOverlay.OFF)
        overlay.ai.setCaption(null)
        if (sound) Sfx.aiOff()
        MicService.stop(ctx)
        try { tts?.shutdown() } catch (e: Exception) {}
        tts = null
        ttsReady = false
    }

    /** Ketuk bulatan: 2x = jeda mikrofon, 1x = sambung lagi. */
    fun onCircleTap(n: Int) {
        if (!active || suspended) return
        if (n >= 2 && !paused) {
            paused = true
            stopListening()
            Sfx.aiOff()
            if (!speaking && !thinking) overlay.ai.setState(AiOverlay.PAUSED)
            overlay.ai.setCaption("Mikrofon dijeda. Ketuk bulatan sekali untuk menyambung.")
            h.postDelayed({ if (paused && !speaking) overlay.ai.setCaption(null) }, 2500L)
        } else if (n == 1 && paused) {
            paused = false
            Sfx.heard()
            if (!speaking && !thinking) overlay.ai.setState(AiOverlay.LISTEN)
            h.postDelayed({ startListening() }, 300L)
        }
    }

    /** Privasi: lepas mikrofon dan diam (on = true), lalu lanjut lagi (on = false). */
    fun suspend(on: Boolean) {
        if (!active) return
        suspended = on
        if (on) {
            gen++
            stopListening()
            try { tts?.stop() } catch (e: Exception) {}
            speaking = false
            thinking = false
            overlay.setSpeaking(false)
            overlay.ai.setState(AiOverlay.OFF)
            overlay.ai.setCaption(null)
        } else {
            overlay.ai.setState(if (paused) AiOverlay.PAUSED else AiOverlay.LISTEN)
            h.postDelayed({ startListening() }, 400L)
        }
    }

    // ---------- mendengar ----------

    private fun startListening() {
        if (!active || suspended || speaking || thinking || micDenied || paused) return
        if (listening) return
        try {
            if (rec == null) {
                if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                    say("Pengenal suara tidak ada di HP ini.", null, false)
                    return
                }
                rec = SpeechRecognizer.createSpeechRecognizer(ctx)
                rec?.setRecognitionListener(listener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            peakRms = -10f
            listening = true
            rec?.startListening(i)
            overlay.ai.setState(AiOverlay.LISTEN)
        } catch (e: Exception) {
            listening = false
            destroyRec()
            h.postDelayed({ startListening() }, 1500L)
        }
    }

    private fun stopListening() {
        listening = false
        try { rec?.cancel() } catch (e: Exception) {}
        destroyRec()
    }

    private fun destroyRec() {
        try { rec?.destroy() } catch (e: Exception) {}
        rec = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() { peakRms = -10f }
        override fun onRmsChanged(rmsdB: Float) { if (rmsdB > peakRms) peakRms = rmsdB }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            listening = false
            if (!active) return
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                micDenied = true
                say("Aku belum boleh pakai mikrofon. Izinkan di pengaturan aplikasi.", Act.WORRY, false)
                return
            }
            // tidak ada suara / tidak cocok: dengarkan lagi
            val wait = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) 1200L else 350L
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) destroyRec()
            h.postDelayed({ startListening() }, wait)
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = list?.firstOrNull()?.trim().orEmpty()
            if (!active) return
            if (text.isEmpty()) {
                h.postDelayed({ startListening() }, 250L)
                return
            }
            onHeard(text)
        }
    }

    private fun onHeard(text: String) {
        val now = SystemClock.elapsedRealtime()
        val far = prefs.getInt(KEY_AI_FAR, 3)
        if (far > 0 && peakRms < far.toFloat()) {
            Sfx.ignored()
            h.postDelayed({ startListening() }, 250L)
            return
        }
        val low = text.lowercase()
        val nm = name().lowercase()
        val called = nm.isNotEmpty() && low.contains(nm)
        val ongoing = now - lastInteract < 40_000L
        if (prefs.getBoolean(KEY_AI_RAMAI, false) && !called && !ongoing) {
            Sfx.ignored()
            h.postDelayed({ startListening() }, 250L)
            return
        }
        if (!host.canTalk()) {
            h.postDelayed({ startListening() }, 600L)
            return
        }
        lastInteract = now
        Sfx.heard()
        ask("reply", text)
    }

    // ---------- berpikir ----------

    private fun ask(task: String, userText: String) {
        if (!active || suspended) return
        thinking = true
        stopListening()
        overlay.ai.setState(AiOverlay.THINK)
        host.play(Act.PONDER)
        Sfx.think()
        val my = ++gen
        val key = (prefs.getString(KEY_AI_KEY, "") ?: "").trim()
        val prompt = buildPrompt(task, userText)
        Thread {
            var out: String? = null
            var err = ""
            if (key.isEmpty()) {
                err = "nokey"
            } else {
                val r = callGemini(key, prompt)
                out = r.first
                err = r.second
            }
            h.post { if (my == gen && active && !suspended) onAnswer(task, userText, out, err) }
        }.start()
    }

    private fun onAnswer(task: String, userText: String, out: String?, err: String) {
        thinking = false
        if (out == null || out.isBlank()) {
            val msg = when (err) {
                "nokey" -> "Kunci Gemini belum diisi. Isi dulu di pengaturan Robot Island."
                "net" -> "Aku tidak bisa terhubung ke internet."
                "quota" -> "Jatah Gemini gratis sedang habis, coba sebentar lagi."
                "auth" -> "Kunci Gemini ditolak. Coba cek lagi kuncinya."
                else -> if (err.startsWith("other ")) "Gemini bermasalah: " + err.substring(6)
                else if (err.startsWith("net ")) "Tidak bisa terhubung ke Gemini: " + err.substringAfter(' ', "")
                else "Gemini bermasalah, kode tidak diketahui."
            }
            if (msg.isNotEmpty() && (task == "reply" || task == "hello")) {
                say(msg, Act.CONFUSED, false)
            } else {
                say(fallback(task, userText), null, true)
            }
            return
        }
        var t = out.trim()
        var act: Act? = null
        val m = Regex("^\\s*\\[([A-Za-z ]+)]\\s*").find(t)
        if (m != null) {
            act = EMO[m.groupValues[1].trim().lowercase()]
            t = t.substring(m.range.last + 1)
        }
        t = clean(t)
        if (t.isEmpty()) {
            say(fallback(task, userText), null, true)
            return
        }
        history.add(Pair("u", userText))
        history.add(Pair("a", t))
        while (history.size > 12) history.removeAt(0)
        recent.add(t)
        while (recent.size > 5) recent.removeAt(0)
        say(t, act, false)
    }

    private fun clean(s0: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s0.length) {
            val c = s0[i]
            if (Character.isHighSurrogate(c)) { i += 2; continue }
            if (c == '*' || c == '_' || c == '`' || c == '#' || c == '"' || c == '“' || c == '”') { i++; continue }
            sb.append(if (c == '\n' || c == '\r') ' ' else c)
            i++
        }
        var r = sb.toString().replace(Regex("\\s+"), " ").trim()
        if (r.length > 230) {
            val cut = r.lastIndexOf('.', 230)
            r = if (cut > 60) r.substring(0, cut + 1) else r.substring(0, 230)
        }
        return r
    }

    // ---------- bicara ----------

    private fun initTts() {
        if (tts != null) return
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val t = tts
                if (t != null) {
                    val r = t.setLanguage(Locale("id", "ID"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
                    t.setPitch(1.25f)
                    t.setSpeechRate(1.05f)
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            h.post { if (active) { overlay.setSpeaking(true); overlay.ai.setState(AiOverlay.SPEAK) } }
                        }
                        override fun onDone(utteranceId: String?) { h.post { finishSpeak() } }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { h.post { finishSpeak() } }
                    })
                    ttsReady = true
                }
            }
        }
    }

    /** cadangan = true: tampilkan label "kalimat cadangan". */
    private fun say(text: String, act: Act?, cadangan: Boolean) {
        if (!active) return
        speaking = true
        stopListening()
        if (act != null) host.play(act)
        overlay.ai.setCaption(if (cadangan) "$text  · kalimat cadangan" else text)
        val textOnly = host.musicPlaying() || host.category() == "video" || !ttsReady
        if (textOnly) {
            overlay.setSpeaking(true)
            overlay.ai.setState(AiOverlay.SPEAK)
            val ms = (1800L + text.length * 55L).coerceAtMost(9000L)
            val my = gen
            h.postDelayed({ if (my == gen) finishSpeak() }, ms)
        } else {
            try {
                val b = Bundle()
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, b, "ai" + gen)
            } catch (e: Exception) {
                finishSpeak()
            }
            val my = gen
            // pengaman kalau TTS tidak memanggil balik
            h.postDelayed({ if (my == gen && speaking) finishSpeak() }, (4000L + text.length * 120L).coerceAtMost(25000L))
        }
    }

    private fun finishSpeak() {
        if (!speaking) return
        speaking = false
        overlay.setSpeaking(false)
        overlay.ai.setState(if (active && !suspended) (if (paused) AiOverlay.PAUSED else AiOverlay.LISTEN) else AiOverlay.OFF)
        h.postDelayed({ overlay.ai.setCaption(null) }, 1200L)
        lastInteract = SystemClock.elapsedRealtime()
        h.postDelayed({ startListening() }, 500L)
    }

    // ---------- bicara duluan ----------

    private val proRun = object : Runnable {
        override fun run() {
            if (!active) return
            val now = SystemClock.elapsedRealtime()
            if (!suspended && !paused && !speaking && !thinking && now >= nextProAt && host.canTalk()) {
                scheduleNextPro(false)
                ask("pro", "")
            }
            h.postDelayed(this, 15_000L)
        }
    }

    private fun scheduleNextPro(first: Boolean) {
        val lv = prefs.getInt(KEY_AI_TALK, 0)
        val (lo, hi) = when (lv) {
            1 -> Pair(8 * 60_000L, 14 * 60_000L)
            2 -> Pair(60_000L, 150_000L)
            else -> Pair(3 * 60_000L, 6 * 60_000L)
        }
        val d = lo + (rnd.nextFloat() * (hi - lo)).toLong()
        nextProAt = SystemClock.elapsedRealtime() + (if (first) d + 45_000L else d)
    }

    // ---------- prompt ----------

    private fun buildPrompt(task: String, userText: String): String {
        val cal = Calendar.getInstance()
        val hari = arrayOf("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")[cal.get(Calendar.DAY_OF_WEEK) - 1]
        val bulan = arrayOf(
            "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
            "Agustus", "September", "Oktober", "November", "Desember"
        )[cal.get(Calendar.MONTH)]
        val jam = cal.get(Calendar.HOUR_OF_DAY)
        val menit = cal.get(Calendar.MINUTE)
        val bagian = if (jam < 4) "dini hari" else if (jam < 11) "pagi" else if (jam < 15) "siang" else if (jam < 18) "sore" else "malam"
        val hhmm = String.format(Locale.US, "%02d.%02d", jam, menit)
        val mood = host.mood()
        val suasana = if (mood < 25f) "kesepian dan agak murung" else if (mood > 70f) "ceria" else "biasa saja, santai"
        val kat = when (host.category()) {
            "game" -> "bermain game"
            "video" -> "menonton video"
            "social" -> "membuka media sosial"
            "news" -> "membaca berita"
            "browser" -> "berselancar di internet"
            "musik" -> "mendengarkan musik"
            "home" -> "di layar utama, tidak sedang membuka apa-apa"
            else -> "memakai aplikasi lain"
        }
        val sb = StringBuilder()
        sb.append("Kamu adalah ").append(name()).append(", robot kecil sahabat pemilik HP yang tinggal di pill di atas layar. ")
        sb.append("Bicara santai seperti teman, bahasa Indonesia sehari-hari, 1 sampai 2 kalimat pendek (maksimal 150 karakter). ")
        sb.append("Tanpa emoji, tanpa markdown, tanpa tanda bintang, tanpa tanda kutip, satu paragraf.\n")
        sb.append("FAKTA SAAT INI (pakai ini, jangan menebak waktu atau tanggal): ")
        sb.append(hari).append(", ").append(cal.get(Calendar.DAY_OF_MONTH)).append(' ').append(bulan).append(' ')
        sb.append(cal.get(Calendar.YEAR)).append(", pukul ").append(hhmm).append(" (").append(bagian).append(", waktu setempat pengguna).\n")
        sb.append("Suasana hatimu: ").append(suasana).append(".\n")
        sb.append("Pengguna sedang: ").append(kat).append(". Musik terdengar: ").append(if (host.musicPlaying()) "ya" else "tidak").append(".\n")
        sb.append("Kamu tidak punya akses internet atau data terkini (cuaca, berita, skor). Kalau ditanya hal itu, jawab jujur bahwa kamu tidak tahu.\n")
        sb.append("Awali dengan SATU tag emosi dalam kurung siku, pilih yang paling cocok dari: ")
        sb.append("[senang] [sedih] [marah] [kaget] [tertawa] [kedip] [bingung] [berpikir] [suka] [kagum] [setuju] [tidak] [malu] [khawatir] [semangat] [usil] [lega] [ide] [canggung] [ngantuk] [netral].\n")
        if (history.isNotEmpty() && task == "reply") {
            sb.append("Percakapan sebelumnya:\n")
            for (p in history) {
                if (p.first == "u") { if (p.second.isNotEmpty()) sb.append("Pengguna: ").append(p.second).append('\n') }
                else sb.append(name()).append(": ").append(p.second).append('\n')
            }
        }
        if (recent.isNotEmpty() && task == "pro") {
            sb.append("Kalimat yang sudah kamu ucapkan (jangan diulang): ").append(recent.joinToString(" | ")).append('\n')
        }
        when (task) {
            "hello" -> sb.append("Tugas: Kamu baru saja diaktifkan. Sapa pengguna dengan singkat dan hangat.\n")
            "pro" -> sb.append("Tugas: Mulailah bicara sendiri tanpa diminta, seperti teman yang iseng. Komentar singkat sesuai situasi sekarang, boleh bertanya balik. Jangan mengulang kalimat yang sudah kamu ucapkan.\n")
            else -> sb.append("Tugas: Jawab ucapan pengguna ini: ").append(userText).append('\n')
        }
        sb.append("Keluarkan hanya tag lalu kalimat yang diucapkan.")
        return sb.toString()
    }

    // ---------- Gemini ----------

    /** Mengembalikan (teks, kode galat). Kode: "", "net", "auth", "quota", "other ...". */
    private fun callGemini(key: String, prompt: String): Pair<String?, String> {
        val pick = (prefs.getString(KEY_AI_MODEL, "") ?: "").trim()
        val auto = (prefs.getString("gemini_auto", "") ?: "").trim()
        val models = ArrayList<String>()
        if (pick.isNotEmpty() && Regex("[a-z0-9.\\-]+").matches(pick)) models.add(pick)
        if (auto.isNotEmpty() && !models.contains(auto)) models.add(auto)
        for (m in arrayOf("gemini-2.5-flash", "gemini-2.0-flash")) if (!models.contains(m)) models.add(m)
        var lastErr = "other"
        var all404 = true
        for (model in models) {
            val r = tryModel(key, model, prompt)
            if (r.first != null) {
                if (model != pick && model != auto) prefs.edit().putString("gemini_auto", model).apply()
                return r
            }
            if (r.second == "auth") return r
            lastErr = r.second
            if (!r.second.startsWith("other 404")) all404 = false
        }
        // semua model bawaan ditolak: tanya Google model apa yang tersedia untuk kunci ini
        if (all404 || lastErr.startsWith("other 404")) {
            val found = listModels(key)
            var n = 0
            for (m in found) {
                if (models.contains(m)) continue
                if (n++ >= 4) break
                val r = tryModel(key, m, prompt)
                if (r.first != null) {
                    prefs.edit().putString("gemini_auto", m).apply()
                    return r
                }
                if (r.second == "auth") return r
                lastErr = r.second
            }
            if (found.isEmpty()) lastErr = "other 404 tidak ada model yang tersedia untuk kunci ini"
        }
        return Pair(null, lastErr)
    }

    /** Daftar model yang bisa generateContent, flash dulu, tanpa lite/tts/image/live. */
    private fun listModels(key: String): List<String> {
        val out = ArrayList<String>()
        try {
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=100").openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 12000
            c.setRequestProperty("x-goog-api-key", key)
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            c.disconnect()
            if (code !in 200..299) return out
            val arr = JSONObject(txt).optJSONArray("models") ?: return out
            val good = ArrayList<String>()
            val rest = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val nm = o.optString("name", "").removePrefix("models/")
                val ms = o.optJSONArray("supportedGenerationMethods") ?: continue
                var ok = false
                for (k in 0 until ms.length()) if (ms.optString(k) == "generateContent") ok = true
                if (!ok || !nm.startsWith("gemini")) continue
                if (nm.contains("tts") || nm.contains("image") || nm.contains("live") || nm.contains("embedding") ||
                    nm.contains("robotics") || nm.contains("computer") || nm.contains("audio") || nm.contains("thinking")
                ) continue
                if (nm.contains("flash") && !nm.contains("lite")) good.add(nm)
                else if (nm.contains("flash")) rest.add(nm)
            }
            good.sortDescending()
            rest.sortDescending()
            out.addAll(good)
            out.addAll(rest)
        } catch (e: Exception) {
        }
        return out
    }

    private fun tryModel(key: String, model: String, prompt: String): Pair<String?, String> {
        var withThink = model.contains("2.5") || model.contains("3")
        var tries = 0
        var lastErr = "other"
        while (tries < 3) {
            tries++
            try {
                val body = JSONObject()
                val parts = JSONArray().put(JSONObject().put("text", prompt))
                body.put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                val gc = JSONObject().put("temperature", 0.95).put("maxOutputTokens", 300)
                if (withThink) gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                body.put("generationConfig", gc)
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 25000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                c.disconnect()
                if (code in 200..299) {
                    val j = JSONObject(txt)
                    val cand = j.optJSONArray("candidates")?.optJSONObject(0)
                    val ps = cand?.optJSONObject("content")?.optJSONArray("parts")
                    val sb = StringBuilder()
                    if (ps != null) for (i in 0 until ps.length()) sb.append(ps.optJSONObject(i)?.optString("text", "") ?: "")
                    val r = sb.toString().trim()
                    if (r.isNotEmpty()) return Pair(r, "")
                    val why = cand?.optString("finishReason", "") ?: ""
                    val blk = j.optJSONObject("promptFeedback")?.optString("blockReason", "") ?: ""
                    return Pair(null, "other 200 jawaban kosong $why $blk $model")
                }
                var detail = ""
                try { detail = JSONObject(txt).optJSONObject("error")?.optString("message", "") ?: "" } catch (e: Exception) {}
                if (code == 400 && withThink) { withThink = false; continue }
                if (code >= 500 && tries < 3) { Thread.sleep(700); continue }
                if (code == 401 || code == 403) return Pair(null, "auth")
                if (code == 429) return Pair(null, "quota")
                if (code == 400 && txt.contains("API key", true)) return Pair(null, "auth")
                lastErr = "other $code ${detail.take(70)}"
                return Pair(null, lastErr)
            } catch (e: java.net.MalformedURLException) {
                return Pair(null, "other model salah")
            } catch (e: java.io.IOException) {
                if (tries < 2) { try { Thread.sleep(600) } catch (x: Exception) {}; continue }
                return Pair(null, "net " + e.javaClass.simpleName + " " + (e.message ?: "").take(50))
            } catch (e: Exception) {
                return Pair(null, "other " + (e.message ?: "").take(60))
            }
        }
        return Pair(null, lastErr)
    }

    // ---------- kalimat cadangan ----------

    private fun pick(vararg a: String): String = a[rnd.nextInt(a.size)]

    private fun fallback(task: String, userText: String): String {
        if (task == "reply") {
            val low = userText.lowercase()
            val cal = Calendar.getInstance()
            return when {
                Regex("jam berapa|pukul berapa").containsMatchIn(low) ->
                    "Sekarang jam " + String.format(Locale.US, "%02d.%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)) + "."
                Regex("hari apa").containsMatchIn(low) ->
                    "Hari ini " + arrayOf("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")[cal.get(Calendar.DAY_OF_WEEK) - 1] + "."
                Regex("siapa (kamu|namamu)|namamu").containsMatchIn(low) -> "Aku " + name() + ", robot kecil di atas layarmu."
                Regex("terima kasih|makasih").containsMatchIn(low) -> pick("Sama-sama!", "Siap, santai aja.")
                else -> pick("Hmm, aku lagi susah mikir. Coba ulang sebentar lagi ya.", "Maaf, otakku lagi putus. Coba lagi nanti.")
            }
        }
        return when (host.category()) {
            "game" -> pick("Semangat mainnya!", "Awas jangan sampai kalah ya.")
            "video" -> pick("Tontonannya seru ya?", "Jangan lupa istirahatin mata.")
            "social" -> pick("Ada kabar seru nggak?", "Scroll-nya jangan kelamaan ya.")
            "news" -> pick("Ada berita apa hari ini?", "Baca yang bener-bener aja ya.")
            "browser" -> pick("Lagi cari apa?", "Nyari apa nih?")
            "musik" -> pick("Lagunya enak.", "Aku ikut goyang dikit ah.")
            else -> when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
                in 4..10 -> pick("Selamat pagi!", "Sudah sarapan belum?")
                in 11..14 -> pick("Sudah makan siang belum?", "Panas ya hari ini.")
                in 15..17 -> pick("Sore-sore enaknya ngemil.", "Jangan lupa minum ya.")
                in 18..21 -> pick("Sudah makan malam belum?", "Malam ini santai aja ya.")
                else -> pick("Sudah malam, jangan begadang ya.", "Mataku mulai berat nih.")
            }
        }
    }

    companion object {
        val EMO: Map<String, Act> = mapOf(
            "senang" to Act.HAPPY, "sedih" to Act.SAD, "marah" to Act.ANNOYED, "kaget" to Act.SURPRISE,
            "tertawa" to Act.LAUGH, "kedip" to Act.WINK, "bingung" to Act.CONFUSED, "berpikir" to Act.PONDER,
            "suka" to Act.LOVE, "kagum" to Act.WOW, "setuju" to Act.NOD, "tidak" to Act.SHAKE,
            "malu" to Act.SHY, "khawatir" to Act.WORRY, "semangat" to Act.EXCITED, "usil" to Act.SMUG,
            "lega" to Act.RELIEF, "ide" to Act.IDEA, "canggung" to Act.AWKWARD, "ngantuk" to Act.YAWN
        )
    }
}
