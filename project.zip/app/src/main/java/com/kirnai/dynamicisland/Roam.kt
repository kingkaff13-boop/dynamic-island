package com.kirnai.dynamicisland

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONArray
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Robot cabut dari colokan dan jalan-jalan di seluruh layar. Logika disalin dari prototipe web:
 * baterai ~5 menit jalan, pulang di 5%, colokan goyang kena angin (bisa gagal masuk),
 * bingung setelah baru keluar, mati kalau habis, dan harus dibantu geser dengan jari.
 * Semua posisi dalam piksel; kecepatan prototipe (satuan per detik) dikali U = lebar layar / 300.
 */
class Roam(
    private val ctx: Context,
    private val overlay: RobotOverlay,
    private val plug: PlugOverlay,
    private val host: Host
) {
    interface Host {
        fun play(a: Act)
        fun say(text: String)
        fun blocked(): Boolean
        fun busy(): Boolean
        fun screenOn(): Boolean
        fun ask(prompt: String, cb: (String?) -> Unit)
        fun setDead(dead: Boolean)
        fun category(): String
        fun mood(): Float
        fun robotName(): String
    }

    companion object {
        const val DOCKED = 0
        const val LEAVING = 1
        const val OUT = 2
        const val RETURNING = 3
        const val DEAD = 4
        const val DOCKING = 5
        private const val TAU = (2.0 * PI).toFloat()
        private val CONF_LINES = arrayOf("Eh, aku harus ke mana?", "Geser aku dong...", "Ini di mana ya?", "Bingung... kasih arahan dong.")
    }

    private class Step(
        val fx: Float, val fy: Float, val ax: Float, val ay: Float, val abs: Boolean,
        val gaya: String, val jalur: String, val jeda: Float, val emosi: String?, val kata: String
    )

    private class Cur(
        val s: Step, val p0x: Float, val p0y: Float, val p1x: Float, val p1y: Float, val dist: Float,
        val dur: Float, val t0: Long, var phase: Int, val side: Int, val hops: Int
    ) {
        var pt0 = 0L
        var fid = 0L
    }

    private val h = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val rnd = Random()
    private val density = ctx.resources.displayMetrics.density
    private val sw = ctx.resources.displayMetrics.widthPixels
    private val sh = ctx.resources.displayMetrics.heightPixels
    private val U = sw / 300f
    private fun dp(v: Float): Float = v * density

    var mode = DOCKED
        private set
    var dead = false
        private set
    var bat = 100f
        private set
    var confused = false
        private set
    private var running = false

    // posisi pill: ox = geser dari tengah layar, y = tepi atas pill
    private var ox = 0f
    private var y = 0f
    private var vx = 0f
    private var vy = 0f
    private var rot = 0f
    private var rotV = 0f
    private var lookX = 0f
    private var lookY = 0f
    private var vis = 0f
    private var lastT = 0L
    private var t0 = 0L
    private var outAt = 0L
    private var nextCheck = 0L
    private var th = 0f
    private var thv = 0f
    private var headAttach = 1f
    private var gust = 0f
    private var clicked = false
    private var ckX = 0f
    private var ckY = 0f
    private var ckT = 0L
    private var dockY0 = 0f
    private var fails = 0
    private var confN = 0
    private var holdUntil = 0L
    private var dizzyUntil = 0L
    private var reviveAt = 0L
    private var deadY0 = 0f
    private var glx = 0f
    private var gly = 0f
    private var flash = 0f
    private var leaveVy = 0f
    private var nextPlan = 0L
    private var planning = false
    private val plan = ArrayList<Step>()
    private var cur: Cur? = null

    // geser jari
    private var dragging = false
    private var grabbed = false
    private var gx = 0f
    private var gy = 0f
    private var gStartX = 0f
    private var gStartY = 0f
    private var dragTx = 0f
    private var dragTy = 0f
    private var turnHas = false
    private var turnAng = 0f
    private var turnAcc = 0f
    private var turnT = 0L
    private var turnPx = 0f
    private var turnPy = 0f

    private var sched: RoamSched = RoamSched.load(prefs)

    // ---------- geometri ----------

    private fun dockY(): Float = overlay.dockTop().toFloat()
    private fun hookX(): Float = sin(th) * plug.cableLen
    private fun hookY(): Float = plug.pivotY + cos(th) * plug.cableLen
    private fun halfW(): Float = overlay.curW() / 2f + dp(2f)
    private fun x0(): Float = -sw / 2f + halfW() + (if (overlay.aiCircleOn()) dp(46f) else 0f)
    private fun x1(): Float = sw / 2f - halfW()
    private fun y0(): Float = dockY()
    private fun y1(): Float = (sh - overlay.curH() - dp(30f)).toFloat()

    fun isActive(): Boolean = mode != DOCKED
    fun isRoaming(): Boolean = mode != DOCKED
    fun isDragging(): Boolean = dragging

    // ---------- siklus ----------

    fun start() {
        if (running) return
        running = true
        lastT = SystemClock.uptimeMillis()
        sched = RoamSched.load(prefs)
        snapHome()
        h.post(tick)
    }

    fun stop() {
        running = false
        h.removeCallbacks(tick)
        snapHome()
        if (dead) {
            dead = false
            host.setDead(false)
        }
        pushView()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.uptimeMillis()
            val dt = min(0.1f, max(0.001f, (now - lastT) / 1000f))
            lastT = now
            if (!host.screenOn()) {
                h.postDelayed(this, 600L)
                return
            }
            try {
                update(now, dt)
            } catch (e: Exception) {
            }
            h.postDelayed(this, if (mode == DOCKED && !dead && bat >= 99.5f) 1000L else 24L)
        }
    }

    private fun snapHome() {
        mode = DOCKED
        ox = 0f; y = dockY(); vx = 0f; vy = 0f; rot = 0f; rotV = 0f
        headAttach = 1f; th = 0f; thv = 0f
        cur = null; plan.clear(); dragging = false; grabbed = false; vis = 0f; confused = false
        overlay.setRoamActive(false)
    }

    // ---------- bantuan ----------

    private fun pick(vararg a: String): String = a[rnd.nextInt(a.size)]
    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
    private fun clamp(v: Float, a: Float, b: Float): Float = if (v < a) a else if (v > b) b else v
    private fun easeIO(u: Float): Float = if (u < 0.5f) 4f * u * u * u else 1f - Math.pow((-2.0 * u + 2.0), 3.0).toFloat() / 2f
    private fun easeSine(u: Float): Float = -(cos(PI.toFloat() * u) - 1f) / 2f

    private fun windForce(now: Long, dt: Float): Float {
        if (mode == DOCKED || (mode == DOCKING && clicked)) return 0f
        if (rnd.nextFloat() < dt * 0.14f) gust = 1.2f
        gust *= exp(-dt * 0.8f)
        val amp = 0.18f + 0.32f * (0.5f + 0.5f * sin(now / 7000f)) + gust
        return amp * (sin(now / 150f) + 0.6f * sin(now / 230f + 1f)) * 50f
    }

    // ---------- jadwal ----------

    private fun schedTick() {
        val nowMs = System.currentTimeMillis()
        if (nowMs < nextCheck) return
        nextCheck = nowMs + 1000L
        if (sched.day != RoamSched.dayKey()) sched = RoamSched.load(prefs)
        if (!prefs.getBoolean(KEY_ROAM, true) || mode != DOCKED || dead) return
        var i = -1
        for (k in 0 until 5) if (sched.done[k] == 0 && sched.times[k] <= nowMs) { i = k; break }
        if (i < 0) return
        if (nowMs - sched.times[i] > 40 * 60_000L) {
            sched.done[i] = 2
            RoamSched.save(prefs, sched)
            return
        }
        if (host.busy() || bat < 60f) return
        if (depart()) {
            sched.done[i] = 1
            sched.at[i] = nowMs
            RoamSched.save(prefs, sched)
        }
    }

    // ---------- keluar, pulang, colok ----------

    private fun depart(): Boolean {
        if (mode != DOCKED || host.blocked()) return false
        val now = SystemClock.uptimeMillis()
        mode = LEAVING; t0 = now; plan.clear(); cur = null
        fails = 0; gust = 0f; confN = 0; dead = false
        headAttach = 0f; th = 0.5f; thv = 7f; leaveVy = dp(30f) * 3f
        overlay.setRoamActive(true)
        Sfx.tick()
        host.play(Act.SURPRISE)
        host.say(pick("Cabut colokan! Aku jalan-jalan dulu ya.", "Dadah colokan, aku keluar sebentar.", "Bosan di atas terus, aku main dulu!"))
        return true
    }

    private fun returnHome(why: String) {
        if (mode != OUT) return
        mode = RETURNING; cur = null; plan.clear(); t0 = SystemClock.uptimeMillis()
        if (why == "low") {
            host.say("Baterai tinggal sedikit. Pulang ke colokan ya.")
            Sfx.lowBatt()
        } else host.say("Capek jalan-jalan. Balik ke colokan ya.")
    }

    private fun startDock(now: Long) {
        mode = DOCKING; t0 = now; clicked = false; dockY0 = y
    }

    private fun dockFail(now: Long, hy: Float) {
        fails++; clicked = false
        bat = max(0f, bat - 1.2f)
        thv += (if (rnd.nextBoolean()) -1f else 1f) * 4f
        y = min(y1(), hy + dp(18f))
        Sfx.bad()
        if (bat <= 0f && !dead) { die(); return }
        if (dead) { mode = DEAD; deadY0 = y; return }
        mode = RETURNING; holdUntil = now + 650L; glx = 0f; gly = 0f
        if (fails % 2 == 1) host.say(pick("Aduh, nggak masuk!", "Colokannya goyang terus!", "Kok meleset sih..."))
    }

    private fun finishDock(now: Long) {
        mode = DOCKED; headAttach = 1f; th = 0f; thv = 0f; confused = false
        overlay.setRoamActive(false)
        if (dead) {
            reviveAt = now + 10000L
        } else {
            host.play(Act.RELIEF)
            host.say(pick("Sudah tersambung. Ngecas dulu ya.", "Aaah, enaknya sudah sampai tempat cas."))
        }
    }

    private fun die() {
        dead = true; mode = DEAD; bat = 0f; cur = null; plan.clear(); deadY0 = y; reviveAt = 0L; clicked = false
        host.setDead(true)
        Sfx.robotOff()
    }

    private fun endConfused(helped: Boolean) {
        if (!confused) return
        confused = false; cur = null; plan.clear(); nextPlan = 0L
        requestPlan()
        if (mode != OUT) return
        host.say(if (helped) pick("Oh, begitu! Makasih arahannya.", "Aku mengerti sekarang!") else "Oh iya, aku ingat caranya!")
        host.play(if (helped) Act.HAPPY else Act.IDEA)
    }

    // ---------- rencana gerak (AI dalang, rencana cadangan kalau AI tidak ada) ----------

    private fun spd(g: String): Float = when (g) {
        "pelan" -> 38f; "biasa" -> 70f; "cepat" -> 130f; "loncat" -> 85f; "melayang" -> 50f; else -> 70f
    }

    private fun emoAct(e: String?): Act? = when (e) {
        "senang" -> Act.HAPPY; "penasaran" -> Act.PONDER; "usil" -> Act.SMUG; "semangat" -> Act.EXCITED
        "santai" -> Act.RELIEF; "ngantuk" -> Act.YAWN; "kaget" -> Act.SURPRISE; "malu" -> Act.SHY
        "bingung" -> Act.CONFUSED; "suka" -> Act.LOVE; else -> null
    }

    private fun st(x: Float, yy: Float, gaya: String, jalur: String, jeda: Float, emosi: String?, kata: String) =
        Step(x, yy, 0f, 0f, false, gaya, jalur, jeda, emosi, kata)

    private fun procPlan(): ArrayList<Step> {
        val out = ArrayList<Step>()
        val n = 4 + rnd.nextInt(3)
        val kinds = arrayOf("jelajah", "lari", "loncat", "melayang", "intip", "bingung")
        fun r() = rnd.nextFloat()
        val fx = clamp((ox - x0()) / max(1f, x1() - x0()), 0f, 1f)
        val fy = clamp((y - y0()) / max(1f, y1() - y0()), 0f, 1f)
        for (i in 0 until n) {
            when (kinds[rnd.nextInt(kinds.size)]) {
                "jelajah" -> out.add(st(r(), r() * 0.9f, if (r() < 0.5f) "biasa" else "pelan", if (r() < 0.5f) "lengkung" else "lurus", 2f + r() * 4f, if (r() < 0.5f) "penasaran" else "santai", if (r() < 0.2f) "Wah, banyak ikon." else ""))
                "lari" -> out.add(st(if (r() < 0.5f) 0.05f + r() * 0.2f else 0.75f + r() * 0.2f, r(), "cepat", "lurus", 1f + r() * 2f, if (r() < 0.5f) "semangat" else "senang", if (r() < 0.2f) "Wuuus!" else ""))
                "loncat" -> out.add(st(r(), r() * 0.8f, "loncat", "lurus", 1.5f + r() * 2f, "senang", if (r() < 0.2f) "Hop hop hop!" else ""))
                "melayang" -> out.add(st(r(), r() * 0.9f, "melayang", "melingkar", 2f + r() * 3f, if (r() < 0.5f) "santai" else "suka", ""))
                "intip" -> out.add(st(if (r() < 0.5f) 0f else 1f, r() * 0.8f, "pelan", "zigzag", 4f + r() * 3f, if (r() < 0.5f) "usil" else "malu", if (r() < 0.3f) "Apa itu ya?" else ""))
                else -> out.add(st(clamp(fx + (r() - 0.5f) * 0.4f, 0f, 1f), clamp(fy + (r() - 0.5f) * 0.3f, 0f, 1f), "pelan", "zigzag", 2f + r() * 2f, "bingung", if (r() < 0.3f) "Tadi ke mana ya?" else ""))
            }
        }
        return out
    }

    private fun parsePlan(text: String?): ArrayList<Step>? {
        if (text == null) return null
        val a = text.indexOf('[')
        val b = text.lastIndexOf(']')
        if (a < 0 || b <= a) return null
        return try {
            val arr = JSONArray(text.substring(a, b + 1))
            val out = ArrayList<Step>()
            for (i in 0 until min(6, arr.length())) {
                val o = arr.optJSONObject(i) ?: continue
                val x = o.optDouble("x", Double.NaN)
                val yy = o.optDouble("y", Double.NaN)
                if (x.isNaN() || yy.isNaN()) continue
                var gaya = o.optString("gaya", "biasa")
                if (gaya !in arrayOf("pelan", "biasa", "cepat", "loncat", "melayang")) gaya = "biasa"
                var jalur = o.optString("jalur", "lurus")
                if (jalur !in arrayOf("lurus", "lengkung", "zigzag", "melingkar")) jalur = "lurus"
                val jeda = o.optDouble("jeda", 2.0).let { if (it.isNaN()) 2.0 else it }
                val emo = o.optString("emosi", "").let { if (emoAct(it) != null) it else null }
                val kata = o.optString("kata", "").replace(Regex("[*_`#\"\\[\\]{}]"), "").trim().take(36)
                out.add(st(clamp(x.toFloat(), 0f, 1f), clamp(yy.toFloat(), 0f, 1f), gaya, jalur, clamp(jeda.toFloat(), 0.8f, 8f), emo, kata))
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun requestPlan() {
        val now = SystemClock.uptimeMillis()
        if (planning || now < nextPlan) return
        planning = true
        nextPlan = now + 20000L
        val fx = clamp((ox - x0()) / max(1f, x1() - x0()), 0f, 1f)
        val fy = clamp((y - y0()) / max(1f, y1() - y0()), 0f, 1f)
        val prompt = "Kamu dalang gerak " + host.robotName() + ", robot kecil yang sedang jalan-jalan bebas di layar HP (peta: x 0 kiri sampai 1 kanan, y 0 atas sampai 1 batas bawah). " +
            "Dia penasaran, lincah, dan sedikit usil seperti anak kucing, jadi geraknya harus terasa hidup dan tidak berpola.\n" +
            "Posisi sekarang x=" + String.format("%.2f", fx) + " y=" + String.format("%.2f", fy) + ". Baterai " + Math.round(bat) +
            " persen. Dia harus pulang mengisi baterai kalau tinggal 5 persen. Suasana hati " + Math.round(host.mood()) + " dari 100. Layar depan: " + host.category() + ".\n" +
            "Buat 5 langkah gerak berurutan. Variasikan gaya dan jalur, jangan semuanya jauh, sesekali berhenti lama untuk melihat-lihat. Keluarkan HANYA JSON array tanpa teks lain. " +
            "Tiap langkah: {\"x\":0-1,\"y\":0-1,\"gaya\":\"pelan|biasa|cepat|loncat|melayang\",\"jalur\":\"lurus|lengkung|zigzag|melingkar\",\"jeda\":1-8," +
            "\"emosi\":\"senang|penasaran|usil|semangat|santai|ngantuk|kaget|malu|bingung|suka\",\"kata\":\"opsional, maksimal 5 kata bahasa Indonesia\"}"
        host.ask(prompt) { text ->
            planning = false
            val pl = parsePlan(text)
            if (pl != null && pl.isNotEmpty() && mode == OUT) {
                plan.clear(); plan.addAll(pl)
            }
        }
    }

    private fun nextStep(now: Long) {
        if (confused && plan.isEmpty()) {
            plan.add(Step(0f, 0f, ox + (rnd.nextFloat() - 0.5f) * 60f * U, y + (rnd.nextFloat() - 0.35f) * 44f * U, true, "pelan", "zigzag", 2f + rnd.nextFloat() * 2.5f, "bingung", if (confN++ % 3 == 0) pick(*CONF_LINES) else ""))
        }
        if (plan.isEmpty()) plan.addAll(procPlan())
        if (plan.size <= 2 && !confused) requestPlan()
        val s = plan.removeAt(0)
        var p1x: Float
        var p1y: Float
        if (s.abs) { p1x = s.ax; p1y = s.ay } else { p1x = lerp(x0(), x1(), s.fx); p1y = lerp(y0() + dp(6f), y1(), s.fy) }
        p1x = clamp(p1x, x0(), x1()); p1y = clamp(p1y, y0(), y1())
        val dist = hypot(p1x - ox, p1y - y)
        val sp = spd(s.gaya) * U
        cur = Cur(s, ox, y, p1x, p1y, dist, max(900f, dist / sp * 1000f), now, 0, if (rnd.nextBoolean()) -1 else 1, max(1, Math.round(dist / (48f * U))))
        val act = emoAct(s.emosi)
        if (act != null && rnd.nextFloat() < 0.85f) host.play(act)
        if (s.kata.isNotEmpty()) host.say(s.kata)
    }

    private fun pathPos(c: Cur, u: Float, now: Long, out: FloatArray) {
        val e = if (c.s.gaya == "cepat") easeIO(u) else if (c.s.gaya == "loncat") u else easeSine(u)
        val dx = c.p1x - c.p0x
        val dy = c.p1y - c.p0y
        val len = max(1f, c.dist)
        val nx = -dy / len
        val ny = dx / len
        var x = c.p0x + dx * e
        var yy = c.p0y + dy * e
        var off = 0f
        when (c.s.jalur) {
            "lengkung" -> off = sin(PI.toFloat() * e) * min(46f * U, len * 0.28f) * c.side
            "zigzag" -> off = sin(e * TAU * 3f) * min(14f * U, len * 0.14f) * sin(PI.toFloat() * min(1f, e * 1.1f))
            "melingkar" -> {
                val vx0 = c.p0x - c.p1x
                val vy0 = c.p0y - c.p1y
                val ph = e * TAU * 0.8f * c.side
                val k = 1f - e
                x = c.p1x + (vx0 * cos(ph) - vy0 * sin(ph)) * k
                yy = c.p1y + (vx0 * sin(ph) + vy0 * cos(ph)) * k
            }
        }
        x += nx * off; yy += ny * off
        if (c.s.gaya == "loncat") yy -= abs(sin(PI.toFloat() * u * c.hops)) * 16f * U * sin(PI.toFloat() * min(1f, u * 1.05f))
        if (c.s.gaya == "melayang") { yy += sin(now / 420f) * 4f * U; x += sin(now / 610f) * 2.5f * U }
        out[0] = x; out[1] = yy
    }

    private val tmp = FloatArray(2)

    // ---------- pembaruan per frame ----------

    private fun update(now: Long, dt: Float) {
        if (host.blocked()) {
            if (mode != DOCKED) snapHome()
            pushView()
            return
        }
        val px0 = ox
        val py0 = y
        vis += ((if (mode == DOCKED) 0f else 1f) - vis) * (1f - exp(-dt * 4f))
        flash = max(0f, flash - dt * 4f)
        // ayunan colokan
        run {
            val n = max(1, Math.ceil(dt / 0.01).toInt())
            val hh = dt / n
            val wf = windForce(now, dt)
            for (i in 0 until n) {
                thv += (-45f * sin(th) - 2.4f * thv + wf) * hh
                th += thv * hh
            }
        }
        val dY = dockY()
        when (mode) {
            DOCKED -> {
                ox = 0f; y = dY; headAttach = 1f; th = 0f; thv = 0f
                bat = min(100f, bat + dt * 100f / 150f)
                if (dead && reviveAt != 0L && now >= reviveAt) {
                    dead = false; reviveAt = 0L
                    host.setDead(false)
                    host.play(Act.REVIVE)
                    host.say("Aku di mana? Oh, sudah dicolok. Makasih ya!")
                }
                if (!dead) schedTick()
            }
            LEAVING -> {
                leaveVy += ((dY + dp(22f) - y) * 70f - leaveVy * 8f) * dt
                y += leaveVy * dt
                if (now - t0 > 1100L) {
                    mode = OUT; outAt = now; plan.clear(); cur = null; nextPlan = 0L; confused = true
                }
            }
            OUT -> {
                bat = max(0f, bat - dt * 0.3167f - (if (dragging) min(1f, hypot(vx, vy) / (200f * U)) * 0.1f * dt else 0f))
                if (confused && now - outAt > 45000L) endConfused(false)
                if (bat <= 0f) die()
                else if (bat <= 5f) returnHome("low")
                if (mode == OUT) {
                    if (dragging) {
                        val k = 1f - exp(-dt * 14f)
                        ox += (dragTx - ox) * k; y += (dragTy - y) * k; cur = null
                    } else if (now < dizzyUntil) {
                        ox += sin(now / 70f) * 0.25f * U; y += cos(now / 90f) * 0.2f * U
                    } else if (now < holdUntil) {
                        ox += glx * dt; y += gly * dt
                        val d = exp(-dt * 3.2f); glx *= d; gly *= d
                    } else {
                        if (cur == null) nextStep(now)
                        val c = cur!!
                        if (c.phase == 0) {
                            val u = (now - c.t0) / c.dur
                            if (u >= 1f) {
                                c.phase = 1; c.pt0 = now; c.fid = now + 900L; ox = c.p1x; y = c.p1y
                            } else {
                                pathPos(c, u, now, tmp)
                                ox = tmp[0]; y = tmp[1] + sin(now / 380f) * 0.8f * U
                            }
                        } else {
                            ox = c.p1x + sin(now / 700f) * 1.6f * U
                            y = c.p1y + sin(now / 530f + 1f) * 2.2f * U
                            if (now >= c.fid) {
                                c.fid = now + 2500L + rnd.nextInt(2000)
                                if (rnd.nextInt(3) == 0 && !host.busy()) host.play(arrayOf(Act.WINK, Act.NOD, Act.SHAKE)[rnd.nextInt(3)])
                            }
                            if (now - c.pt0 >= c.s.jeda * 1000f) cur = null
                        }
                    }
                }
            }
            RETURNING -> {
                val hx = hookX()
                val hy = hookY()
                val tx = hx
                val ty = hy + dp(3f)
                val dx = tx - ox
                val dy = ty - y
                val d = hypot(dx, dy)
                bat = max(0f, bat - dt * 0.3167f)
                if (bat <= 0f) die()
                else if (dragging) {
                    val k = 1f - exp(-dt * 14f)
                    ox += (dragTx - ox) * k; y += (dragTy - y) * k
                } else if (now < dizzyUntil) {
                    ox += sin(now / 70f) * 0.25f * U
                } else if (now < holdUntil) {
                    ox += glx * dt; y += gly * dt
                    val k = exp(-dt * 3.2f); glx *= k; gly *= k
                } else {
                    val sp = min((if (bat <= 2f) 40f else 80f) * U, d * 2.8f + 8f * U)
                    val wob = sin(now / 260f) * 9f * U * min(1f, max(0f, d - 20f * U) / (60f * U))
                    if (d > 0.01f) {
                        ox += (dx / d) * sp * dt + (-dy / d) * wob * dt
                        y += (dy / d) * sp * dt + (dx / d) * wob * dt
                    }
                    if (d < dp(4.5f)) startDock(now)
                }
            }
            DEAD -> {
                if (dragging) {
                    val k = 1f - exp(-dt * 14f)
                    ox += (dragTx - ox) * k; y += (dragTy - y) * k; deadY0 = y
                } else if (now < holdUntil) {
                    ox += glx * dt; y += gly * dt
                    val k = exp(-dt * 3.2f); glx *= k; gly *= k; deadY0 = y
                } else {
                    y += max(0f, deadY0 + 26f * U - y) * min(1f, dt * 1.2f)
                }
            }
            DOCKING -> {
                val hx = hookX()
                val hy = hookY()
                val u = (now - t0) / 800f
                if (!clicked) {
                    if (u < 0.6f) {
                        ox += (hx - ox) * (1f - exp(-dt * 6f))
                        y = lerp(dockY0, hy + dp(3f), easeSine(clamp(u / 0.6f, 0f, 1f)))
                        headAttach = 0f
                        if (bat <= 0f && !dead) die()
                    } else if (abs(hx - ox) < dp(4.5f)) {
                        clicked = true; ckX = ox; ckY = y; ckT = now; flash = 1f
                        Sfx.charger()
                    } else dockFail(now, hy)
                } else {
                    val v = clamp((now - ckT) / 320f, 0f, 1f)
                    val e = easeSine(v)
                    ox = lerp(ckX, 0f, e); y = lerp(ckY, dY, e); headAttach = e
                    if (v >= 1f) finishDock(now)
                }
            }
        }
        if (mode != DOCKED) {
            ox = clamp(ox, x0(), max(x0(), x1()))
            y = clamp(y, y0(), max(y0(), y1()))
        }
        // kecepatan dan kemiringan badan
        val ivx = (ox - px0) / dt
        val ivy = (y - py0) / dt
        val kv = 1f - exp(-dt * 8f)
        vx += (ivx - vx) * kv; vy += (ivy - vy) * kv
        val vu = vx / U
        val tgt = if (dragging) clamp(-vu * 0.0030f, -0.45f, 0.45f)
        else if (now < dizzyUntil) sin(now / 95f) * 0.2f
        else clamp(vu * 0.0018f, -0.2f, 0.2f)
        rotV += ((tgt - rot) * 70f - rotV * 9f) * dt
        rot += rotV * dt
        if (mode == DOCKED) { rot *= 0.8f; rotV *= 0.8f }
        val lk = 1f - exp(-dt * 6f)
        lookX += (clamp(vu / 60f, -1f, 1f) - lookX) * lk
        lookY += (clamp(vy / U / 60f, -1f, 1f) - lookY) * lk
        pushView()
    }

    private fun pushView() {
        val dY = dockY()
        if (mode == DOCKED && !dead && vis < 0.02f && bat >= 99.5f && abs(y - dY) < 0.5f) {
            overlay.roamPose(0, dY.toInt(), 0f, bat, 0f, dead, false, 0f, 0f)
        } else {
            overlay.roamPose(ox.toInt(), y.toInt(), Math.toDegrees(rot.toDouble()).toFloat(), bat, vis, dead, confused && mode == OUT, lookX, lookY)
        }
        // kepala colokan: menggantung, atau menyatu dengan pill saat terpasang
        val k = headAttach
        val hx = lerp(hookX(), 0f, k)
        val hy = lerp(hookY(), dockY() - dp(1.5f), k)
        plug.update(th, k, hx, hy, mode == DOCKED && bat < 99.5f, mode == DOCKED, flash)
    }

    // ---------- geser dengan jari ----------

    /** Dipanggil saat jari menyentuh robot. Mengembalikan true kalau robot sedang boleh digeser. */
    fun grab(rawX: Float, rawY: Float): Boolean {
        if (mode != OUT && mode != RETURNING && mode != DEAD) return false
        grabbed = true
        gStartX = rawX; gStartY = rawY
        gx = ox - (rawX - sw / 2f); gy = y - rawY
        return true
    }

    fun dragMove(rawX: Float, rawY: Float) {
        if (!grabbed) return
        val now = SystemClock.uptimeMillis()
        if (!dragging) {
            if (hypot(rawX - gStartX, rawY - gStartY) < dp(8f)) return
            dragging = true
            turnHas = false; turnAcc = 0f; turnPx = rawX / U; turnPy = rawY / U
            Sfx.ping()
            host.play(Act.SURPRISE)
            if (confused) endConfused(true)
        }
        dragTx = clamp(rawX - sw / 2f + gx, x0(), max(x0(), x1()))
        dragTy = clamp(rawY + gy, y0(), max(y0(), y1()))
        // deteksi diputar-putar: jumlahkan perubahan arah gerak jari
        val wx = rawX / U
        val wy = rawY / U
        val mvx = wx - turnPx
        val mvy = wy - turnPy
        if (hypot(mvx, mvy) > 3f) {
            val ang = atan2(mvy, mvx)
            if (turnHas) {
                var da = ang - turnAng
                while (da > PI) da -= TAU
                while (da < -PI) da += TAU
                turnAcc = turnAcc * exp(-(now - turnT) / 1000f * 0.45f) + da
            }
            turnAng = ang; turnHas = true; turnT = now; turnPx = wx; turnPy = wy
            if (abs(turnAcc) > TAU * 1.1f && now > dizzyUntil) {
                turnAcc = 0f
                dizzyUntil = now + 5200L
                bat = max(0f, bat - 6f)
                host.play(Act.DIZZY)
            }
        }
    }

    fun release() {
        if (!grabbed) return
        grabbed = false
        if (!dragging) return
        dragging = false
        val now = SystemClock.uptimeMillis()
        glx = clamp(vx, -120f * U, 120f * U) * 0.5f
        gly = clamp(vy, -120f * U, 120f * U) * 0.5f
        holdUntil = now + 1000L
        cur = null
        Sfx.tick()
        if (mode == DEAD && hypot(ox - hookX(), y - (hookY() + dp(3f))) < dp(40f)) {
            dockY0 = y; startDock(now); return
        }
        if (mode == OUT && hypot(ox, y - (dockY() + dp(14f))) < dp(40f)) {
            mode = RETURNING; plan.clear()
            host.say("Wah, kamu antar aku pulang. Makasih!")
        }
    }
}
