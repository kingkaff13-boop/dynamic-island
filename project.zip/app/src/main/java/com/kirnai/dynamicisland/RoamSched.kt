package com.kirnai.dynamicisland

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Random

/**
 * Jadwal rahasia: 5 kali sehari robot cabut dari colokan. Hanya robot yang tahu.
 * Yang ditampilkan di aplikasi hanyalah ramalan yang sengaja sering meleset.
 */
class RoamSched(val day: String, val times: LongArray, val pred: LongArray, val done: IntArray, val at: LongArray) {

    fun toJson(): String {
        val o = JSONObject()
        o.put("day", day)
        o.put("times", JSONArray(times.toList()))
        o.put("pred", JSONArray(pred.toList()))
        o.put("done", JSONArray(done.toList()))
        o.put("at", JSONArray(at.toList()))
        return o.toString()
    }

    companion object {
        fun dayKey(): String {
            val c = Calendar.getInstance()
            return "${c.get(Calendar.YEAR)}-${c.get(Calendar.MONTH) + 1}-${c.get(Calendar.DAY_OF_MONTH)}"
        }

        fun hhmm(ms: Long): String {
            val c = Calendar.getInstance()
            c.timeInMillis = ms
            return String.format("%02d.%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        }

        /** Membaca jadwal hari ini; membuat yang baru kalau belum ada atau sudah ganti hari. */
        fun load(prefs: SharedPreferences): RoamSched {
            val key = dayKey()
            try {
                val raw = prefs.getString(KEY_ROAM_SCHED, null)
                if (raw != null) {
                    val o = JSONObject(raw)
                    if (o.getString("day") == key && o.getJSONArray("times").length() == 5) {
                        fun la(n: String): LongArray { val a = o.getJSONArray(n); return LongArray(a.length()) { a.getLong(it) } }
                        val d = o.getJSONArray("done")
                        return RoamSched(key, la("times"), la("pred"), IntArray(d.length()) { d.getInt(it) }, la("at"))
                    }
                }
            } catch (e: Exception) {
            }
            val s = generate(key)
            prefs.edit().putString(KEY_ROAM_SCHED, s.toJson()).apply()
            return s
        }

        fun save(prefs: SharedPreferences, s: RoamSched) {
            prefs.edit().putString(KEY_ROAM_SCHED, s.toJson()).apply()
        }

        private fun generate(key: String): RoamSched {
            val rnd = Random()
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            val base = cal.timeInMillis
            val hour = 3600_000L
            val start = base + (6.5 * hour).toLong()
            val win = (17 * hour) / 5
            val times = LongArray(5)
            val done = IntArray(5)
            val at = LongArray(5)
            val preds = LongArray(5)
            val now = System.currentTimeMillis()
            for (i in 0 until 5) {
                val t = start + i * win + ((0.1 + 0.8 * rnd.nextDouble()) * win).toLong()
                times[i] = t
                done[i] = if (t < now) 2 else 0
                val r = rnd.nextDouble()
                val sg = if (rnd.nextBoolean()) -1 else 1
                val err = if (r < 0.15) rnd.nextDouble() * 12 - 6 else if (r < 0.45) sg * (8 + rnd.nextDouble() * 21) else sg * (30 + rnd.nextDouble() * 110)
                val p = t + (err * 60_000).toLong()
                preds[i] = p.coerceIn(base + 6 * hour, base + (23.9 * hour).toLong())
            }
            preds.sort()
            return RoamSched(key, times, preds, done, at)
        }
    }
}
