package com.kirnai.dynamicisland

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Pill hitam di bagian atas layar yang melebar saat ada notifikasi.
 * Semua fungsi harus dipanggil dari main thread.
 */
class IslandOverlay(private val ctx: Context, private val useA11y: Boolean = false) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val density = ctx.resources.displayMetrics.density

    private fun dp(v: Int): Int = (v * density).toInt()
    private fun lerp(a: Int, b: Int, f: Float): Int = (a + (b - a) * f).toInt()

    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }

    private val iconView = ImageView(ctx).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        setColorFilter(Color.WHITE)
    }

    private val titleView = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private val subView = TextView(ctx).apply {
        setTextColor(Color.parseColor("#B3FFFFFF"))
        textSize = 12f
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private val content = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), 0, dp(16), 0)
        alpha = 0f
        addView(iconView, LinearLayout.LayoutParams(dp(28), dp(28)))
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView)
            addView(subView)
        }
        val colLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        colLp.marginStart = dp(12)
        addView(col, colLp)
    }

    private val root = FrameLayout(ctx).apply {
        background = bg
        addView(
            content,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
    }

    private var params: WindowManager.LayoutParams? = null
    private var attached = false
    private var fraction = 0f
    private var animator: ValueAnimator? = null

    private fun idleW() = dp(prefs.getInt(KEY_W, 110))
    private fun idleH() = dp(prefs.getInt(KEY_H, 32))
    private fun expW(): Int {
        val screenW = ctx.resources.displayMetrics.widthPixels
        return minOf(screenW - dp(24), dp(360))
    }
    private fun expH() = dp(68)
    private fun idleVisible() = prefs.getBoolean(KEY_IDLE, true)

    private val collapseRunnable = Runnable {
        animateTo(0f) {
            if (!idleVisible()) root.visibility = View.GONE
        }
    }

    fun show() {
        if (attached) {
            applySettings()
            return
        }
        if (!useA11y && !Settings.canDrawOverlays(ctx)) return

        val lp = WindowManager.LayoutParams(
            idleW(),
            idleH(),
            if (useA11y) {
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(prefs.getInt(KEY_TOP, 8))
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        params = lp
        fraction = 0f
        content.alpha = 0f
        bg.cornerRadius = idleH() / 2f
        root.visibility = if (idleVisible()) View.VISIBLE else View.GONE

        try {
            wm.addView(root, lp)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    fun hide() {
        handler.removeCallbacks(collapseRunnable)
        animator?.cancel()
        if (attached) {
            try {
                wm.removeView(root)
            } catch (e: Exception) {
            }
            attached = false
        }
        fraction = 0f
    }

    /** Dipanggil setelah pengaturan (posisi/ukuran/idle) berubah. */
    fun applySettings() {
        val lp = params ?: return
        if (!attached) return
        lp.y = dp(prefs.getInt(KEY_TOP, 8))
        if (fraction == 0f) {
            root.visibility = if (idleVisible()) View.VISIBLE else View.GONE
        }
        applyFraction(fraction)
    }

    fun showMessage(title: CharSequence?, text: CharSequence?, icon: Drawable?) {
        if (!attached) return
        handler.removeCallbacks(collapseRunnable)
        iconView.setImageDrawable(icon)
        iconView.visibility = if (icon == null) View.GONE else View.VISIBLE
        titleView.text = title ?: ""
        subView.text = text ?: ""
        root.visibility = View.VISIBLE
        animateTo(1f)
        handler.postDelayed(collapseRunnable, 4500)
    }

    private fun applyFraction(f: Float) {
        val lp = params ?: return
        fraction = f
        lp.width = lerp(idleW(), expW(), f)
        lp.height = lerp(idleH(), expH(), f)
        bg.cornerRadius = minOf(lp.height / 2f, dp(34).toFloat())
        content.alpha = ((f - 0.5f) / 0.5f).coerceIn(0f, 1f)
        if (attached) {
            try {
                wm.updateViewLayout(root, lp)
            } catch (e: Exception) {
            }
        }
    }

    private fun animateTo(target: Float, onEnd: (() -> Unit)? = null) {
        animator?.cancel()
        val a = ValueAnimator.ofFloat(fraction, target)
        a.duration = 350
        a.interpolator = if (target > fraction) {
            OvershootInterpolator(0.9f)
        } else {
            AccelerateDecelerateInterpolator()
        }
        a.addUpdateListener { applyFraction(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) onEnd?.invoke()
            }
        })
        animator = a
        a.start()
    }
}
