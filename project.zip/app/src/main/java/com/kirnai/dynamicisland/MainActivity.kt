package com.kirnai.dynamicisland

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.Manifest
import android.content.pm.PackageManager
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }

        col.addView(makeText("Robot Island", 26f, true))
        status = makeText("", 14f, false)
        status.setPadding(0, dp(8), 0, dp(8))
        col.addView(status)

        col.addView(makeButton("1. Aktifkan robot (Aksesibilitas)") {
            openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        col.addView(makeSwitch("Aktifkan robot", KEY_ENABLED, true))
        col.addView(makeSwitch("Robot bisa diketuk (ketuk = bereaksi, tahan = nari)", KEY_TOUCH, true))
        col.addView(makeSwitch("Pengingat senam mata", KEY_BREAK, true))

        col.addView(makeSlider("Senam mata tiap", KEY_BREAK_MIN, 20, 1, 60) { "$it menit" })
        col.addView(
            makeSlider("Keaktifan robot", KEY_ACTIVITY, 1, 0, 2) {
                arrayOf("Jarang", "Sedang", "Sering")[it]
            }
        )
        col.addView(makeSlider("Jarak dari atas", KEY_TOP, 4, 0, 80) { "$it dp" })
        col.addView(makeSlider("Lebar pill", KEY_W, 115, 80, 220) { "$it dp" })
        col.addView(makeSlider("Tinggi pill", KEY_H, 32, 20, 50) { "$it dp" })

        val demoTitle = makeText("Coba aksi robot", 16f, true)
        demoTitle.setPadding(0, dp(20), 0, dp(4))
        col.addView(demoTitle)
        col.addView(actRow("Senang" to Act.HAPPY, "Sedih" to Act.SAD, "Ngantuk" to Act.SLEEPY))
        col.addView(actRow("Kaget" to Act.SURPRISE, "Kedip" to Act.WINK, "Ketawa" to Act.LAUGH))
        col.addView(actRow("Kepanasan" to Act.HOT, "Foto" to Act.PHOTO, "Nari" to Act.DANCE))
        col.addView(actRow("Senam mata 20 detik" to Act.EXERCISE, "Menyapa" to Act.HELLO))
        col.addView(actRow("Marah" to Act.ANGRY, "Kesal" to Act.ANNOYED, "Bingung" to Act.CONFUSED))
        col.addView(actRow("Ngintip" to Act.PEEK, "Pusing" to Act.DIZZY, "Headset" to Act.HEADSET))

        col.addView(sectionTitle("Suara"))
        col.addView(makeSwitch("Suara robot", KEY_SOUND, true))
        col.addView(makeSlider("Volume suara", KEY_VOL, 70, 0, 100) { "$it%" })

        col.addView(sectionTitle("Musik dan notifikasi"))
        col.addView(
            makeText(
                "Robot ikut bergoyang saat ada musik atau video: semangat, sedih, atau bingung (mata menyipit dengan tanda tanya). " +
                    "Ini perkiraan dari irama dan butuh izin Rekam audio. Suara tidak direkam atau disimpan.\n" +
                    "Kalau banyak notifikasi masuk, robot jadi pusing. Robot hanya menghitung jumlahnya, isinya tidak dibaca.",
                13f,
                false
            )
        )
        col.addView(makeMusicSwitch())
        col.addView(makeSwitch("Robot pusing saat banyak notifikasi", KEY_NOTIF, true))
        col.addView(makeButton("Beri akses notifikasi (hitung jumlah saja)") {
            openSettings(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        col.addView(sectionTitle("Game dengan robot"))
        col.addView(
            makeText(
                "Ikuti mataku: lihat ke arah mana mata robot menoleh, lalu tekan tombol arah yang sama, urut dari yang pertama. " +
                    "Suit: pilih batu, kertas, atau gunting setelah menekan Mulai suit.",
                13f,
                false
            )
        )
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(makeButton("Mulai ikuti mataku") { withSvc { it.gameAction(1, 0) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(makeButton("Mulai suit") { withSvc { it.gameAction(3, 0) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(makeButton("Stop") { withSvc { it.gameAction(0, 0) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        )
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val names = arrayOf("Atas", "Kanan", "Bawah", "Kiri")
                for (d in 0..3) {
                    addView(makeButton(names[d]) { withSvc { it.gameAction(2, d) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
            }
        )
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val names = arrayOf("Batu", "Kertas", "Gunting")
                for (d in 0..2) {
                    addView(makeButton(names[d]) { withSvc { it.gameAction(4, d) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
            }
        )

        col.addView(sectionTitle("Mancing"))
        col.addView(
            makeText(
                "Nyalakan saat kamu menonton video laut atau air. Robot memancing di bawah pill, " +
                    "ikannya makin besar tiap 25 detik, dan talinya bisa putus kalau ikannya terlalu besar. " +
                    "Saat mancing, layar di bawah pill tetap bisa disentuh.",
                13f,
                false
            )
        )
        col.addView(makeButton("Mulai mancing") { withSvc { it.setFishing(true) } })
        col.addView(makeButton("Ikan lebih besar (uji)") { withSvc { it.fishLevelUp() } })
        col.addView(makeButton("Berhenti mancing") { withSvc { it.setFishing(false) } })

        col.addView(sectionTitle("Timer fokus"))
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                for (m in intArrayOf(5, 15, 25)) {
                    addView(
                        makeButton("$m menit") { withSvc { it.startFocus(m) } },
                        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    )
                }
                addView(
                    makeButton("Stop") { withSvc { it.stopFocus() } },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                )
            }
        )

        col.addView(sectionTitle("Pengingat sholat"))
        col.addView(makeSwitch("Robot mengingatkan waktu sholat (bunyi lonceng lembut)", KEY_PRAY, true))
        col.addView(makeCitySpinner())

        col.addView(sectionTitle("Kejadian HP"))
        col.addView(makeSwitch("Bereaksi pada charger, Wi-Fi, headset, volume, senter, mode pesawat, goyang, HP telungkup", KEY_EVENTS, true))

        col.addView(sectionTitle("Gaya robot"))
        col.addView(styleRow("Warna", KEY_COLOR, arrayOf("Cyan", "Hijau", "Ungu", "Pink", "Oranye", "Putih", "Pelangi")))
        col.addView(styleRow("Mata", KEY_SHAPE, arrayOf("Kapsul", "Kotak", "Bulat")))
        col.addView(makeNameBox())

        val tips = makeText(
            "Tips:\n" +
                "• Aktifkan di Aksesibilitas → Aplikasi yang didownload → Robot Island. " +
                "Layanan ini hanya dipakai untuk menggambar robot di atas status bar, " +
                "tidak membaca layar.\n" +
                "• Jika tombol layanan abu-abu: Info aplikasi → titik tiga kanan atas → " +
                "Izinkan setelan terbatas.\n" +
                "• HyperOS/Xiaomi: aktifkan Mulai otomatis, atur Hemat baterai ke " +
                "Tanpa batasan, dan kunci aplikasi di layar Recent supaya tidak dimatikan sistem.\n" +
                "• Geser Jarak, Lebar, dan Tinggi sampai pill pas menutupi kamera depan.\n" +
                "• Robot ikut bereaksi saat charger dicolok, baterai rendah, HP panas, " +
                "Wi-Fi, headset, volume, senter (mata jadi terang), mode pesawat (pesawat lewat di belakang mata), " +
                "HP digoyang (pusing), dan HP ditelungkupkan (mengintip).\n" +
                "• Reaksi musik dan banjir notifikasi butuh izin (lihat bagian masing-masing di atas).",
            13f,
            false
        )
        tips.setPadding(0, dp(16), 0, 0)
        col.addView(tips)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        IslandAccessibility.instance?.refresh()
    }

    private fun updateStatus() {
        val enabled =
            Settings.Secure.getString(contentResolver, "enabled_accessibility_services") ?: ""
        val ok = enabled.contains(packageName)
        status.text = "Aksesibilitas: " + (if (ok) "✓ aktif" else "✗ belum diaktifkan")
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Tidak bisa membuka pengaturan, buka manual lewat menu Aksesibilitas")
        }
    }

    private fun makeMusicSwitch(): Switch =
        Switch(this).apply {
            text = "Robot bereaksi ke musik"
            isChecked = prefs.getBoolean(KEY_MUSIC, false) &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { btn, checked ->
                if (checked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
                    btn.isChecked = false
                } else {
                    prefs.edit().putBoolean(KEY_MUSIC, checked).apply()
                    IslandAccessibility.instance?.refresh()
                }
            }
        }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean(KEY_MUSIC, true).apply()
            IslandAccessibility.instance?.refresh()
            recreate()
        }
    }

    private fun withSvc(f: (IslandAccessibility) -> Unit) {
        val svc = IslandAccessibility.instance
        if (svc == null) toast("Aksesibilitas belum aktif") else f(svc)
    }

    private fun sectionTitle(label: String): TextView {
        val t = makeText(label, 16f, true)
        t.setPadding(0, dp(22), 0, dp(4))
        return t
    }

    private fun makeCitySpinner(): View {
        val sp = Spinner(this)
        val names = Prayer.cities.map { it.name }
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(prefs.getInt(KEY_CITY, 0).coerceIn(0, names.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                prefs.edit().putInt(KEY_CITY, pos).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    private fun styleRow(label: String, key: String, options: Array<String>): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val caption = makeText("$label: ${options[prefs.getInt(key, 0).coerceIn(0, options.size - 1)]}", 14f, false)
        box.addView(caption)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in options.indices) {
            val b = makeButton(options[i]) {
                prefs.edit().putInt(key, i).apply()
                caption.text = "$label: ${options[i]}"
                IslandAccessibility.instance?.refresh()
            }
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val scroll = android.widget.HorizontalScrollView(this)
        scroll.addView(row)
        box.addView(scroll)
        return box
    }

    private fun makeNameBox(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val et = EditText(this)
        et.setText(prefs.getString(KEY_NAME, "Beepo"))
        et.hint = "Nama robot"
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(makeButton("Simpan") {
            val v = et.text.toString().trim().take(8)
            if (v.isNotEmpty()) {
                prefs.edit().putString(KEY_NAME, v).apply()
                IslandAccessibility.instance?.refresh()
                IslandAccessibility.instance?.play(Act.HELLO)
            }
        })
        return row
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun makeText(label: String, size: Float, bold: Boolean): TextView =
        TextView(this).apply {
            text = label
            textSize = size
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun makeButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun actRow(vararg items: Pair<String, Act>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((label, act) in items) {
            val b = makeButton(label) {
                val svc = IslandAccessibility.instance
                if (svc == null) {
                    toast("Aksesibilitas belum aktif")
                } else {
                    svc.refresh()
                    svc.play(act)
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        return row
    }

    private fun makeSwitch(label: String, key: String, def: Boolean): Switch =
        Switch(this).apply {
            text = label
            isChecked = prefs.getBoolean(key, def)
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                IslandAccessibility.instance?.refresh()
            }
        }

    private fun makeSlider(
        label: String,
        key: String,
        def: Int,
        lo: Int,
        hi: Int,
        fmt: (Int) -> String
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val value = prefs.getInt(key, def).coerceIn(lo, hi)
        val caption = makeText("$label: ${fmt(value)}", 14f, false)
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = value - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                caption.text = "$label: ${fmt(v)}"
                prefs.edit().putInt(key, v).apply()
                IslandAccessibility.instance?.refresh()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(caption)
        box.addView(bar)
        return box
    }
}
