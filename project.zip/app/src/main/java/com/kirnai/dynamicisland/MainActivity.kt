package com.kirnai.dynamicisland

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }

        col.addView(makeText("Robot Island", 26f, true))
        status = makeText("", 14f, false)
        status.setPadding(0, dp(8), 0, dp(8))
        col.addView(status)

        col.addView(makeButton("1. Aktifkan robot (Aksesibilitas)") {
            openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        col.addView(makeSwitch("Aktifkan robot", KEY_ENABLED, true))
        col.addView(makeSwitch("Robot bisa diketuk (ketuk = bereaksi, tahan = nari)", KEY_TOUCH, true))
        col.addView(makeSwitch("Pengingat senam mata", KEY_BREAK, true))

        col.addView(makeSlider("Senam mata tiap", KEY_BREAK_MIN, 20, 1, 60) { "$it menit" })
        col.addView(
            makeSlider("Keaktifan robot", KEY_ACTIVITY, 1, 0, 2) {
                arrayOf("Jarang", "Sedang", "Sering")[it]
            }
        )
        col.addView(makeSlider("Jarak dari atas", KEY_TOP, 4, 0, 80) { "$it dp" })
        col.addView(makeSlider("Lebar pill", KEY_W, 115, 80, 220) { "$it dp" })
        col.addView(makeSlider("Tinggi pill", KEY_H, 32, 20, 50) { "$it dp" })

        val demoTitle = makeText("Coba aksi robot", 16f, true)
        demoTitle.setPadding(0, dp(20), 0, dp(4))
        col.addView(demoTitle)
        col.addView(actRow("Senang" to Act.HAPPY, "Sedih" to Act.SAD, "Ngantuk" to Act.SLEEPY))
        col.addView(actRow("Kaget" to Act.SURPRISE, "Kedip" to Act.WINK, "Ketawa" to Act.LAUGH))
        col.addView(actRow("Kepanasan" to Act.HOT, "Foto" to Act.PHOTO, "Nari" to Act.DANCE))
        col.addView(actRow("Senam mata 20 detik" to Act.EXERCISE))

        val tips = makeText(
            "Tips:\n" +
                "• Aktifkan di Aksesibilitas → Aplikasi yang didownload → Robot Island. " +
                "Layanan ini hanya dipakai untuk menggambar robot di atas status bar, " +
                "tidak membaca layar.\n" +
                "• Jika tombol layanan abu-abu: Info aplikasi → titik tiga kanan atas → " +
                "Izinkan setelan terbatas.\n" +
                "• HyperOS/Xiaomi: aktifkan Mulai otomatis, atur Hemat baterai ke " +
                "Tanpa batasan, dan kunci aplikasi di layar Recent supaya tidak dimatikan sistem.\n" +
                "• Geser Jarak, Lebar, dan Tinggi sampai pill pas menutupi kamera depan.\n" +
                "• Robot ikut bereaksi saat charger dicolok, baterai rendah, HP panas, " +
                "dan saat layar dinyalakan.",
            13f,
            false
        )
        tips.setPadding(0, dp(16), 0, 0)
        col.addView(tips)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        IslandAccessibility.instance?.refresh()
    }

    private fun updateStatus() {
        val enabled =
            Settings.Secure.getString(contentResolver, "enabled_accessibility_services") ?: ""
        val ok = enabled.contains(packageName)
        status.text = "Aksesibilitas: " + (if (ok) "✓ aktif" else "✗ belum diaktifkan")
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Tidak bisa membuka pengaturan, buka manual lewat menu Aksesibilitas")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun makeText(label: String, size: Float, bold: Boolean): TextView =
        TextView(this).apply {
            text = label
            textSize = size
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun makeButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun actRow(vararg items: Pair<String, Act>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((label, act) in items) {
            val b = makeButton(label) {
                val svc = IslandAccessibility.instance
                if (svc == null) {
                    toast("Aksesibilitas belum aktif")
                } else {
                    svc.refresh()
                    svc.play(act)
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        return row
    }

    private fun makeSwitch(label: String, key: String, def: Boolean): Switch =
        Switch(this).apply {
            text = label
            isChecked = prefs.getBoolean(key, def)
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                IslandAccessibility.instance?.refresh()
            }
        }

    private fun makeSlider(
        label: String,
        key: String,
        def: Int,
        lo: Int,
        hi: Int,
        fmt: (Int) -> String
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val value = prefs.getInt(key, def).coerceIn(lo, hi)
        val caption = makeText("$label: ${fmt(value)}", 14f, false)
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = value - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                caption.text = "$label: ${fmt(v)}"
                prefs.edit().putInt(key, v).apply()
                IslandAccessibility.instance?.refresh()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(caption)
        box.addView(bar)
        return box
    }
}
