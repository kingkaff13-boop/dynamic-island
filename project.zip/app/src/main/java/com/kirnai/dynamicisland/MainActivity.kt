package com.kirnai.dynamicisland

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }

        col.addView(makeText("Dynamic Island", 26f, true))
        status = makeText("", 14f, false)
        status.setPadding(0, dp(8), 0, dp(8))
        col.addView(status)

        col.addView(makeButton("1. Izinkan tampil di atas aplikasi lain") {
            openSettings(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(makeButton("2. Izinkan akses notifikasi") {
            openSettings(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        col.addView(makeSwitch("Aktifkan Dynamic Island", KEY_ENABLED, true))
        col.addView(makeSwitch("Tampilkan pill saat diam", KEY_IDLE, true))
        col.addView(makeSlider("Jarak dari atas", KEY_TOP, 8, 0, 80))
        col.addView(makeSlider("Lebar pill", KEY_W, 110, 60, 220))
        col.addView(makeSlider("Tinggi pill", KEY_H, 32, 20, 50))

        col.addView(makeButton("Tes tampilan") {
            val l = IslandListener.instance
            if (l == null) {
                toast("Akses notifikasi belum aktif")
            } else {
                l.refresh()
                l.demo()
            }
        })

        val tips = makeText(
            "Tips:\n" +
                "• Android 13 ke atas: jika tombol akses notifikasi abu-abu, buka Info aplikasi → " +
                "titik tiga di kanan atas → Izinkan setelan terbatas, lalu ulangi langkah 2.\n" +
                "• HyperOS/Xiaomi: aktifkan Mulai otomatis untuk aplikasi ini, atur Hemat baterai " +
                "ke Tanpa batasan, dan kunci aplikasi di layar Recent supaya tidak dimatikan sistem.\n" +
                "• Geser Jarak dari atas, Lebar, dan Tinggi sampai pill pas menutupi kamera depan.",
            13f,
            false
        )
        tips.setPadding(0, dp(16), 0, 0)
        col.addView(tips)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        IslandListener.instance?.refresh()
    }

    private fun updateStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val enabledListeners =
            Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        val notifOk = enabledListeners.contains(packageName)
        status.text =
            "Tampil di atas aplikasi lain: " + (if (overlayOk) "✓ aktif" else "✗ belum") + "\n" +
                "Akses notifikasi: " + (if (notifOk) "✓ aktif" else "✗ belum")
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Tidak bisa membuka pengaturan, buka manual lewat Info aplikasi")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun makeText(label: String, size: Float, bold: Boolean): TextView =
        TextView(this).apply {
            text = label
            textSize = size
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun makeButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun makeSwitch(label: String, key: String, def: Boolean): Switch =
        Switch(this).apply {
            text = label
            isChecked = prefs.getBoolean(key, def)
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                IslandListener.instance?.refresh()
            }
        }

    private fun makeSlider(label: String, key: String, def: Int, lo: Int, hi: Int): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val value = prefs.getInt(key, def)
        val caption = makeText("$label: $value dp", 14f, false)
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = value - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                caption.text = "$label: $v dp"
                prefs.edit().putInt(key, v).apply()
                IslandListener.instance?.refresh()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(caption)
        box.addView(bar)
        return box
    }
}
