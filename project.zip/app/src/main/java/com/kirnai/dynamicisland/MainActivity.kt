package com.kirnai.dynamicisland

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.Manifest
import android.content.pm.PackageManager
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }

        col.addView(makeText("Robot Island", 26f, true))
        status = makeText("", 14f, false)
        status.setPadding(0, dp(8), 0, dp(8))
        col.addView(status)

        col.addView(makeButton("1. Aktifkan robot (Aksesibilitas)") {
            openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        col.addView(makeSwitch("Aktifkan robot", KEY_ENABLED, true))
        col.addView(makeSwitch("Robot bisa diketuk (ketuk = bereaksi, tahan = nari)", KEY_TOUCH, true))
        col.addView(makeSwitch("Pengingat senam mata", KEY_BREAK, true))

        col.addView(makeSlider("Senam mata tiap", KEY_BREAK_MIN, 20, 1, 60) { "$it menit" })
        col.addView(
            makeSlider("Keaktifan robot", KEY_ACTIVITY, 1, 0, 2) {
                arrayOf("Jarang", "Sedang", "Sering")[it]
            }
        )
        col.addView(makeSlider("Jarak dari atas", KEY_TOP, 4, 0, 80) { "$it dp" })
        col.addView(makeSlider("Lebar pill", KEY_W, 115, 80, 220) { "$it dp" })
        col.addView(makeSlider("Tinggi pill", KEY_H, 32, 20, 50) { "$it dp" })

        col.addView(sectionTitle("Asisten AI"))
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(makeButton("Aktifkan AI") { withSvc { it.setAi(true) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(makeButton("Matikan AI") { withSvc { it.setAi(false) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        )
        col.addView(makeText("Kunci Gemini dan pengaturan AI lain ada di bagian Asisten AI (Gemini) di bawah.", 13f, false))

        val demoTitle = makeText("Coba aksi robot", 16f, true)
        demoTitle.setPadding(0, dp(20), 0, dp(4))
        col.addView(demoTitle)
        col.addView(actRow("Senang" to Act.HAPPY, "Sedih" to Act.SAD, "Ngantuk" to Act.SLEEPY))
        col.addView(actRow("Kaget" to Act.SURPRISE, "Kedip" to Act.WINK, "Ketawa" to Act.LAUGH))
        col.addView(actRow("Kepanasan" to Act.HOT, "Foto" to Act.PHOTO, "Nari" to Act.DANCE))
        col.addView(actRow("Senam mata 20 detik" to Act.EXERCISE, "Menyapa" to Act.HELLO))
        col.addView(actRow("Marah" to Act.ANGRY, "Kesal" to Act.ANNOYED, "Bingung" to Act.CONFUSED))
        col.addView(actRow("Ngintip" to Act.PEEK, "Pusing" to Act.DIZZY, "Headset" to Act.HEADSET))
        col.addView(actRow("Menguap" to Act.YAWN, "Pagi" to Act.MORNING, "Kangen" to Act.MISS))
        col.addView(actRow("Bertemu lagi" to Act.REUNION, "Istirahat" to Act.REST, "Geli" to Act.TICKLE))
        col.addView(actRow("Kejar kutu" to Act.BUG, "Main bola" to Act.BALL, "Lempar kertas" to Act.TOSS))
        col.addView(actRow("Dielus" to Act.CUDDLE, "Lemas" to Act.WEAK, "Segar lagi" to Act.REVIVE))
        col.addView(
            makeText(
                "Cara bermain dengan robot: ketuk = bereaksi (makin sering makin kesal), tahan sebentar = nari, " +
                    "tahan lama = dielus, usap kiri-kanan cepat = geli, sentuh dengan dua jari = kaget. " +
                    "Kalau HP lama ditinggal, robot jadi kangen dan senang sekali saat kamu kembali. " +
                    "Pagi menyapa, malam mengantuk, dan setelah 45 menit pakai HP robot mengajak istirahat.",
                13f,
                false
            )
        )

        col.addView(actRow("Berpikir" to Act.PONDER, "Suka" to Act.LOVE, "Kagum" to Act.WOW))
        col.addView(actRow("Setuju" to Act.NOD, "Tidak" to Act.SHAKE, "Malu" to Act.SHY))
        col.addView(actRow("Khawatir" to Act.WORRY, "Semangat" to Act.EXCITED, "Usil" to Act.SMUG))
        col.addView(actRow("Lega" to Act.RELIEF, "Dapat ide" to Act.IDEA, "Canggung" to Act.AWKWARD))
        col.addView(
            makeText(
                "Ketukan robot (ditunggu 0,7 detik setelah ketukan terakhir): 1 sampai 3x = bereaksi, 4x = matikan robot " +
                    "(menguap, mata tutup, pill jadi titik redup; 3x untuk menyalakan lagi), 5x = nyalakan atau matikan asisten AI, " +
                    "6 sampai 7x = kesal, 8x atau lebih = marah.",
                13f,
                false
            )
        )

        col.addView(sectionTitle("Tampilan kaca"))
        col.addView(makeSwitch("Pill kaca cair (bening, berkilau)", KEY_GLASS, true))
        col.addView(makeSlider("Gelap kaca", KEY_GLASS_LVL, 55, 20, 95) { "$it%" })

        col.addView(sectionTitle("Asisten AI (Gemini)"))
        col.addView(
            makeText(
                "Ketuk robot 5x untuk menyalakan. Bicara ke robot, dia menjawab dengan suara dan sesekali bicara duluan. " +
                    "Isi kunci Gemini gratis dari aistudio.google.com. Kunci hanya tersimpan di HP ini. " +
                    "Yang dikirim ke Google hanya teks ucapanmu dan kategori aplikasi (misalnya 'game'), tidak pernah isi layar. " +
                    "Pada paket gratis, Google bisa memakai isinya untuk memperbaiki produk mereka dan peninjau manusia bisa membacanya, " +
                    "jadi jangan bicarakan hal rahasia.",
                13f,
                false
            )
        )
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(makeButton("Aktifkan AI") { withSvc { it.setAi(true) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(makeButton("Matikan AI") { withSvc { it.setAi(false) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        )
        col.addView(makeAiKeyBox())
        col.addView(styleRow("Seberapa cerewet", KEY_AI_TALK, arrayOf("Normal", "Pendiam", "Cerewet")))
        col.addView(makeSwitch("Mode ramai: hanya jawab kalau namanya dipanggil", KEY_AI_RAMAI, false))
        col.addView(makeSlider("Abaikan suara jauh (0 = mati)", KEY_AI_FAR, 3, 0, 8) { "$it" })
        col.addView(makeButton("Izinkan mikrofon dan notifikasi") { askAiPermissions() })

        col.addView(sectionTitle("Privasi otomatis"))
        col.addView(
            makeText(
                "Saat telepon atau panggilan suara, atau saat membuka aplikasi uang (DANA, OVO, GoPay, bank, dompet digital, " +
                    "kata sandi), dan kamera, robot menutup mata, diam, dan melepas mikrofon. Ini selalu aktif dan tidak bisa dimatikan. " +
                    "Robot hanya melihat nama aplikasi di depan, bukan isinya. Sekitar 1,5 detik setelah kamu keluar, robot bangun lagi.",
                13f,
                false
            )
        )
        col.addView(makeSwitch("Tutup mata di WhatsApp dan aplikasi chat lain", KEY_PRIV_CHAT, true))
        col.addView(makeSwitch("Tutup mata di aplikasi email", KEY_PRIV_EMAIL, false))
        col.addView(makeSwitch("Tutup mata di Setelan", KEY_PRIV_SET, false))
        col.addView(makeSwitch("Tutup mata di Galeri dan foto", KEY_PRIV_GAL, false))

        col.addView(sectionTitle("Performa"))
        col.addView(makeText("Booster mematikan efek kaca supaya tidak lag. Otomatis = booster hanya saat main game.", 13f, false))
        col.addView(styleRow("Mode performa", KEY_PERF, arrayOf("Otomatis", "Penuh", "Booster")))

        col.addView(sectionTitle("Sifat robot"))
        col.addView(styleRow("Jenis kelamin dan suara robot (matikan lalu hidupkan lagi robot di Aksesibilitas setelah ganti)", KEY_GENDER, arrayOf("Cowok", "Cewek")))
        col.addView(makeSwitch("Robot bisa bosan, ngantuk, tidur (ketuk 2x untuk bangunkan), dan mancing sendiri", KEY_BORE, true))

        col.addView(sectionTitle("Colokan dan jalan-jalan"))
        col.addView(
            makeText(
                "Robot menempel di colokan di atas layar. Sekitar 5 kali sehari, di jam rahasia, dia mencabut colokan dan jalan-jalan ke seluruh layar. " +
                    "Baterainya habis sekitar 5 menit. Pulang di 5%. Colokan bisa goyang kena angin sehingga kadang gagal masuk. " +
                    "Setelah keluar dia bingung, geser dia dengan jari untuk memberi arahan. Jangan diputar-putar, nanti pusing. " +
                    "Kalau baterai habis dia mati. Geser dia ke colokan, lalu tunggu 10 detik sampai sadar.",
                13f,
                false
            )
        )
        col.addView(makeSwitch("Robot boleh cabut colokan dan jalan-jalan", KEY_ROAM, true))
        col.addView(makeText("Ramalan jam keluar hari ini (hanya AI yang tahu jadwal aslinya, ramalan ini sering meleset)", 13f, true))
        schedBox = TextView(this).apply { textSize = 14f; typeface = Typeface.MONOSPACE; setPadding(0, dp(6), 0, dp(6)) }
        col.addView(schedBox)

        col.addView(sectionTitle("Suara"))
        col.addView(makeSwitch("Suara robot", KEY_SOUND, true))
        col.addView(makeSlider("Volume suara", KEY_VOL, 70, 0, 100) { "$it%" })

        col.addView(sectionTitle("Musik dan notifikasi"))
        col.addView(
            makeText(
                "Robot ikut bergoyang saat ada musik atau video: semangat, sedih, atau bingung (mata menyipit dengan tanda tanya). " +
                    "Ini perkiraan dari irama dan butuh izin Rekam audio. Suara tidak direkam atau disimpan.\n" +
                    "Kalau banyak notifikasi masuk, robot jadi pusing. Robot hanya menghitung jumlahnya, isinya tidak dibaca.",
                13f,
                false
            )
        )
        col.addView(makeMusicSwitch())
        col.addView(makeSwitch("Robot pusing saat banyak notifikasi", KEY_NOTIF, true))
        col.addView(makeButton("Beri akses notifikasi (hitung jumlah saja)") {
            openSettings(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        col.addView(sectionTitle("Game dengan robot"))
        col.addView(
            makeText(
                "Ikuti mataku: lihat ke arah mana mata robot menoleh, lalu tekan tombol arah yang sama, urut dari yang pertama. " +
                    "Suit: pilih batu, kertas, atau gunting setelah menekan Mulai suit.",
                13f,
                false
            )
        )
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(makeButton("Mulai ikuti mataku") { withSvc { it.gameAction(1, 0) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(makeButton("Mulai suit") { withSvc { it.gameAction(3, 0) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(makeButton("Stop") { withSvc { it.gameAction(0, 0) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        )
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val names = arrayOf("Atas", "Kanan", "Bawah", "Kiri")
                for (d in 0..3) {
                    addView(makeButton(names[d]) { withSvc { it.gameAction(2, d) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
            }
        )
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val names = arrayOf("Batu", "Kertas", "Gunting")
                for (d in 0..2) {
                    addView(makeButton(names[d]) { withSvc { it.gameAction(4, d) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
            }
        )

        col.addView(sectionTitle("Mancing"))
        col.addView(
            makeText(
                "Nyalakan saat kamu menonton video laut atau air. Robot memancing di bawah pill, " +
                    "ikannya makin besar tiap 25 detik, dan talinya bisa putus kalau ikannya terlalu besar. " +
                    "Saat mancing, layar di bawah pill tetap bisa disentuh.",
                13f,
                false
            )
        )
        col.addView(makeButton("Mulai mancing") { withSvc { it.setFishing(true) } })
        col.addView(makeButton("Ikan lebih besar (uji)") { withSvc { it.fishLevelUp() } })
        col.addView(makeButton("Berhenti mancing") { withSvc { it.setFishing(false) } })

        col.addView(sectionTitle("Timer fokus"))
        col.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                for (m in intArrayOf(5, 15, 25)) {
                    addView(
                        makeButton("$m menit") { withSvc { it.startFocus(m) } },
                        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    )
                }
                addView(
                    makeButton("Stop") { withSvc { it.stopFocus() } },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                )
            }
        )

        col.addView(sectionTitle("Pengingat sholat"))
        col.addView(makeSwitch("Robot mengingatkan waktu sholat (bunyi lonceng lembut)", KEY_PRAY, true))
        col.addView(makeCitySpinner())

        col.addView(sectionTitle("Kejadian HP"))
        col.addView(makeSwitch("Bereaksi pada charger, Wi-Fi, headset, volume, senter, mode pesawat, goyang, HP telungkup", KEY_EVENTS, true))

        col.addView(sectionTitle("Gaya robot"))
        col.addView(styleRow("Warna", KEY_COLOR, arrayOf("Cyan", "Hijau", "Ungu", "Pink", "Oranye", "Putih", "Pelangi")))
        col.addView(styleRow("Mata", KEY_SHAPE, arrayOf("Kapsul", "Kotak", "Bulat")))
        col.addView(makeNameBox())

        val tips = makeText(
            "Tips:\n" +
                "• Aktifkan di Aksesibilitas → Aplikasi yang didownload → Robot Island. " +
                "Layanan ini hanya dipakai untuk menggambar robot di atas status bar, " +
                "tidak membaca layar.\n" +
                "• Jika tombol layanan abu-abu: Info aplikasi → titik tiga kanan atas → " +
                "Izinkan setelan terbatas.\n" +
                "• HyperOS/Xiaomi: aktifkan Mulai otomatis, atur Hemat baterai ke " +
                "Tanpa batasan, dan kunci aplikasi di layar Recent supaya tidak dimatikan sistem.\n" +
                "• Geser Jarak, Lebar, dan Tinggi sampai pill pas menutupi kamera depan.\n" +
                "• Robot ikut bereaksi saat charger dicolok, baterai rendah, HP panas, " +
                "Wi-Fi, headset, volume, senter (mata jadi terang), mode pesawat (pesawat lewat di belakang mata), " +
                "HP digoyang (pusing), dan HP ditelungkupkan (mengintip).\n" +
                "• Reaksi musik dan banjir notifikasi butuh izin (lihat bagian masing-masing di atas).",
            13f,
            false
        )
        tips.setPadding(0, dp(16), 0, 0)
        col.addView(tips)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private var schedBox: TextView? = null

    private fun renderSched() {
        val sc = RoamSched.load(prefs)
        val sb = StringBuilder("No  Ramalan  Asli\n")
        for (i in 0 until 5) {
            val real = when (sc.done[i]) {
                1 -> {
                    val d = Math.round((sc.at[i] - sc.pred[i]) / 60000.0).toInt()
                    RoamSched.hhmm(sc.at[i]) + " (" + (if (d >= 0) "+" else "") + d + " mnt)"
                }
                2 -> "terlewat"
                else -> "?"
            }
            sb.append(String.format("%d   %s     %s\n", i + 1, RoamSched.hhmm(sc.pred[i]), real))
        }
        schedBox?.text = sb.toString()
    }

    override fun onResume() {
        super.onResume()
        renderSched()
        updateStatus()
        IslandAccessibility.instance?.refresh()
    }

    private fun updateStatus() {
        val enabled =
            Settings.Secure.getString(contentResolver, "enabled_accessibility_services") ?: ""
        val ok = enabled.contains(packageName)
        status.text = "Aksesibilitas: " + (if (ok) "✓ aktif" else "✗ belum diaktifkan")
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Tidak bisa membuka pengaturan, buka manual lewat menu Aksesibilitas")
        }
    }

    private fun makeAiKeyBox(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val has = (prefs.getString(KEY_AI_KEY, "") ?: "").isNotEmpty()
        val status = makeText(if (has) "Kunci Gemini: sudah tersimpan" else "Kunci Gemini: belum diisi", 14f, false)
        box.addView(status)
        val et = EditText(this)
        et.hint = "Tempel kunci Gemini di sini"
        et.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(et)
        box.addView(makeButton("Simpan kunci") {
            val v = et.text.toString().trim()
            if (v.isNotEmpty()) {
                prefs.edit().putString(KEY_AI_KEY, v).apply()
                et.setText("")
                status.text = "Kunci Gemini: sudah tersimpan"
                toast("Kunci disimpan")
            } else {
                prefs.edit().remove(KEY_AI_KEY).apply()
                status.text = "Kunci Gemini: belum diisi"
                toast("Kunci dihapus")
            }
        })
        val md = EditText(this)
        md.hint = "Model (kosongkan = otomatis)"
        md.setText(prefs.getString(KEY_AI_MODEL, ""))
        box.addView(md)
        box.addView(makeButton("Simpan model") {
            prefs.edit().putString(KEY_AI_MODEL, md.text.toString().trim()).apply()
            toast("Model disimpan")
        })
        return box
    }

    private fun askAiPermissions() {
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) toast("Izin sudah lengkap") else requestPermissions(need.toTypedArray(), 78)
    }

    private fun makeMusicSwitch(): Switch =
        Switch(this).apply {
            text = "Robot bereaksi ke musik"
            isChecked = prefs.getBoolean(KEY_MUSIC, false) &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { btn, checked ->
                if (checked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
                    btn.isChecked = false
                } else {
                    prefs.edit().putBoolean(KEY_MUSIC, checked).apply()
                    IslandAccessibility.instance?.refresh()
                }
            }
        }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean(KEY_MUSIC, true).apply()
            IslandAccessibility.instance?.refresh()
            recreate()
        }
    }

    private fun withSvc(f: (IslandAccessibility) -> Unit) {
        val svc = IslandAccessibility.instance
        if (svc == null) toast("Aksesibilitas belum aktif") else f(svc)
    }

    private fun sectionTitle(label: String): TextView {
        val t = makeText(label, 16f, true)
        t.setPadding(0, dp(22), 0, dp(4))
        return t
    }

    private fun makeCitySpinner(): View {
        val sp = Spinner(this)
        val names = Prayer.cities.map { it.name }
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(prefs.getInt(KEY_CITY, 0).coerceIn(0, names.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                prefs.edit().putInt(KEY_CITY, pos).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    private fun styleRow(label: String, key: String, options: Array<String>): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val caption = makeText("$label: ${options[prefs.getInt(key, 0).coerceIn(0, options.size - 1)]}", 14f, false)
        box.addView(caption)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in options.indices) {
            val b = makeButton(options[i]) {
                prefs.edit().putInt(key, i).apply()
                caption.text = "$label: ${options[i]}"
                IslandAccessibility.instance?.refresh()
            }
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val scroll = android.widget.HorizontalScrollView(this)
        scroll.addView(row)
        box.addView(scroll)
        return box
    }

    private fun makeNameBox(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val et = EditText(this)
        et.setText(prefs.getString(KEY_NAME, "Beepo"))
        et.hint = "Nama robot"
        row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(makeButton("Simpan") {
            val v = et.text.toString().trim().take(8)
            if (v.isNotEmpty()) {
                prefs.edit().putString(KEY_NAME, v).apply()
                IslandAccessibility.instance?.refresh()
                IslandAccessibility.instance?.play(Act.HELLO)
            }
        })
        return row
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun makeText(label: String, size: Float, bold: Boolean): TextView =
        TextView(this).apply {
            text = label
            textSize = size
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun makeButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

    private fun actRow(vararg items: Pair<String, Act>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((label, act) in items) {
            val b = makeButton(label) {
                val svc = IslandAccessibility.instance
                if (svc == null) {
                    toast("Aksesibilitas belum aktif")
                } else {
                    svc.refresh()
                    svc.play(act)
                }
            }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        return row
    }

    private fun makeSwitch(label: String, key: String, def: Boolean): Switch =
        Switch(this).apply {
            text = label
            isChecked = prefs.getBoolean(key, def)
            setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                IslandAccessibility.instance?.refresh()
            }
        }

    private fun makeSlider(
        label: String,
        key: String,
        def: Int,
        lo: Int,
        hi: Int,
        fmt: (Int) -> String
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val value = prefs.getInt(key, def).coerceIn(lo, hi)
        val caption = makeText("$label: ${fmt(value)}", 14f, false)
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = value - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                caption.text = "$label: ${fmt(v)}"
                prefs.edit().putInt(key, v).apply()
                IslandAccessibility.instance?.refresh()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        box.addView(caption)
        box.addView(bar)
        return box
    }
}
