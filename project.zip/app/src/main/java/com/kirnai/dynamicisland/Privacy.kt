package com.kirnai.dynamicisland

import android.content.Context
import android.content.pm.ApplicationInfo

/**
 * Daftar aplikasi pribadi. Saat salah satunya terbuka (atau sedang telepon),
 * robot menutup mata, diam, dan melepas mikrofon. Hanya nama paket yang dilihat,
 * tidak pernah isi layar.
 */
object Privacy {
    const val UANG = 1
    const val KAMERA = 2
    const val CHAT = 4
    const val EMAIL = 8
    const val SETELAN = 16
    const val GALERI = 32

    private val reUang = Regex(
        "(^|[._])(dana|ovo|gopay|linkaja|shopeepay|jago|seabank|jenius|flip|bibit|blu|octo|livin|brimo|bca|bri|bni|mandiri|permata|danamon|btpn|ocbc|maybank|cimb)([._]|$)|bank|wallet|dompet|payment|mbanking|ibank|authenticator|password|keepass|bitwarden|lastpass|1password"
    )
    private val reKamera = Regex("camera")
    private val reChat = Regex("(^|[._])(whatsapp|w4b|telegram|signal|messenger|orca|line)([._]|$)|securesms")
    private val reEmail = Regex("gmail|\\.gm$|email|outlook|k9mail")
    private val reSet = Regex("com\\.android\\.settings|miui\\.securitycenter|permissioncontroller")
    private val reGal = Regex("gallery|\\.photos")

    /** Paket yang bukan "aplikasi di depan" sungguhan: keyboard, status bar, dan sejenisnya. */
    fun isIgnorable(pkg: String, own: String): Boolean {
        if (pkg == own) return true
        val p = pkg.lowercase()
        return p == "com.android.systemui" || p == "android" || p.contains("inputmethod") ||
            p.contains("keyboard") || p.contains("swiftkey") || p.contains("honeyboard")
    }

    fun groupOf(pkg: String): Int {
        val p = pkg.lowercase()
        var g = 0
        if (reUang.containsMatchIn(p)) g = g or UANG
        if (reKamera.containsMatchIn(p)) g = g or KAMERA
        if (reChat.containsMatchIn(p)) g = g or CHAT
        if (reEmail.containsMatchIn(p)) g = g or EMAIL
        if (reSet.containsMatchIn(p)) g = g or SETELAN
        if (reGal.containsMatchIn(p)) g = g or GALERI
        return g
    }

    /** Apakah paket ini harus membuat robot menutup mata, menurut pengaturan. */
    fun isPrivate(ctx: Context, pkg: String): Boolean {
        val g = groupOf(pkg)
        if (g == 0) return false
        val pr = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (g and UANG != 0 || g and KAMERA != 0) return true
        if (g and CHAT != 0 && pr.getBoolean(KEY_PRIV_CHAT, true)) return true
        if (g and EMAIL != 0 && pr.getBoolean(KEY_PRIV_EMAIL, false)) return true
        if (g and SETELAN != 0 && pr.getBoolean(KEY_PRIV_SET, false)) return true
        if (g and GALERI != 0 && pr.getBoolean(KEY_PRIV_GAL, false)) return true
        return false
    }

    /** Kategori kasar untuk konteks AI: game, video, social, news, browser, musik, atau lain. */
    fun category(ctx: Context, pkg: String): String {
        val p = pkg.lowercase()
        if (p.contains("chrome") || p.contains("browser") || p.contains("firefox") || p.contains("opera") || p.contains("brave")) return "browser"
        if (p.contains("youtube") || p.contains("netflix") || p.contains("video") || p.contains("tiktok") || p.contains("vidio")) return "video"
        if (p.contains("instagram") || p.contains("facebook") || p.contains("twitter") || p.contains("threads") || p.contains("reddit")) return "social"
        if (p.contains("spotify") || p.contains("music") || p.contains("joox")) return "musik"
        if (p.contains("launcher") || p.contains("home")) return "home"
        try {
            val info = ctx.packageManager.getApplicationInfo(pkg, 0)
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                when (info.category) {
                    ApplicationInfo.CATEGORY_GAME -> return "game"
                    ApplicationInfo.CATEGORY_VIDEO -> return "video"
                    ApplicationInfo.CATEGORY_AUDIO -> return "musik"
                    ApplicationInfo.CATEGORY_SOCIAL -> return "social"
                    ApplicationInfo.CATEGORY_NEWS -> return "news"
                }
            }
            if (info.flags and ApplicationInfo.FLAG_IS_GAME != 0) return "game"
        } catch (e: Exception) {
        }
        return "lain"
    }
}
