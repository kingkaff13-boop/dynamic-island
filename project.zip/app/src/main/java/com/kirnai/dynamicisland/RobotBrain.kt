package com.kirnai.dynamicisland

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.Calendar
import java.util.Random

/**
 * "Otak" robot: memutuskan kapan berkedip, melirik, dan memainkan aksi.
 * Semua offline: hanya memakai jam, status layar, dan baterai.
 */
class RobotBrain(private val ctx: Context, private val overlay: RobotOverlay) {

    private val h = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val rnd = Random()

    private var screenOn = true
    private var running = false
    private var current = Act.IDLE
    private var lastCharging: Boolean? = null
    private var lastSad = 0L
    private var lastHot = 0L
    private var notifiedFull = false

    private val endRun = Runnable {
        current = Act.IDLE
        overlay.setAct(Act.IDLE, null)
    }

    private val blinkRun = object : Runnable {
        override fun run() {
            overlay.blink()
            if (rnd.nextInt(5) == 0) {
                h.postDelayed({ overlay.blink() }, 260L)
            }
            h.postDelayed(this, 2200L + rnd.nextInt(3600))
        }
    }

    private val glanceRun = object : Runnable {
        override fun run() {
            if (current == Act.IDLE) {
                val x = if (rnd.nextInt(3) == 0) 0f else rnd.nextFloat() * 2f - 1f
                val y = (rnd.nextFloat() * 2f - 1f) * 0.6f
                overlay.lookAt(x, y)
                h.postDelayed({
                    if (current == Act.IDLE) overlay.lookAt(0f, 0f)
                }, 1100L + rnd.nextInt(1400))
            }
            h.postDelayed(this, 3200L + rnd.nextInt(5200))
        }
    }

    private val autoRun = object : Runnable {
        override fun run() {
            if (current == Act.IDLE) play(pickAuto(), null, false)
            h.postDelayed(this, autoDelay())
        }
    }

    private val breakRun = object : Runnable {
        override fun run() {
            if (prefs.getBoolean(KEY_BREAK, true)) play(Act.EXERCISE, null, true)
            h.postDelayed(this, breakMs())
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    h.removeCallbacksAndMessages(null)
                    current = Act.IDLE
                    overlay.setAct(Act.IDLE, null)
                }

                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    scheduleAll()
                    val hour = hourNow()
                    play(if (hour < 5) Act.SLEEPY else Act.HAPPY, null, true)
                }
            }
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return
            val pct = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val now = SystemClock.elapsedRealtime()

            val prev = lastCharging
            lastCharging = charging
            if (prev == null) return

            if (charging != prev) {
                notifiedFull = false
                if (charging) play(Act.HAPPY, "⚡", true) else play(Act.SURPRISE, null, true)
                return
            }
            if (charging && pct >= 100 && !notifiedFull) {
                notifiedFull = true
                play(Act.HAPPY, "🔋", true)
                return
            }
            if (!charging && pct <= 20 && now - lastSad > 10 * 60_000L) {
                lastSad = now
                play(Act.SAD, null, true)
                return
            }
            if (temp >= 43f && now - lastHot > 5 * 60_000L) {
                lastHot = now
                play(Act.HOT, null, true)
            }
        }
    }

    fun start() {
        if (running) return
        running = true
        screenOn = true
        val screenF = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        register(screenReceiver, screenF)
        register(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        scheduleAll()
        h.postDelayed({ play(Act.HAPPY, null, true) }, 600L)
    }

    fun stop() {
        if (!running) return
        running = false
        h.removeCallbacksAndMessages(null)
        try {
            ctx.unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        try {
            ctx.unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
        }
        current = Act.IDLE
    }

    private fun register(r: BroadcastReceiver, f: IntentFilter) {
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            ctx.registerReceiver(r, f)
        }
    }

    private fun scheduleAll() {
        h.removeCallbacks(blinkRun)
        h.removeCallbacks(glanceRun)
        h.removeCallbacks(autoRun)
        h.removeCallbacks(breakRun)
        h.postDelayed(blinkRun, 1800L)
        h.postDelayed(glanceRun, 3000L)
        h.postDelayed(autoRun, autoDelay())
        h.postDelayed(breakRun, breakMs())
    }

    /** Mainkan aksi. force=false: dilewati jika robot sedang sibuk. */
    fun play(a: Act, badge: String? = null, force: Boolean = true) {
        if (!screenOn || !running) return
        if (!force && current != Act.IDLE) return
        h.removeCallbacks(endRun)
        current = a
        overlay.setAct(a, badge)
        if (a.durationMs > 0L) h.postDelayed(endRun, a.durationMs)
    }

    /** Robot diketuk: bereaksi acak. Ketukan saat senam mata menghentikannya. */
    fun onTap() {
        if (current == Act.EXERCISE) {
            h.removeCallbacks(endRun)
            endRun.run()
            return
        }
        val pool = arrayOf(Act.SURPRISE, Act.LAUGH, Act.WINK, Act.HAPPY, Act.PHOTO)
        play(pool[rnd.nextInt(pool.size)], null, true)
    }

    fun onLongPress() {
        play(Act.DANCE, null, true)
    }

    private fun pickAuto(): Act {
        val hour = hourNow()
        val pool = ArrayList<Act>()
        repeat(3) { pool.add(Act.WINK) }
        repeat(3) { pool.add(Act.HAPPY) }
        repeat(2) { pool.add(Act.LAUGH) }
        repeat(2) { pool.add(Act.SURPRISE) }
        repeat(2) { pool.add(Act.PHOTO) }
        pool.add(Act.DANCE)
        if (hour >= 22 || hour < 5) repeat(5) { pool.add(Act.SLEEPY) }
        return pool[rnd.nextInt(pool.size)]
    }

    private fun autoDelay(): Long = when (prefs.getInt(KEY_ACTIVITY, 1)) {
        0 -> 60_000L + rnd.nextInt(60_000)
        2 -> 12_000L + rnd.nextInt(18_000)
        else -> 25_000L + rnd.nextInt(35_000)
    }

    private fun breakMs(): Long = prefs.getInt(KEY_BREAK_MIN, 20).coerceAtLeast(1) * 60_000L

    private fun hourNow(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
}
