package com.kirnai.dynamicisland

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import java.util.Calendar
import java.util.Random
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * "Otak" robot: kapan berkedip, melirik, bereaksi pada kejadian HP, dan memainkan aksi.
 * Semua offline. Tidak membaca layar atau isi notifikasi.
 */
class RobotBrain(private val ctx: Context, private val overlay: RobotOverlay) {

    private val h = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val rnd = Random()

    private var screenOn = true
    private var running = false
    private var current = Act.IDLE
    private var lastCharging: Boolean? = null
    private var lastSad = 0L
    private var lastHot = 0L
    private var notifiedFull = false
    private var pokes = ArrayList<Long>()

    private var fishing = false
    private var focusEnd = 0L
    private var firedKey = ""
    private var lastShake = 0L
    private var shakeCount = 0
    private var shakeWindowStart = 0L
    private var faceDownSince = 0L
    private var lastPeek = 0L
    private var wifiUp: Boolean? = null

    private var sensorMgr: SensorManager? = null
    private var camMgr: CameraManager? = null
    private var connMgr: ConnectivityManager? = null
    private var torchCb: CameraManager.TorchCallback? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    // kehidupan: suasana hati, waktu, lama pakai
    private var mood = 60f
    private var lastRobotTouch = SystemClock.elapsedRealtime()
    private var screenOffAt = 0L
    private var screenOnSince = SystemClock.elapsedRealtime()
    private var lastBucket = ""
    private var weak = false
    private var lastWeak = 0L
    private var volUp = true
    private var toss = true

    // game
    private var gameOn = false
    private var gameMode = 0
    private var seq = ArrayList<Int>()
    private var gpos = 0
    private var gscore = 0
    private var gphase = ""
    private val gameRuns = ArrayList<Runnable>()

    // musik & notifikasi
    private var musicMood = 0
    private var sense: MusicSense? = null
    private var dizzyLevel = 0f
    private var dizzyAt = 0L

    private fun baseAct(): Act = when {
        gameOn -> Act.GAME
        fishing -> Act.FISH
        focusEnd > SystemClock.uptimeMillis() -> Act.FOCUS
        musicMood == 1 -> Act.MUSIC_HYPE
        musicMood == 2 -> Act.MUSIC_SAD
        musicMood == 3 -> Act.MUSIC_ODD
        musicMood == 4 -> Act.MUSIC_CHILL
        else -> Act.IDLE
    }

    private fun isBusy(): Boolean = current != Act.IDLE && current != baseAct()

    private val endRun = Runnable {
        current = baseAct()
        overlay.setAct(current, null)
    }

    private val blinkRun = object : Runnable {
        override fun run() {
            overlay.blink()
            if (rnd.nextInt(5) == 0) h.postDelayed({ overlay.blink() }, 260L)
            h.postDelayed(this, 2200L + rnd.nextInt(3600))
        }
    }

    private val glanceRun = object : Runnable {
        override fun run() {
            if (current == Act.IDLE) {
                val x = if (rnd.nextInt(3) == 0) 0f else rnd.nextFloat() * 2f - 1f
                val y = (rnd.nextFloat() * 2f - 1f) * 0.6f
                overlay.lookAt(x, y)
                h.postDelayed({ if (current == Act.IDLE) overlay.lookAt(0f, 0f) }, 1100L + rnd.nextInt(1400))
            }
            h.postDelayed(this, 3200L + rnd.nextInt(5200))
        }
    }

    private val autoRun = object : Runnable {
        override fun run() {
            if (current == Act.IDLE) play(pickAuto(), null, false)
            h.postDelayed(this, autoDelay())
        }
    }

    private val breakRun = object : Runnable {
        override fun run() {
            if (prefs.getBoolean(KEY_BREAK, true) && !fishing) play(Act.EXERCISE, null, true)
            h.postDelayed(this, breakMs())
        }
    }

    private val tickRun = object : Runnable {
        override fun run() {
            checkFocus()
            checkPrayer()
            checkLife()
            h.postDelayed(this, 5000L)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    screenOffAt = SystemClock.elapsedRealtime()
                    stopSensors()
                    applyMusic()
                    h.removeCallbacks(endRun)
                    h.removeCallbacks(blinkRun)
                    h.removeCallbacks(glanceRun)
                    h.removeCallbacks(autoRun)
                    h.removeCallbacks(breakRun)
                    current = baseAct()
                    overlay.setAct(current, null)
                }

                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    startSensors()
                    applyMusic()
                    scheduleAll()
                    val nowE = SystemClock.elapsedRealtime()
                    val offMin = (nowE - screenOffAt) / 60000f
                    if (offMin > 2f) screenOnSince = nowE
                    if (offMin > 30f) mood = max(0f, mood - min(60f, offMin / 3f))
                    pushMood()
                    if (offMin > 30f && mood < 45f) {
                        bump(20f)
                        play(Act.REUNION, null, true)
                    } else {
                        bump(1.5f)
                        play(if (hourNow() < 5) Act.SLEEPY else if (bucket() == "pagi" && offMin > 120f) Act.MORNING else Act.HAPPY, null, true)
                    }
                }
            }
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return
            val pct = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val now = SystemClock.elapsedRealtime()

            val prev = lastCharging
            lastCharging = charging
            if (prev == null || !events()) return

            if (charging != prev) {
                notifiedFull = false
                if (charging) {
                    if (weak) {
                        weak = false
                        play(Act.REVIVE, null, true)
                    } else {
                        play(Act.HAPPY, "bolt", true)
                    }
                } else {
                    play(Act.SURPRISE, null, true)
                }
                return
            }
            if (!charging && pct <= 5 && now - lastWeak > 10 * 60_000L) {
                lastWeak = now
                weak = true
                play(Act.WEAK, null, true)
                return
            }
            if (charging && pct >= 100 && !notifiedFull) {
                notifiedFull = true
                play(Act.HAPPY, "bolt", true)
                return
            }
            if (!charging && pct <= 20 && now - lastSad > 10 * 60_000L) {
                lastSad = now
                play(Act.SAD, "battery", true)
                return
            }
            if (temp >= 43f && now - lastHot > 5 * 60_000L) {
                lastHot = now
                play(Act.HOT, null, true)
            }
        }
    }

    private val eventReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent == null || !events()) return
            when (intent.action) {
                Intent.ACTION_HEADSET_PLUG -> {
                    if (intent.getIntExtra("state", 0) == 1) play(Act.HEADSET, null, true)
                    else play(Act.SURPRISE, null, true)
                }

                Intent.ACTION_AIRPLANE_MODE_CHANGED -> {
                    val on = intent.getBooleanExtra("state", false)
                    overlay.setAirplane(on)
                    if (on) Sfx.planeOn() else Sfx.planeOff()
                }

                "android.media.VOLUME_CHANGED_ACTION" -> {
                    val type = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                    if (type != 3) return
                    val v = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", 0)
                    val pv = intent.getIntExtra("android.media.EXTRA_PREV_VOLUME_STREAM_VALUE", 0)
                    if (v == pv) return
                    volUp = v > pv
                    overlay.setExtras(volUp = volUp)
                    play(Act.VOLUME, null, false)
                }
            }
        }
    }

    private val sensorListener = object : SensorEventListener {
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        override fun onSensorChanged(e: SensorEvent?) {
            if (e == null || !events()) return
            val x = e.values[0]
            val y = e.values[1]
            val z = e.values[2]
            val g = sqrt(x * x + y * y + z * z)
            val now = SystemClock.elapsedRealtime()
            // goyang: gaya jauh di atas gravitasi, 3 kali dalam 1,2 detik
            if (abs(g - 9.8f) > 9f && now - lastShake > 150L) {
                lastShake = now
                if (now - shakeWindowStart > 1200L) {
                    shakeWindowStart = now
                    shakeCount = 0
                }
                shakeCount++
                if (shakeCount >= 3) {
                    shakeCount = 0
                    play(Act.DIZZY, null, true)
                }
            }
            // telungkup: layar menghadap bawah stabil 1,5 detik
            if (z < -8.5f && abs(x) < 2.5f && abs(y) < 2.5f) {
                if (faceDownSince == 0L) faceDownSince = now
                if (now - faceDownSince > 1500L && now - lastPeek > 60_000L) {
                    lastPeek = now
                    play(Act.PEEK, null, false)
                }
            } else {
                faceDownSince = 0L
            }
        }
    }

    private fun events(): Boolean = prefs.getBoolean(KEY_EVENTS, true)

    fun start() {
        if (running) return
        running = true
        screenOn = true
        fishing = false
        lastBucket = bucket()
        screenOnSince = SystemClock.elapsedRealtime()
        pushMood()
        applySound()
        register(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        })
        register(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        register(eventReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_HEADSET_PLUG)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction("android.media.VOLUME_CHANGED_ACTION")
        })
        try {
            val on = Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
            overlay.setAirplane(on)
        } catch (e: Exception) {
        }
        startTorch()
        startWifi()
        startSensors()
        applyMusic()
        scheduleAll()
        h.postDelayed(tickRun, 3000L)
        h.postDelayed({ play(Act.HELLO, null, true) }, 600L)
    }

    fun stop() {
        if (!running) return
        running = false
        h.removeCallbacksAndMessages(null)
        for (r in arrayOf(screenReceiver, batteryReceiver, eventReceiver)) {
            try {
                ctx.unregisterReceiver(r)
            } catch (e: Exception) {
            }
        }
        stopSensors()
        stopGameLogic()
        sense?.stop()
        sense = null
        try {
            val cb = torchCb
            if (cb != null) camMgr?.unregisterTorchCallback(cb)
        } catch (e: Exception) {
        }
        try {
            val cb = netCb
            if (cb != null) connMgr?.unregisterNetworkCallback(cb)
        } catch (e: Exception) {
        }
        torchCb = null
        netCb = null
        overlay.setFishing(false)
        overlay.setTorch(false)
        overlay.setAirplane(false)
        current = Act.IDLE
    }

    /** Dipanggil saat pengaturan berubah (suara, gaya). */
    fun applySound() {
        Sfx.enabled = prefs.getBoolean(KEY_SOUND, true)
        Sfx.volume = prefs.getInt(KEY_VOL, 70) / 100f
        overlay.applyStyle()
        applyMusic()
    }

    private fun register(r: BroadcastReceiver, f: IntentFilter) {
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            ctx.registerReceiver(r, f)
        }
    }

    private fun startTorch() {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            camMgr = cm
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    overlay.setTorch(enabled)
                    if (events()) {
                        if (enabled) Sfx.torchOn() else Sfx.torchOff()
                    }
                }
            }
            torchCb = cb
            cm.registerTorchCallback(cb, h)
        } catch (e: Exception) {
        }
    }

    private fun startWifi() {
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            connMgr = cm
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build()
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    h.post {
                        val first = wifiUp == null
                        wifiUp = true
                        if (!first && events()) play(Act.HAPPY, "wifi", true)
                        if (first) wifiUp = true
                    }
                }

                override fun onLost(network: Network) {
                    h.post {
                        wifiUp = false
                        if (events()) play(Act.SAD, "nowifi", true)
                    }
                }
            }
            netCb = cb
            cm.registerNetworkCallback(req, cb)
        } catch (e: Exception) {
        }
    }

    private fun startSensors() {
        if (sensorMgr != null) return
        try {
            val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            sensorMgr = sm
            sm.registerListener(sensorListener, acc, SensorManager.SENSOR_DELAY_NORMAL)
        } catch (e: Exception) {
            sensorMgr = null
        }
    }

    private fun stopSensors() {
        try {
            sensorMgr?.unregisterListener(sensorListener)
        } catch (e: Exception) {
        }
        sensorMgr = null
        faceDownSince = 0L
    }

    private fun scheduleAll() {
        h.removeCallbacks(blinkRun)
        h.removeCallbacks(glanceRun)
        h.removeCallbacks(autoRun)
        h.removeCallbacks(breakRun)
        h.postDelayed(blinkRun, 1800L)
        h.postDelayed(glanceRun, 3000L)
        h.postDelayed(autoRun, autoDelay())
        h.postDelayed(breakRun, breakMs())
    }

    /** Mainkan aksi. force=false: dilewati jika robot sedang sibuk. */
    fun play(a: Act, badge: String? = null, force: Boolean = true) {
        if (!screenOn || !running) return
        if (!force && isBusy()) return
        h.removeCallbacks(endRun)
        current = a
        if (a == Act.TOSS) {
            toss = rnd.nextFloat() < 0.6f
            overlay.setToss(toss)
        }
        overlay.setAct(a, badge)
        Sfx.newVoice()
        Sfx.forAct(a, volUp, toss)
        when (badge) {
            "bolt" -> Sfx.charger()
            "battery" -> Sfx.lowBatt()
            "wifi" -> Sfx.wifiOn()
            "nowifi" -> Sfx.wifiOff()
        }
        if (a.durationMs > 0L) h.postDelayed(endRun, a.durationMs)
    }

    fun setPrayerName(name: String) = overlay.setExtras(prayer = name)

// ---------- musik ----------

    private fun applyMusic() {
        if (!running) return
        val want = prefs.getBoolean(KEY_MUSIC, false) && screenOn
        if (want && sense == null) {
            val ms = MusicSense(
                { mood -> h.post { onMusicMood(mood) } },
                { overlay.musicBeat() }
            )
            if (ms.start()) sense = ms
        } else if (!want && sense != null) {
            sense?.stop()
            sense = null
            onMusicMood(0)
        }
    }

    private fun onMusicMood(m: Int) {
        musicMood = m
        if (!screenOn) return
        // jangan menimpa aksi sesaat; kalau robot sedang sibuk, baseAct dipakai setelah aksi selesai
        if (!isBusy()) {
            current = baseAct()
            overlay.setAct(current, null)
            Sfx.cue(m)
        }
    }

    // ---------- notifikasi ----------

    fun onNotification() {
        if (!screenOn || !running || !prefs.getBoolean(KEY_NOTIF, true)) return
        val now = SystemClock.uptimeMillis()
        dizzyLevel = max(0f, dizzyLevel - (now - dizzyAt) / 1000f * 0.45f) + 1f
        dizzyAt = now
        Sfx.ping()
        if (dizzyLevel >= 3f && current != Act.DIZZY) {
            dizzyLevel = 3f
            play(Act.DIZZY, null, true)
        } else if (!isBusy()) {
            overlay.lookAt(0f, 0.8f)
            overlay.blink()
            h.postDelayed({ if (!isBusy()) overlay.lookAt(0f, 0f) }, 900L)
        }
    }

    // ---------- game ----------

    private fun later(ms: Long, r: () -> Unit) {
        val run = Runnable { r() }
        gameRuns.add(run)
        h.postDelayed(run, ms)
    }

    private fun stopGameLogic() {
        for (r in gameRuns) h.removeCallbacks(r)
        gameRuns.clear()
        gameOn = false
        gameMode = 0
        overlay.gameState(0, "")
        overlay.lookAt(0f, 0f)
    }

    private fun enterGame() {
        fishing = false
        overlay.setFishing(false)
        gameOn = true
        h.removeCallbacks(endRun)
        current = Act.GAME
        overlay.setAct(Act.GAME, null)
    }

    /** kind: 0 = berhenti, 1 = mulai ikuti mataku, 2 = tekan arah (value 0..3), 3 = mulai suit, 4 = pilih suit (0 batu, 1 kertas, 2 gunting) */
    fun gameAction(kind: Int, value: Int) {
        if (!running) return
        when (kind) {
            0 -> {
                stopGameLogic()
                current = baseAct()
                overlay.setAct(current, null)
            }
            1 -> { stopGameLogic(); enterGame(); gameMode = 1; seq.clear(); gscore = 0; simonRound() }
            2 -> simonPress(value)
            3 -> {
                stopGameLogic(); enterGame(); gameMode = 2
                overlay.gameState(2, "ready")
            }
            4 -> rpsPick(value)
        }
    }

    private val dirX = floatArrayOf(0f, 1f, 0f, -1f)
    private val dirY = floatArrayOf(-1f, 0f, 1f, 0f)
    private val dirTone = floatArrayOf(523f, 659f, 392f, 784f)

    private fun simonRound() {
        seq.add(rnd.nextInt(4))
        gpos = 0
        gphase = "show"
        overlay.gameState(1, "show", 0, seq.size, gscore)
        overlay.lookAt(0f, 0f)
        for (i in seq.indices) {
            val d = seq[i]
            later(900L + i * 900L) { overlay.lookAt(dirX[d], dirY[d]); Sfx.beep(dirTone[d]) }
            later(900L + i * 900L + 560L) { overlay.lookAt(0f, 0f) }
        }
        later(900L + seq.size * 900L) { gphase = "input"; overlay.gameState(1, "input", gpos, seq.size, gscore) }
    }

    private fun simonPress(d: Int) {
        if (!gameOn || gameMode != 1) return
        if (gphase != "input") return
        Sfx.beep(dirTone[d.coerceIn(0, 3)])
        if (gpos >= seq.size) return
        if (d == seq[gpos]) {
            gpos++
            overlay.gameState(1, "input", gpos.coerceAtMost(seq.size - 1), seq.size, gscore)
            if (gpos == seq.size) {
                gscore = seq.size
                val best = prefs.getInt(KEY_BEST, 0)
                if (gscore > best) prefs.edit().putInt(KEY_BEST, gscore).apply()
                gphase = "cheer"
                overlay.gameState(1, "cheer", 0, seq.size, gscore)
                later(250L) { Sfx.good() }
                later(1600L) { simonRound() }
            }
        } else {
            gphase = "over"
            overlay.gameState(1, "over", 0, seq.size, gscore)
            Sfx.bad()
            later(3200L) { stopGameLogic(); current = baseAct(); overlay.setAct(current, null) }
        }
    }

    private fun rpsPick(c: Int) {
        if (!gameOn || gameMode != 2) return
        val robot = rnd.nextInt(3)
        for (i in 0..2) {
            later(i * 600L) {
                overlay.gameState(2, "count", count = 3 - i, robot = robot)
                Sfx.beep(if (i < 2) 700f else 1000f)
            }
        }
        later(1850L) {
            val r = (c - robot + 3) % 3
            val res = if (r == 0) "draw" else if (r == 1) "win" else "lose"
            overlay.gameState(2, "reveal", robot = robot, result = res)
            if (res == "win") Sfx.bad() else if (res == "lose") Sfx.forAct(Act.LAUGH) else Sfx.forAct(Act.WINK)
        }
        later(4300L) { overlay.gameState(2, "ready") }
    }

    // ---------- mancing & fokus ----------

    fun setFishing(on: Boolean) {
        if (on && gameOn) stopGameLogic()
        fishing = on
        overlay.setFishing(on)
        if (on) {
            Sfx.levelUp()
            h.removeCallbacks(endRun)
            current = Act.FISH
            overlay.setAct(Act.FISH, null)
        } else {
            h.removeCallbacks(endRun)
            current = baseAct()
            overlay.setAct(current, null)
        }
    }

    fun isFishing(): Boolean = fishing

    fun fishLevelUp() {
        if (fishing) overlay.fishLevelUp() else setFishing(true)
    }

    fun startFocus(minutes: Int) {
        focusEnd = SystemClock.uptimeMillis() + minutes * 60_000L
        overlay.setExtras(focusEnd = focusEnd)
        if (!fishing) {
            h.removeCallbacks(endRun)
            current = Act.FOCUS
            overlay.setAct(Act.FOCUS, null)
        }
        Sfx.levelUp()
    }

    fun stopFocus() {
        focusEnd = 0L
        overlay.setExtras(focusEnd = 0L)
        if (current == Act.FOCUS) {
            current = baseAct()
            overlay.setAct(current, null)
        }
    }

    private fun checkFocus() {
        if (focusEnd != 0L && SystemClock.uptimeMillis() >= focusEnd) {
            focusEnd = 0L
            overlay.setExtras(focusEnd = 0L)
            if (current == Act.FOCUS) {
                current = Act.IDLE
                overlay.setAct(Act.IDLE, null)
            }
            play(Act.DANCE, null, true)
        }
    }

    // ---------- sholat ----------

    private fun checkPrayer() {
        if (!prefs.getBoolean(KEY_PRAY, true) || !screenOn) return
        val city = Prayer.cities[prefs.getInt(KEY_CITY, 0).coerceIn(0, Prayer.cities.size - 1)]
        val cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+" + city.tz))
        val key0 = "" + cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.DAY_OF_YEAR)
        val times = Prayer.times(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), city)
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        for (i in times.indices) {
            val key = key0 + "-" + i
            if (times[i].toInt() == nowMin && key != firedKey) {
                firedKey = key
                setPrayerName(Prayer.names[i])
                play(Act.ADZAN, null, true)
            }
        }
    }

    // ---------- interaksi ----------

    private fun hourNow(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    private fun bucket(): String {
        val h = hourNow()
        return if (h < 5 || h >= 22) "dini" else if (h < 11) "pagi" else if (h < 18) "siang" else "malam"
    }

    private fun pushMood() = overlay.setMood(mood)

    private fun bump(n: Float) {
        mood = (mood + n).coerceIn(0f, 100f)
        pushMood()
    }

    /** Dicek tiap 5 detik: suasana hati turun pelan, pergantian waktu, dan terlalu lama pakai HP. */
    private fun checkLife() {
        if (!running) return
        val now = SystemClock.elapsedRealtime()
        val lonely = now - lastRobotTouch > 30 * 60_000L
        mood = (mood - 5f * (if (lonely) 0.03f else 0.004f)).coerceIn(0f, 100f)
        pushMood()
        if (!screenOn) return
        val b = bucket()
        if (lastBucket.isNotEmpty() && b != lastBucket && !isBusy() && !fishing && !gameOn) {
            play(if (b == "pagi") Act.MORNING else if (b == "siang") Act.HAPPY else Act.YAWN, null, true)
        }
        lastBucket = b
        if (now - screenOnSince > 45 * 60_000L && !isBusy() && !fishing && !gameOn) {
            screenOnSince = now
            play(Act.REST, null, true)
        }
    }

    /** Robot diketuk: makin sering diketuk makin kesal. Ketukan saat senam mata menghentikannya. */
    fun onTap() {
        val now = SystemClock.uptimeMillis()
        lastRobotTouch = SystemClock.elapsedRealtime()
        pokes.removeAll { now - it > 4000L }
        pokes.add(now)
        val n = pokes.size
        if (current == Act.EXERCISE) {
            h.removeCallbacks(endRun)
            endRun.run()
            return
        }
        if (current == Act.SLEEPY) {
            play(Act.SURPRISE, null, true)
            return
        }
        val wasLonely = mood < 25f
        bump(4f)
        if (wasLonely) {
            bump(30f)
            play(Act.REUNION, null, true)
            return
        }
        if (n >= 5) {
            pokes.clear()
            play(Act.ANGRY, null, true)
        } else if (n == 4) {
            play(Act.ANNOYED, null, true)
        } else if (n >= 2) {
            play(if (rnd.nextBoolean()) Act.LAUGH else Act.WINK, null, true)
        } else {
            val pool = arrayOf(Act.SURPRISE, Act.HAPPY, Act.PHOTO, Act.WINK)
            play(pool[rnd.nextInt(pool.size)], null, true)
        }
    }

    fun onLongPress() {
        lastRobotTouch = SystemClock.elapsedRealtime()
        play(Act.DANCE, null, true)
    }

    /** 1 = usap kiri-kanan (geli), 2 = dua jari (kaget), 3 = tahan lama (dielus). */
    fun onGesture(kind: Int) {
        lastRobotTouch = SystemClock.elapsedRealtime()
        when (kind) {
            1 -> { bump(3f); play(Act.TICKLE, null, true) }
            2 -> { bump(2f); play(Act.SURPRISE, null, true) }
            3 -> { bump(6f); play(Act.CUDDLE, null, true) }
        }
    }

    private fun pickAuto(): Act {
        val b = bucket()
        val pool = ArrayList<Act>()
        if (mood < 25f) {
            repeat(2) { pool.add(Act.MISS) }
            pool.add(Act.SAD); pool.add(Act.SLEEPY); pool.add(Act.CONFUSED); pool.add(Act.YAWN)
        } else {
            repeat(2) { pool.add(Act.WINK) }
            pool.add(Act.HAPPY); pool.add(Act.LAUGH); pool.add(Act.SURPRISE); pool.add(Act.PHOTO); pool.add(Act.CONFUSED)
            pool.add(Act.BUG); pool.add(Act.BALL); pool.add(Act.TOSS); pool.add(Act.DANCE)
            if (mood >= 70f) {
                pool.add(Act.DANCE); pool.add(Act.BUG); pool.add(Act.BALL); pool.add(Act.TOSS); pool.add(Act.HAPPY); pool.add(Act.LAUGH)
            }
        }
        if (b == "dini" || b == "malam") {
            pool.add(Act.YAWN); pool.add(Act.YAWN)
            repeat(if (b == "dini") 5 else 2) { pool.add(Act.SLEEPY) }
        }
        if (b == "pagi") { pool.add(Act.MORNING); pool.add(Act.YAWN) }
        return pool[rnd.nextInt(pool.size)]
    }

    private fun autoDelay(): Long = when (prefs.getInt(KEY_ACTIVITY, 1)) {
        0 -> 60_000L + rnd.nextInt(60_000)
        2 -> 12_000L + rnd.nextInt(18_000)
        else -> 25_000L + rnd.nextInt(35_000)
    }

    private fun breakMs(): Long = prefs.getInt(KEY_BREAK_MIN, 20).coerceAtLeast(1) * 60_000L

}
