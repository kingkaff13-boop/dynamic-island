package com.kirnai.dynamicisland

/**
 * Aksi yang bisa dimainkan robot.
 * durationMs = lama aksi, wide = seberapa lebar pill saat aksi (0 = ukuran diam, 1 = penuh).
 */
enum class Act(val durationMs: Long, val wide: Float) {
    IDLE(0L, 0f),
    HAPPY(2600L, 0f),
    SAD(4600L, 0f),
    SLEEPY(5400L, 0f),
    SURPRISE(1800L, 0f),
    WINK(1500L, 0f),
    LAUGH(2600L, 0f),
    HOT(5200L, 0.55f),
    PHOTO(3900L, 0.6f),
    DANCE(7000L, 1f),
    EXERCISE(25000L, 1f)
}
