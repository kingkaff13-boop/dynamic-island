package com.kirnai.dynamicisland

/**
 * Aksi yang bisa dimainkan robot.
 * durationMs = lama aksi (0 = tanpa batas), wide = lebar pill saat aksi (0 = diam, 1 = penuh).
 */
enum class Act(val durationMs: Long, val wide: Float, val title: String) {
    IDLE(0L, 0f, "Diam"),
    HAPPY(2600L, 0f, "Senang"),
    SAD(4600L, 0f, "Sedih"),
    ANGRY(3800L, 0.35f, "Marah"),
    ANNOYED(3000L, 0.2f, "Kesal"),
    SURPRISE(1800L, 0f, "Kaget"),
    LAUGH(2600L, 0f, "Ketawa"),
    WINK(1500L, 0f, "Kedip sebelah"),
    SLEEPY(5400L, 0f, "Ngantuk"),
    CONFUSED(3600L, 0.3f, "Bingung"),
    PEEK(3800L, 0f, "Ngintip"),
    HOT(5200L, 0.55f, "Kegerahan"),
    PHOTO(3900L, 0.6f, "Foto"),
    DANCE(7000L, 1f, "Nari"),
    EXERCISE(25000L, 1f, "Senam mata"),
    HEADSET(6000L, 0f, "Pakai headset"),
    VOLUME(2000L, 0.35f, "Ubah volume"),
    ADZAN(9000L, 0.55f, "Waktu sholat"),
    HELLO(2800L, 0.55f, "Menyapa"),
    DIZZY(4200L, 0.4f, "Pusing"),
    FOCUS(0L, 0.55f, "Fokus"),
    FISH(0L, 0.45f, "Mancing")
}
