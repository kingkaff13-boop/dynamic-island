package com.kirnai.dynamicisland

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Dua jendela kecil di samping pill: bulatan asisten AI di kiri pill
 * (mendengar / berpikir / bicara) dan jendela info di bawah pill
 * (teks ucapan robot dan penghitung ketukan). Tidak bisa disentuh.
 */
class AiOverlay(private val ctx: Context) {

    companion object {
        const val OFF = 0
        const val LISTEN = 1
        const val THINK = 2
        const val SPEAK = 3
        const val PAUSED = 4
    }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = ctx.resources.displayMetrics.density
    private val circle = CircleView(ctx)
    private val info = InfoView(ctx)
    private var circleLp: WindowManager.LayoutParams? = null
    private var infoLp: WindowManager.LayoutParams? = null
    private var attached = false

    private var pillW = 0
    private var pillH = 0
    private var pillTop = 0

    /** Dipanggil dengan jumlah ketukan pada bulatan (1 atau 2). */
    var circleCb: ((Int) -> Unit)? = null

    private fun dp(v: Int): Int = (v * density).toInt()

    private fun baseFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun newLp(w: Int, h: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, baseFlags(), PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    fun show() {
        if (attached) return
        val sw = ctx.resources.displayMetrics.widthPixels
        val c = newLp(dp(40), dp(40))
        c.flags = c.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        c.gravity = Gravity.TOP or Gravity.LEFT
        circle.onTaps = { n -> circleCb?.invoke(n) }
        val i = newLp(min(sw - dp(24), dp(320)), dp(120))
        i.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        circleLp = c
        infoLp = i
        try {
            wm.addView(circle, c)
            wm.addView(info, i)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
        layoutAll()
    }

    fun hide() {
        if (!attached) return
        try { wm.removeView(circle) } catch (e: Exception) {}
        try { wm.removeView(info) } catch (e: Exception) {}
        attached = false
    }

    /** Lebar, tinggi, dan jarak atas pill saat ini (px). */
    private var pillX = 0

    fun setPill(w: Int, h: Int, top: Int, x: Int = 0) {
        pillW = w
        pillH = h
        pillTop = top
        pillX = x
        layoutAll()
    }

    private fun layoutAll() {
        if (!attached) return
        val sw = ctx.resources.displayMetrics.widthPixels
        val c = circleLp ?: return
        val i = infoLp ?: return
        val d = max(dp(34), pillH)
        c.width = d
        c.height = d
        c.x = (sw / 2 + pillX - pillW / 2 + dp(5) - d).coerceIn(0, max(0, sw - d))
        c.y = pillTop + (pillH - d) / 2
        i.y = pillTop + pillH + dp(6)
        i.x = pillX
        try { wm.updateViewLayout(circle, c) } catch (e: Exception) {}
        try { wm.updateViewLayout(info, i) } catch (e: Exception) {}
    }

    fun setGlass(on: Boolean, lvl: Float) {
        circle.glassOn = on
        circle.glassLvl = lvl
        info.glassOn = on
        info.glassLvl = lvl
        circle.invalidate()
        info.invalidate()
    }

    private var stNow = OFF

    fun isOn(): Boolean = stNow != OFF

    fun setState(st: Int) {
        stNow = st
        circle.setState(st)
    }

    /** Teks ucapan robot (null untuk menyembunyikan). */
    fun setCaption(text: String?) {
        info.caption = text
        info.invalidate()
    }

    /** Penghitung ketukan: titik-titik dan keterangan. n = 0 untuk menyembunyikan. */
    fun setTapHint(n: Int, label: String?) {
        info.tapN = n
        info.tapLabel = label
        info.invalidate()
    }

    // ---------- bulatan ----------

    private class CircleView(ctx: Context) : View(ctx) {
        var glassOn = true
        var glassLvl = 0.55f
        var onTaps: ((Int) -> Unit)? = null
        private var taps = 0
        private val tapRun = Runnable {
            val n = taps
            taps = 0
            onTaps?.invoke(n)
        }
        private var state = OFF
        private var appear = 0f

        override fun onTouchEvent(ev: android.view.MotionEvent): Boolean {
            if (ev.actionMasked == android.view.MotionEvent.ACTION_DOWN) return state != OFF
            if (ev.actionMasked == android.view.MotionEvent.ACTION_UP) {
                taps++
                removeCallbacks(tapRun)
                postDelayed(tapRun, 380L)
                return true
            }
            return true
        }
        private var last = 0L
        private val d = ctx.resources.displayMetrics.density
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val cyan = Color.rgb(110, 225, 255)

        fun setState(s: Int) {
            state = s
            invalidate()
        }

        override fun onDraw(c: Canvas) {
            val now = SystemClock.uptimeMillis()
            val dt = if (last == 0L) 0.016f else min(0.1f, (now - last) / 1000f)
            last = now
            val target = if (state == OFF) 0f else 1f
            appear += (target - appear) * min(1f, dt * 9f)
            if (appear < 0.01f) { if (state != OFF) postInvalidateOnAnimation(); return }
            val t = now / 1000f
            val w = width.toFloat()
            val h = height.toFloat()
            val sc = 0.6f + 0.4f * appear
            val rad = min(w, h) / 2f * sc
            val cx = w / 2f
            val cy = h / 2f
            rect.set(cx - rad, cy - rad, cx + rad, cy + rad)
            if (glassOn) {
                Glass.draw(c, rect, rad, glassLvl, appear, ((now % 5200L) / 5200f) * 1.7f - 0.35f, d)
            } else {
                p.style = Paint.Style.FILL
                p.color = Color.argb((255 * appear).toInt(), 0, 0, 0)
                c.drawCircle(cx, cy, rad, p)
            }
            val a = appear
            p.style = Paint.Style.FILL
            // leher penyambung ke pill supaya bulatan terlihat menyatu seperti tetesan
            if (appear > 0.05f) {
                val nh = h * 0.40f
                val neck = RectF(cx, cy - nh / 2f, w, cy + nh / 2f)
                p.color = Color.argb((235 * appear).toInt(), 6, 10, 18)
                c.drawRoundRect(neck, nh / 2f, nh / 2f, p)
                p.color = Color.argb((60 * appear).toInt(), 140, 215, 255)
                p.style = Paint.Style.STROKE
                p.strokeWidth = d
                c.drawRoundRect(neck, nh / 2f, nh / 2f, p)
                p.style = Paint.Style.FILL
            }
            when (state) {
                LISTEN -> {
                    val ph = (t * 0.9f) % 1f
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 1.4f * d
                    p.color = Color.argb((120 * (1f - ph) * a).toInt(), 110, 225, 255)
                    c.drawCircle(cx, cy, rad * (0.35f + 0.55f * ph), p)
                    p.style = Paint.Style.FILL
                    p.color = Color.argb((255 * a).toInt(), 110, 225, 255)
                    c.drawCircle(cx, cy, rad * (0.26f + 0.04f * sin(t * 6f)), p)
                }
                THINK -> {
                    p.color = Color.argb((255 * a).toInt(), 110, 225, 255)
                    for (i in 0 until 3) {
                        val ang = t * 4f + i * 2.094f
                        c.drawCircle(cx + cos(ang) * rad * 0.42f, cy + sin(ang) * rad * 0.42f, rad * 0.14f, p)
                    }
                }
                PAUSED -> {
                    p.color = Color.argb((200 * a).toInt(), 200, 205, 215)
                    for (i in 0 until 2) {
                        val bx = cx + (i - 0.5f) * rad * 0.42f
                        rect.set(bx - rad * 0.09f, cy - rad * 0.3f, bx + rad * 0.09f, cy + rad * 0.3f)
                        c.drawRoundRect(rect, rad * 0.09f, rad * 0.09f, p)
                    }
                }
                SPEAK -> {
                    p.color = Color.argb((255 * a).toInt(), 110, 225, 255)
                    for (i in 0 until 4) {
                        val bh = rad * (0.25f + 0.55f * abs(sin(t * 7f + i * 1.3f)))
                        val bx = cx + (i - 1.5f) * rad * 0.34f
                        rect.set(bx - rad * 0.09f, cy - bh / 2f, bx + rad * 0.09f, cy + bh / 2f)
                        c.drawRoundRect(rect, rad * 0.09f, rad * 0.09f, p)
                    }
                }
            }
            postInvalidateOnAnimation()
        }
    }

    // ---------- info (teks + ketukan) ----------

    private class InfoView(ctx: Context) : View(ctx) {
        var glassOn = true
        var glassLvl = 0.55f
        var caption: String? = null
            set(v) {
                if (v != field) { field = v; shown = if (v != null) v else shown; capT0 = SystemClock.uptimeMillis() }
            }
        var tapN = 0
        var tapLabel: String? = null

        private var shown: String? = null
        private var capT0 = 0L
        private var appear = 0f
        private var last = 0L
        private val d = ctx.resources.displayMetrics.density
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

        override fun onDraw(c: Canvas) {
            val now = SystemClock.uptimeMillis()
            val dt = if (last == 0L) 0.016f else min(0.1f, (now - last) / 1000f)
            last = now
            val hintOn = tapN > 0
            val capOn = !hintOn && caption != null
            val target = if (hintOn || capOn) 1f else 0f
            appear += (target - appear) * min(1f, dt * 10f)
            if (appear < 0.01f) {
                if (target > 0f) postInvalidateOnAnimation()
                return
            }
            val w = width.toFloat()
            val a = appear
            if (hintOn) {
                drawHint(c, w, a)
            } else {
                val txt = shown ?: return
                drawCaption(c, w, a, txt)
            }
            if (target > 0f || appear > 0.02f) postInvalidateOnAnimation()
        }

        private fun drawCaption(c: Canvas, w: Float, a: Float, txt: String) {
            tp.textSize = 13f * d
            tp.alpha = (255 * a).toInt()
            val maxW = (w - 28f * d).toInt()
            val lay = StaticLayout.Builder.obtain(txt, 0, txt.length, tp, maxW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.05f).build()
            var tw = 0f
            for (i in 0 until lay.lineCount) tw = max(tw, lay.getLineWidth(i))
            val bw = min(w, tw + 28f * d)
            val bh = lay.height + 16f * d
            val l = (w - bw) / 2f
            val slide = (1f - a) * -6f * d
            rect.set(l, slide, l + bw, slide + bh)
            val r = min(bh / 2f, 18f * d)
            if (glassOn) Glass.draw(c, rect, r, glassLvl, a, ((SystemClock.uptimeMillis() % 5200L) / 5200f) * 1.7f - 0.35f, d)
            else { p.style = Paint.Style.FILL; p.color = Color.argb((235 * a).toInt(), 0, 0, 0); c.drawRoundRect(rect, r, r, p) }
            c.save()
            c.translate(l + bw / 2f - maxW / 2f, slide + 8f * d)
            lay.draw(c)
            c.restore()
        }

        private fun drawHint(c: Canvas, w: Float, a: Float) {
            val n = min(tapN, 8)
            val label = tapLabel ?: ""
            tp.textSize = 11f * d
            tp.alpha = (255 * a).toInt()
            val tw = tp.measureText(label)
            val dots = n * 9f * d
            val bw = max(dots, tw) + 24f * d
            val bh = 14f * d + 18f * d + (if (label.isEmpty()) 0f else 4f * d)
            rect.set((w - bw) / 2f, 0f, (w + bw) / 2f, bh)
            val r = min(bh / 2f, 14f * d)
            if (glassOn) Glass.draw(c, rect, r, glassLvl, a, 0.5f, d)
            else { p.style = Paint.Style.FILL; p.color = Color.argb((235 * a).toInt(), 0, 0, 0); c.drawRoundRect(rect, r, r, p) }
            p.style = Paint.Style.FILL
            p.color = Color.argb((255 * a).toInt(), 110, 225, 255)
            val sx = (w - dots) / 2f + 4.5f * d
            for (i in 0 until n) c.drawCircle(sx + i * 9f * d, 11f * d, 3f * d, p)
            if (label.isNotEmpty()) c.drawText(label, (w - tw) / 2f, bh - 8f * d, tp)
        }
    }
}
