package com.kirnai.dynamicisland

const val PREFS = "island_prefs"
const val KEY_ENABLED = "enabled"
const val KEY_TOP = "top_dp"
const val KEY_W = "idle_w_dp"
const val KEY_H = "idle_h_dp"
const val KEY_TOUCH = "touch_enabled"
const val KEY_BREAK = "eye_break_enabled"
const val KEY_BREAK_MIN = "eye_break_min"
const val KEY_ACTIVITY = "activity_level"
