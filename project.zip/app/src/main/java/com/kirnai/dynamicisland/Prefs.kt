package com.kirnai.dynamicisland

const val PREFS = "island_prefs"
const val KEY_ENABLED = "enabled"
const val KEY_IDLE = "idle_visible"
const val KEY_TOP = "top_dp"
const val KEY_W = "idle_w_dp"
const val KEY_H = "idle_h_dp"
