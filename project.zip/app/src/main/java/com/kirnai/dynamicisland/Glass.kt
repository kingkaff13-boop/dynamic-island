package com.kirnai.dynamicisland

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.min

/**
 * Kaca cair buatan sendiri (sama dengan versi artefak): isi gelap tembus pandang,
 * cahaya bias di dasar, kilau di atas, kilau yang bergerak, dan tepi mengilap.
 * Gambar di balik pill tidak bisa dibiaskan sungguhan, jadi ini kaca tiruan.
 */
object Glass {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val clipPath = Path()
    private val rr = RectF()
    private val pos4 = floatArrayOf(0f, 0.3f, 0.7f, 1f)
    private val pos3 = floatArrayOf(0f, 0.5f, 1f)

    private fun a(alpha: Float, r: Int, g: Int, b: Int): Int =
        Color.argb((alpha.coerceIn(0f, 1f) * 255f).toInt(), r, g, b)

    /**
     * tint: 0..1 seberapa pekat isi kaca. alpha: untuk muncul dan hilang halus.
     * sheen: posisi kilau yang bergerak (0..1 melintasi lebar, di luar itu tidak terlihat).
     * d: density layar.
     */
    private var cache: Bitmap? = null
    private var cacheKey = ""
    private var lastKey = ""
    private var sheenShader: LinearGradient? = null
    private var sheenH = -1f
    private val sheenM = Matrix()
    private val sheenP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val src = Rect()
    private val dst = RectF()

    /** Pakai gambar tersimpan kalau ukuran dan warna tidak berubah. Hanya kilau yang digambar tiap frame. */
    @Synchronized
    fun draw(c: Canvas, rect: RectF, r: Float, tint: Float, alpha: Float, sheen: Float, d: Float) {
        if (alpha <= 0.01f || rect.width() < 2f || rect.height() < 2f) return
        val w = Math.round(rect.width())
        val h = Math.round(rect.height())
        val key = "$w,$h,${Math.round(r)},${Math.round(tint * 100f)},${Math.round(alpha * 40f)},${Math.round(d * 10f)}"
        if (key == cacheKey && cache != null) {
            val bm = cache!!
            dst.set(rect.left, rect.top, rect.left + w, rect.top + h)
            c.drawBitmap(bm, rect.left, rect.top, null)
            drawSheen(c, rect, r, alpha, sheen)
            return
        }
        if (key == lastKey && w * h < 1_500_000) {
            // dua frame berturut-turut sama: simpan
            try {
                val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val bc = Canvas(bm)
                val rr0 = RectF(0f, 0f, w.toFloat(), h.toFloat())
                drawLive(bc, rr0, r, tint, alpha, -5f, d)
                cache?.recycle()
                cache = bm
                cacheKey = key
            } catch (e: Throwable) {
                cache = null
                cacheKey = ""
            }
        }
        lastKey = key
        drawLive(c, rect, r, tint, alpha, sheen, d)
    }

    private fun drawSheen(c: Canvas, rect: RectF, r: Float, alpha: Float, sheen: Float) {
        val h = rect.height()
        if (sheenShader == null || sheenH != h) {
            sheenShader = LinearGradient(
                -h * 1.2f, 0f, h * 1.2f, h,
                intArrayOf(a(0f, 255, 255, 255), a(0.20f, 255, 255, 255), a(0f, 255, 255, 255)),
                pos3, Shader.TileMode.CLAMP
            )
            sheenH = h
        }
        val sx = rect.left + sheen * rect.width()
        if (sx < rect.left - h * 1.3f || sx > rect.right + h * 1.3f) return
        sheenM.setTranslate(sx, rect.top)
        sheenShader!!.setLocalMatrix(sheenM)
        sheenP.shader = sheenShader
        sheenP.alpha = (alpha * 255f).toInt().coerceIn(0, 255)
        c.save()
        clipPath.reset()
        clipPath.addRoundRect(rect, r, r, Path.Direction.CW)
        c.clipPath(clipPath)
        c.drawRect(rect, sheenP)
        c.restore()
    }

    private fun drawLive(c: Canvas, rect: RectF, r: Float, tint: Float, alpha: Float, sheen: Float, d: Float) {
        val l = rect.left
        val t = rect.top
        val rt = rect.right
        val b = rect.bottom
        val w = rect.width()
        val h = rect.height()

        c.save()
        clipPath.reset()
        clipPath.addRoundRect(rect, r, r, Path.Direction.CW)
        c.clipPath(clipPath)

        // isi dasar
        fillP.shader = LinearGradient(
            0f, t, 0f, b,
            a(tint * 0.9f * alpha, 30, 46, 72), a(min(0.97f, tint * 1.15f) * alpha, 4, 8, 15),
            Shader.TileMode.CLAMP
        )
        c.drawRect(rect, fillP)

        // cahaya bias di dasar
        fillP.shader = LinearGradient(
            0f, b, 0f, t + h * 0.45f,
            a(0.22f * alpha, 140, 215, 255), a(0f, 140, 215, 255), Shader.TileMode.CLAMP
        )
        c.drawRect(rect, fillP)

        // kilau di atas
        rr.set(l + 1.5f * d, t + 1f * d, rt - 1.5f * d, t + h * 0.6f)
        fillP.shader = LinearGradient(
            0f, t, 0f, t + h * 0.6f,
            a(0.30f * alpha, 255, 255, 255), a(0f, 255, 255, 255), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rr, r * 0.9f, r * 0.9f, fillP)

        // kilau yang bergerak (sheen < -1 = dilewati, digambar terpisah oleh versi tersimpan)
        if (sheen > -1f) {
            val sx = l + sheen * w
            fillP.shader = LinearGradient(
                sx - h * 1.2f, t, sx + h * 1.2f, b,
                intArrayOf(a(0f, 255, 255, 255), a(0.20f * alpha, 255, 255, 255), a(0f, 255, 255, 255)),
                pos3, Shader.TileMode.CLAMP
            )
            c.drawRect(rect, fillP)
        }
        fillP.shader = null
        c.restore()

        // tepi mengilap
        rimP.strokeWidth = d
        rimP.shader = LinearGradient(
            l, t, rt, b,
            intArrayOf(
                a(0.92f * alpha, 255, 255, 255), a(0.22f * alpha, 255, 255, 255),
                a(0.12f * alpha, 255, 255, 255), a(0.65f * alpha, 255, 255, 255)
            ),
            pos4, Shader.TileMode.CLAMP
        )
        rr.set(l + 0.5f * d, t + 0.5f * d, rt - 0.5f * d, b - 0.5f * d)
        c.drawRoundRect(rr, max(0f, r - 0.5f * d), max(0f, r - 0.5f * d), rimP)
        rimP.shader = null
        rimP.color = a(0.30f * alpha, 110, 225, 255)
        rimP.strokeWidth = 0.6f * d
        rr.set(l + 1.6f * d, t + 1.6f * d, rt - 1.6f * d, b - 1.6f * d)
        c.drawRoundRect(rr, max(0f, r - 1.6f * d), max(0f, r - 1.6f * d), rimP)
    }
}
