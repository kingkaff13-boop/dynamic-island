package com.kirnai.dynamicisland

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Pill hitam dengan sepasang mata menyala. Semua ekspresi digambar di sini.
 * Saat diam (IDLE) dan tidak ada gerakan, view tidak menggambar ulang sama sekali.
 */
class RobotView(ctx: Context) : View(ctx) {

    private enum class Look { BAR, ARC_UP, SLANT, CHEVRON, EMOJI }

    /** Tinggi pill saat diam (px). Ukuran mata mengikuti nilai ini. */
    var baseH = 0f

    private var act = Act.IDLE
    private var actStart = SystemClock.uptimeMillis()
    private var badgeOverride: String? = null
    private var blinkStart = -1L
    private var gazeX = 0f
    private var gazeY = 0f
    private var targetX = 0f
    private var targetY = 0f
    private var sideAmount = 0f

    private val density = ctx.resources.displayMetrics.density
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val path = Path()

    fun setAct(a: Act, badge: String? = null) {
        act = a
        badgeOverride = badge
        actStart = SystemClock.uptimeMillis()
        targetX = 0f
        targetY = 0f
        invalidate()
    }

    /** Detik sejak aksi terakhir dimulai. */
    fun elapsed(): Float = (SystemClock.uptimeMillis() - actStart) / 1000f

    fun blink() {
        blinkStart = SystemClock.uptimeMillis()
        invalidate()
    }

    /** Arahkan pandangan: x, y di rentang -1..1. */
    fun lookAt(x: Float, y: Float) {
        targetX = x
        targetY = y
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = (now - actStart) / 1000f
        val w = width.toFloat()
        val h = height.toFloat()
        val u = if (baseH > 0f) baseH else h

        // badan pill
        val r = min(h / 2f, 26f * density)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, bgPaint)

        // pandangan mengejar target dengan halus
        gazeX += (targetX - gazeX) * 0.18f
        gazeY += (targetY - gazeY) * 0.18f
        var needFrames = abs(targetX - gazeX) > 0.01f || abs(targetY - gazeY) > 0.01f

        // pose default
        var lookL = Look.BAR
        var lookR = Look.BAR
        var color = CYAN
        var open = 1f
        var scale = 1f
        var dx = 0f
        var dy = 0f
        var badge: String? = null
        var badgeX = w * 0.82f
        var badgeY = h / 2f
        var label: String? = null
        var labelColor = 0
        var side = 0f
        var tear = false
        var flash = 0f

        when (act) {
            Act.IDLE -> {
                dx = gazeX * u * 0.35f
                dy = gazeY * u * 0.14f
            }

            Act.HAPPY -> {
                lookL = Look.ARC_UP
                lookR = Look.ARC_UP
                dy = -abs(sin(t * 7f)) * u * 0.07f * max(0f, 1f - t / 1.6f)
            }

            Act.SAD -> {
                lookL = Look.SLANT
                lookR = Look.SLANT
                color = SAD_BLUE
                dy = u * 0.06f
                tear = true
            }

            Act.SLEEPY -> {
                open = 0.16f + 0.10f * (0.5f + 0.5f * sin(t * 2.2f))
                dy = u * 0.08f
                color = DIM_CYAN
                badge = "💤"
                badgeX = w * 0.80f
                badgeY = h * (0.50f - 0.14f * ((t * 0.6f) % 1f))
            }

            Act.SURPRISE -> {
                scale = 1f + 0.38f * max(0f, 1f - t / 1.1f)
                dx = sin(t * 40f) * u * 0.015f * max(0f, 1f - t)
            }

            Act.WINK -> {
                lookR = Look.ARC_UP
            }

            Act.LAUGH -> {
                lookL = Look.CHEVRON
                lookR = Look.CHEVRON
                dy = sin(t * 28f) * u * 0.035f
            }

            Act.HOT -> {
                lookL = Look.CHEVRON
                lookR = Look.CHEVRON
                color = ORANGE
                dx = sin(t * 34f) * u * 0.02f
                side = 1f
                badge = "💦"
                badgeX = w * 0.80f
                badgeY = h * (0.40f + 0.08f * sin(t * 6f))
            }

            Act.PHOTO -> {
                side = 1f
                if (t < 2.65f) {
                    lookL = Look.EMOJI
                    lookR = Look.EMOJI
                    scale = min(1f, t / 0.35f)
                    if (t in 0.5f..2.45f) {
                        val n = 3 - floor((t - 0.5f) / 0.65f).toInt()
                        label = n.coerceIn(1, 3).toString()
                        labelColor = Color.WHITE
                        scale *= 1f + 0.08f * sin(t * 12f)
                    }
                } else {
                    lookL = Look.ARC_UP
                    lookR = Look.ARC_UP
                    badge = "✨"
                    badgeX = w * 0.80f
                }
                flash = max(0f, 1f - abs(t - 2.55f) / 0.12f)
            }

            Act.DANCE -> {
                val phase = t * 2.2f * TWO_PI
                val bounce = abs(sin(phase / 2f))
                dy = -bounce * u * 0.14f
                open = 1f + 0.20f * bounce
                dx = sin(phase / 4f) * u * 0.45f
                color = Color.HSVToColor(floatArrayOf((t * 140f) % 360f, 0.7f, 1f))
                badge = "🎵"
                val k = (t * 2.2f).toInt()
                badgeX = if (k % 2 == 0) w * 0.14f else w * 0.86f
                badgeY = h * (0.62f - 0.30f * ((t * 2.2f) % 1f))
            }

            Act.EXERCISE -> {
                side = 1f
                color = GREEN
                val s = t - 2f
                if (t < 2f) {
                    scale = 1f + 0.10f * sin(t * 6f)
                    label = "Ikuti!"
                } else if (t < 22f) {
                    var gx = 0f
                    var gy = 0f
                    val arrow: String
                    when ((s / 4f).toInt()) {
                        0 -> {
                            gx = -1f
                            arrow = "←"
                        }
                        1 -> {
                            gx = 1f
                            arrow = "→"
                        }
                        2 -> {
                            gy = -1f
                            arrow = "↑"
                        }
                        3 -> {
                            gy = 1f
                            arrow = "↓"
                        }
                        else -> {
                            val a = (s - 16f) / 4f * TWO_PI * 1.5f
                            gx = cos(a)
                            gy = sin(a)
                            arrow = "↻"
                        }
                    }
                    targetX = gx
                    targetY = gy
                    dx = gazeX * u * 0.5f
                    dy = gazeY * u * 0.22f
                    val remaining = (20 - floor(s).toInt()).coerceIn(1, 20)
                    label = "$arrow $remaining"
                } else {
                    lookL = Look.ARC_UP
                    lookR = Look.ARC_UP
                    label = "Bagus!"
                }
            }
        }

        // kedip
        if (blinkStart >= 0L) {
            val p = (now - blinkStart) / 170f
            if (p >= 1f) {
                blinkStart = -1L
            } else {
                open *= max(0.06f, abs(1f - 2f * p))
                needFrames = true
            }
        }

        // posisi mata: bergeser ke kiri jika ada teks di sisi kanan
        sideAmount += (side - sideAmount) * 0.2f
        if (abs(side - sideAmount) > 0.01f) needFrames = true
        val cx = w * (0.5f - 0.14f * sideAmount)

        val ew = u * 0.20f * scale
        val eh = u * 0.46f * scale
        val gap = u * 0.55f
        val cy = h / 2f + dy
        val lx = cx - gap + dx
        val rx = cx + gap + dx
        drawEye(canvas, lx, cy, lookL, color, ew, eh, open, true)
        drawEye(canvas, rx, cy, lookR, color, ew, eh, open, false)

        if (tear) {
            val p = (t * 0.7f) % 1f
            fill.color = withAlpha(TEAR, ((1f - p) * 255f).toInt().coerceIn(0, 255))
            canvas.drawCircle(lx - u * 0.12f, cy + eh * 0.35f + p * u * 0.30f, u * 0.065f, fill)
            needFrames = true
        }

        val shownBadge = badgeOverride ?: badge
        if (shownBadge != null) {
            textPaint.textSize = u * 0.5f
            textPaint.color = Color.WHITE
            drawCentered(canvas, shownBadge, badgeX, badgeY + sin(t * 5f) * u * 0.04f)
        }

        if (label != null) {
            textPaint.textSize = u * 0.42f
            textPaint.color = if (labelColor != 0) labelColor else color
            drawCentered(canvas, label, w * 0.80f, h / 2f)
        }

        if (flash > 0f) {
            rect.set(0f, 0f, w, h)
            fill.color = Color.argb((flash * 235f).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawRoundRect(rect, r, r, fill)
            needFrames = true
        }

        if (act != Act.IDLE) needFrames = true
        if (needFrames) postInvalidateOnAnimation()
    }

    private fun drawEye(
        c: Canvas,
        x: Float,
        y: Float,
        look: Look,
        color: Int,
        ew: Float,
        eh: Float,
        open: Float,
        left: Boolean
    ) {
        when (look) {
            Look.BAR -> {
                val hh = eh * open
                for (k in 3 downTo 1) {
                    fill.color = withAlpha(color, 26)
                    val g = ew * 0.22f * k
                    rect.set(x - ew / 2f - g, y - hh / 2f - g, x + ew / 2f + g, y + hh / 2f + g)
                    c.drawRoundRect(rect, ew / 2f + g, ew / 2f + g, fill)
                }
                fill.color = color
                rect.set(x - ew / 2f, y - hh / 2f, x + ew / 2f, y + hh / 2f)
                val rr = min(ew / 2f, hh / 2f)
                c.drawRoundRect(rect, rr, rr, fill)
            }

            Look.ARC_UP -> {
                val rad = eh * 0.52f
                rect.set(x - rad, y + rad * 0.5f - rad, x + rad, y + rad * 0.5f + rad)
                val sw = ew * 0.95f
                for (k in 3 downTo 1) {
                    stroke.color = withAlpha(color, 28)
                    stroke.strokeWidth = sw + sw * 0.45f * k
                    c.drawArc(rect, 200f, 140f, false, stroke)
                }
                stroke.color = color
                stroke.strokeWidth = sw
                c.drawArc(rect, 200f, 140f, false, stroke)
            }

            Look.SLANT -> {
                val half = ew * 1.35f
                val rise = eh * 0.22f
                val sx = if (left) -1f else 1f
                path.reset()
                path.moveTo(x + sx * half, y + rise)
                path.lineTo(x - sx * half, y - rise)
                strokePath(c, color, ew * 0.95f)
            }

            Look.CHEVRON -> {
                val s = eh * 0.38f
                val dir = if (left) 1f else -1f
                path.reset()
                path.moveTo(x - dir * s, y - s)
                path.lineTo(x + dir * s * 0.7f, y)
                path.lineTo(x - dir * s, y + s)
                strokePath(c, color, ew * 0.9f)
            }

            Look.EMOJI -> {
                textPaint.textSize = eh * 1.35f
                textPaint.color = Color.WHITE
                drawCentered(c, "📷", x, y)
            }
        }
    }

    private fun strokePath(c: Canvas, color: Int, sw: Float) {
        for (k in 3 downTo 1) {
            stroke.color = withAlpha(color, 28)
            stroke.strokeWidth = sw + sw * 0.45f * k
            c.drawPath(path, stroke)
        }
        stroke.color = color
        stroke.strokeWidth = sw
        c.drawPath(path, stroke)
    }

    private fun drawCentered(c: Canvas, s: String, x: Float, y: Float) {
        val fm = textPaint.fontMetrics
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    companion object {
        private val TWO_PI = (2.0 * PI).toFloat()
        private val CYAN = Color.parseColor("#38E8FF")
        private val DIM_CYAN = Color.parseColor("#2B9DB0")
        private val SAD_BLUE = Color.parseColor("#5AA8FF")
        private val TEAR = Color.parseColor("#9BEFFF")
        private val GREEN = Color.parseColor("#3DFF8B")
        private val ORANGE = Color.parseColor("#FF9F1C")
    }
}
