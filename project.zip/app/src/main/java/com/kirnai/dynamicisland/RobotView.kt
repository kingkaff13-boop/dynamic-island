package com.kirnai.dynamicisland

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Pill hitam dengan sepasang mata menyala. Semua ekspresi, ikon, pesawat, dan
 * pemandangan mancing digambar di sini (tanpa emoji bawaan HP).
 */
class RobotView(ctx: Context) : View(ctx) {

    private enum class Look { BAR, ARC, SLANT, CHEV, ANGRY, SQUINT, SPIRAL, CAMERA }

    private class Ic(
        val k: String, val x: Float, val y: Float, val s: Float, val col: Int,
        val a: Float = 1f, val wob: Boolean = false, val rot: Float = 0f,
        val lvl: Float = 0f, val spin: Float = 0f, val off: Boolean = false
    )

    /** Tinggi pill saat diam (px). Ukuran mata mengikuti nilai ini. */
    var baseH = 0f

    var colorIdx = 0
    var shapeIdx = 0
    var robotName = "Beepo"
    var prayerName = ""
    var volUp = true
    var focusEndMs = 0L
    var focusActive = false
    var airplane = false
        set(v) {
            field = v
            planeT0 = 0L
            planeNext = SystemClock.uptimeMillis() + 600L
            invalidate()
        }
    var torchOn = false
        set(v) {
            field = v
            invalidate()
        }

    val fish = FishModel()

    private var act = Act.IDLE
    private var actStart = SystemClock.uptimeMillis()
    private var badgeOverride: String? = null
    private var blinkStart = -1L
    private var gazeX = 0f
    private var gazeY = 0f
    private var targetX = 0f
    private var targetY = 0f
    private var sideAmount = 0f
    private var torchLevel = 0f
    private var lastFrame = 0L
    private var planeT0 = 0L
    private var planeNext = 0L
    private var planeDir = 1
    private val rnd = Random()

    private val density = ctx.resources.displayMetrics.density
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val path = Path()
    private val icons = ArrayList<Ic>()

    fun setAct(a: Act, badge: String? = null) {
        act = a
        badgeOverride = badge
        actStart = SystemClock.uptimeMillis()
        targetX = 0f
        targetY = 0f
        invalidate()
    }

    fun blink() {
        blinkStart = SystemClock.uptimeMillis()
        invalidate()
    }

    fun lookAt(x: Float, y: Float) {
        targetX = x
        targetY = y
        invalidate()
    }

    /** Tinggi jendela yang dibutuhkan saat mancing, untuk lebar jendela w (px). */
    fun fishingHeight(w: Float): Int = (baseH + 86f * w / FishModel.PW).toInt()

    fun startFishing() {
        fish.start(SystemClock.uptimeMillis())
        invalidate()
    }

    fun stopFishing() {
        fish.stop()
        invalidate()
    }

    fun fishLevelUp() {
        fish.levelUp(SystemClock.uptimeMillis())
    }

    // ---------- warna ----------

    private fun baseColor(now: Long): Int = when (colorIdx) {
        0 -> CYAN
        1 -> Color.rgb(61, 255, 139)
        2 -> Color.rgb(182, 156, 255)
        3 -> Color.rgb(255, 120, 200)
        4 -> Color.rgb(255, 170, 60)
        5 -> Color.rgb(235, 245, 255)
        else -> Color.HSVToColor(floatArrayOf((now / 18f) % 360f, 0.7f, 1f))
    }

    private fun mix(a: Int, b: Int, f: Float): Int {
        val ff = f.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * ff).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * ff).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * ff).toInt()
        )
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
    private fun fa(color: Int, a: Float): Int = withAlpha(color, (a * 255f).toInt())

    private fun ic(
        k: String, x: Float, y: Float, s: Float, col: Int = Color.WHITE, a: Float = 1f,
        wob: Boolean = false, rot: Float = 0f, lvl: Float = 0f, spin: Float = 0f, off: Boolean = false
    ) {
        icons.add(Ic(k, x, y, s, col, a, wob, rot, lvl, spin, off))
    }

    // ---------- gambar utama ----------

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0.016f else min(0.1f, (now - lastFrame) / 1000f)
        lastFrame = now
        val w = width.toFloat()
        val u = if (baseH > 0f) baseH else height.toFloat()
        val h = u
        val base = baseColor(now)

        // mancing aktif: kerjakan logika dan gambar pemandangan
        val k = w / FishModel.PW
        val ax = (w / k) * 0.78f
        fish.update(now, dt, ax, FishModel.PILL_BOTTOM)
        val t = if (act == Act.FISH) max(0f, (now - fish.sT0) / 1000f) else max(0f, (now - actStart) / 1000f)
        if (fish.vis > 0.01f || fish.drop != null) {
            drawFishScene(canvas, now, w, u, k, ax)
        }

        // torch
        val tgtTorch = if (torchOn) 1f else 0f
        torchLevel += (tgtTorch - torchLevel) * min(1f, dt * 6f)
        var needFrames = abs(tgtTorch - torchLevel) > 0.01f
        val br = torchLevel

        // badan pill
        val r = min(h / 2f, 26f * density)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, bgPaint)
        if (br > 0.05f) {
            fill.color = fa(Color.rgb(170, 240, 255), 0.10f * br)
            canvas.drawRoundRect(rect, r, r, fill)
        }

        canvas.save()
        canvas.clipRect(0f, 0f, w, h)

        // pandangan mengejar target dengan halus
        val kg = min(1f, dt * 12f)
        gazeX += (targetX - gazeX) * kg
        gazeY += (targetY - gazeY) * kg
        if (abs(targetX - gazeX) > 0.01f || abs(targetY - gazeY) > 0.01f) needFrames = true

        // pose default
        var lookL = Look.BAR
        var lookR = Look.BAR
        var color = base
        var open = 1f
        var scale = 1f
        var scaleL = 1f
        var scaleR = 1f
        var openL = 1f
        var openR = 1f
        var dx = 0f
        var dy = 0f
        var dyL = 0f
        var dyR = 0f
        var side = 0f
        var tear = false
        var tiltL = 0f
        var tiltR = 0f
        var label: String? = null
        var labelX = 0.8f
        var labelColor = 0
        var flash = 0f
        var spin = 0f
        icons.clear()

        val shown = act
        when (shown) {
            Act.IDLE -> {
                dx = gazeX * u * 0.35f
                dy = gazeY * u * 0.14f
            }

            Act.HAPPY -> {
                lookL = Look.ARC; lookR = Look.ARC
                dy = -abs(sin(t * 7f)) * u * 0.07f * max(0f, 1f - t / 1.6f)
                if (badgeOverride == "bolt") ic("bolt", .84f, .5f, u * .5f, YELLOW, wob = true)
                if (badgeOverride == "wifi") ic("wifi", .84f, .5f, u * .42f, GREEN, wob = true)
            }

            Act.SAD -> {
                lookL = Look.SLANT; lookR = Look.SLANT
                color = SAD_BLUE; dy = u * 0.06f; tear = true
                if (badgeOverride == "battery") ic("battery", .84f, .5f, u * .6f, RED, lvl = .12f)
                if (badgeOverride == "nowifi") ic("wifi", .84f, .5f, u * .42f, Color.rgb(220, 230, 240), off = true)
            }

            Act.ANGRY -> {
                lookL = Look.ANGRY; lookR = Look.ANGRY; color = RED
                dx = sin(t * 45f) * u * 0.02f
                ic("anger", .84f, .46f, u * (0.42f + 0.07f * sin(t * 14f)) * min(1f, t / 0.25f), RED)
            }

            Act.ANNOYED -> {
                color = Color.rgb(255, 190, 90); openL = .42f; openR = .42f; tiltL = .2f; tiltR = -.2f
                dx = sin(t * 3f) * u * 0.1f
                ic("anger", .82f, .46f, u * 0.26f * min(1f, t / 0.3f), ORANGE)
            }

            Act.SURPRISE -> {
                scale = 1f + 0.38f * max(0f, 1f - t / 1.1f)
                dx = sin(t * 40f) * u * 0.015f * max(0f, 1f - t)
                if (t < 1.4f) ic("exclaim", .83f, .5f, u * .5f, YELLOW)
            }

            Act.LAUGH -> {
                lookL = Look.CHEV; lookR = Look.CHEV
                dy = sin(t * 28f) * u * 0.035f
            }

            Act.WINK -> lookR = Look.ARC

            Act.SLEEPY -> {
                open = 0.16f + 0.10f * (0.5f + 0.5f * sin(t * 2.2f))
                dy = u * 0.08f
                color = mix(base, Color.BLACK, 0.42f)
                for (i in 0 until 3) {
                    val ph = ((t * 0.5f) + i / 3f) % 1f
                    ic("zed", .74f + ph * .14f, .66f - ph * .5f, u * (0.14f + 0.09f * i), ICE, a = 1f - ph)
                }
            }

            Act.CONFUSED -> {
                openL = .65f; scaleR = 1.3f; tiltR = -.12f
                dx = sin(t * 2.2f) * u * 0.3f
                ic("question", .82f, .5f, u * .6f, YELLOW, wob = true)
            }

            Act.PEEK -> {
                dy = u * 0.5f; open = 1.15f
                dx = sin(t * 2.2f) * u * 0.55f
            }

            Act.HOT -> {
                lookL = Look.CHEV; lookR = Look.CHEV; color = ORANGE
                dx = sin(t * 34f) * u * 0.02f; side = 1f
                ic("fan", .68f, .5f, u * .46f, spin = t * 12f)
                ic("thermo", .87f, .5f, u * .62f, lvl = (t / 1.8f).coerceIn(0f, 1f) * (0.9f + 0.1f * sin(t * 8f)))
            }

            Act.PHOTO -> {
                side = 1f
                if (t < 2.65f) {
                    lookL = Look.CAMERA; lookR = Look.CAMERA
                    scale = min(1f, t / 0.35f)
                    if (t in 0.5f..2.45f) {
                        label = (3 - floor((t - 0.5f) / 0.65f).toInt()).coerceIn(1, 3).toString()
                        labelColor = Color.WHITE
                    }
                } else {
                    lookL = Look.ARC; lookR = Look.ARC
                    ic("spark", .8f, .5f, u * .34f, YELLOW, rot = t * 2f)
                    ic("spark", .88f, .3f, u * .2f, Color.WHITE, rot = -t * 2f)
                }
                flash = max(0f, 1f - abs(t - 2.55f) / 0.12f)
            }

            Act.DANCE -> {
                val ph = t * 2.2f * TWO_PI
                val bn = abs(sin(ph / 2f))
                dy = -bn * u * 0.14f; open = 1f + 0.2f * bn
                dx = sin(ph / 4f) * u * 0.45f
                color = Color.HSVToColor(floatArrayOf((t * 140f) % 360f, 0.7f, 1f))
                val kk = (t * 2.2f).toInt()
                val fr = (t * 2.2f) % 1f
                ic("note", if (kk % 2 == 1) .86f else .14f, .66f - .34f * fr, u * .5f, Color.WHITE, a = 1f - fr * .6f)
                ic("note", if (kk % 2 == 1) .14f else .86f, .7f - .3f * ((fr + .5f) % 1f), u * .36f, color, a = .7f)
            }

            Act.EXERCISE -> {
                side = 1f; color = GREEN
                val s = t - 2f
                if (t < 2f) {
                    scale = 1f + 0.10f * sin(t * 6f)
                    label = "Ikuti!"
                } else if (t < 22f) {
                    var gx = 0f
                    var gy = 0f
                    var kind = "arrow"
                    var rot = 0f
                    when ((s / 4f).toInt()) {
                        0 -> { gx = -1f; rot = PI.toFloat() }
                        1 -> { gx = 1f }
                        2 -> { gy = -1f; rot = -PI.toFloat() / 2f }
                        3 -> { gy = 1f; rot = PI.toFloat() / 2f }
                        else -> {
                            val a = (s - 16f) / 4f * TWO_PI * 1.5f
                            gx = cos(a); gy = sin(a); kind = "cw"
                        }
                    }
                    targetX = gx; targetY = gy
                    dx = gazeX * u * 0.5f; dy = gazeY * u * 0.22f
                    ic(kind, .72f, .5f, u * .34f, GREEN, rot = rot)
                    label = (20 - floor(s).toInt()).coerceIn(1, 20).toString()
                    labelX = .88f
                } else {
                    lookL = Look.ARC; lookR = Look.ARC
                    label = "Bagus!"
                }
            }

            Act.HEADSET -> {
                lookL = Look.ARC; lookR = Look.ARC
                dy = -abs(sin(t * 5.2f)) * u * 0.08f
                ic("headphone", .5f, .5f, u * 1.43f, rot = 0f)
                ic("note", .5f + (((t * 0.8f) % 1f) - .5f) * .5f, .24f, u * .26f, color, a = .85f)
            }

            Act.VOLUME -> {
                side = 1f
                dy = sin(t * (if (volUp) 9f else 5f)) * u * 0.06f
                ic("speaker", .78f, .5f, u * .5f, lvl = if (volUp) 3f else 1f)
            }

            Act.ADZAN -> {
                side = 1f
                dy = sin(t * 1.6f) * u * 0.04f
                color = mix(base, Color.rgb(255, 235, 180), 0.35f)
                openL = 0.85f + 0.15f * sin(t * 1.6f); openR = openL
                ic("crescent", .64f, .5f, u * .36f, YELLOW)
                ic("star", .74f, .36f, u * .13f, YELLOW, a = .6f + .4f * sin(t * 3f))
                label = prayerName; labelX = .88f; labelColor = YELLOW
            }

            Act.HELLO -> {
                side = 1f
                lookL = Look.ARC; lookR = Look.ARC
                dy = -abs(sin(t * 6f)) * u * 0.06f * max(0f, 1f - t / 1.8f)
                label = robotName; labelX = .76f
                ic("spark", .94f, .3f, u * .16f, YELLOW, rot = t * 2f)
            }

            Act.DIZZY -> {
                lookL = Look.SPIRAL; lookR = Look.SPIRAL; spin = t
                dx = sin(t * 5f) * u * 0.22f; dy = sin(t * 3.3f) * u * 0.04f
                for (i in 0 until 3) {
                    val ang = t * 4f + i * TWO_PI / 3f
                    ic("star", .5f + cos(ang) * (u * 1.05f / w), .2f + sin(ang) * .11f, u * .17f, YELLOW)
                }
            }

            Act.FOCUS -> {
                val rem = max(0L, focusEndMs - now) / 1000L
                side = 1f; openL = .6f; openR = .6f
                if (rem <= 10L) color = ORANGE
                label = String.format("%02d:%02d", rem / 60L, rem % 60L)
                labelX = .86f; labelColor = Color.WHITE
                ic("tomato", .64f, .5f, u * .3f, wob = true)
            }

            Act.FISH -> {
                side = 1f; dy = u * 0.08f
                when (fish.state) {
                    FishModel.CAST -> { dy = u * 0.14f; dx = sin(t * 6f) * u * 0.1f }
                    FishModel.WAIT -> {
                        openL = .55f; openR = .55f; dx = sin(t * 0.9f) * u * 0.15f; dy = u * 0.12f
                    }
                    FishModel.BITE -> {
                        scale = 1.22f; dy = u * 0.06f
                        ic("exclaim", .86f, .5f, u * .5f, YELLOW)
                    }
                    FishModel.REEL -> {
                        lookL = Look.CHEV; lookR = Look.CHEV
                        dx = sin(t * 30f) * u * (0.02f + fish.tension * 0.05f)
                        if (fish.tier >= 3) color = ORANGE
                        ic("tension", .87f, .5f, u * .6f, lvl = fish.tension)
                    }
                    FishModel.SHOW -> {
                        lookL = Look.ARC; lookR = Look.ARC
                        dy = -abs(sin(t * 7f)) * u * 0.07f * max(0f, 1f - t / 1.2f)
                        label = FishModel.kinds[fish.tier].name; labelX = .8f; labelColor = Color.WHITE
                    }
                    FishModel.SNAP -> {
                        lookL = Look.SLANT; lookR = Look.SLANT; color = SAD_BLUE; tear = true
                        dy = u * 0.06f; label = "Putus!"; labelX = .8f; labelColor = Color.WHITE
                    }
                }
            }
        }

        // pesawat di belakang mata
        if (airplane) {
            if (planeT0 == 0L) {
                if (now >= planeNext) {
                    planeT0 = now
                    planeDir = if (rnd.nextBoolean()) 1 else -1
                    Sfx.planePass()
                } else {
                    postInvalidateDelayed(max(16L, min(500L, planeNext - now)))
                }
            }
            if (planeT0 != 0L) {
                val p = (now - planeT0) / PLANE_MS
                if (p >= 1f) {
                    planeT0 = 0L
                    planeNext = now + 3500L + rnd.nextInt(3500)
                } else {
                    drawPlaneInPill(canvas, p, w, h, u)
                    needFrames = true
                }
            }
        }

        // kedip
        if (blinkStart >= 0L) {
            val p = (now - blinkStart) / 170f
            if (p >= 1f) {
                blinkStart = -1L
            } else {
                open *= max(0.06f, abs(1f - 2f * p))
                needFrames = true
            }
        }

        sideAmount += (side - sideAmount) * min(1f, dt * 14f)
        if (abs(side - sideAmount) > 0.01f) needFrames = true
        val cx = w * (0.5f - 0.14f * sideAmount)
        val sc = scale * (1f + 0.12f * br)
        val ew = u * 0.20f * sc
        val eh = u * 0.46f * sc
        val gap = u * 0.55f
        val cy = h / 2f + dy
        val lx = cx - gap + dx
        val rx = cx + gap + dx
        drawEye(canvas, lookL, lx, cy + dyL, color, ew * scaleL, eh * scaleL, open * openL, true, tiltL, br, spin)
        drawEye(canvas, lookR, rx, cy + dyR, color, ew * scaleR, eh * scaleR, open * openR, false, tiltR, br, spin)

        if (tear) {
            val p = (t * 0.7f) % 1f
            fill.color = fa(Color.rgb(155, 239, 255), 1f - p)
            canvas.drawOval(
                lx - u * 0.12f - u * 0.05f, cy + eh * 0.35f + p * u * 0.3f - u * 0.075f,
                lx - u * 0.12f + u * 0.05f, cy + eh * 0.35f + p * u * 0.3f + u * 0.075f, fill
            )
            needFrames = true
        }

        for (i in icons) drawIcon(canvas, i, w, h, t, u)

        if (label != null) {
            textPaint.textSize = u * 0.42f
            textPaint.color = if (labelColor != 0) labelColor else color
            drawCentered(canvas, label, w * labelX, h / 2f)
        }

        if (flash > 0f) {
            fill.color = Color.argb((flash * 235f).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawRect(0f, 0f, w, h, fill)
            needFrames = true
        }
        canvas.restore()

        if (act != Act.IDLE || fish.vis > 0.01f || fish.active || fish.drop != null) needFrames = true
        if (needFrames) postInvalidateOnAnimation()
    }

    // ---------- pesawat ----------

    private fun drawPlane(c: Canvas, x: Float, y: Float, s: Float, dir: Int, col: Int, alpha: Float) {
        c.save()
        c.translate(x, y)
        c.scale(dir.toFloat(), 1f)
        fill.color = fa(col, alpha)
        rect.set(-s, -s * 0.17f, s, s * 0.17f)
        c.drawOval(rect, fill)
        for (m in intArrayOf(1, -1)) {
            val mf = m.toFloat()
            path.reset()
            path.moveTo(s * 0.18f, 0f); path.lineTo(-s * 0.32f, mf * s * 0.95f)
            path.lineTo(-s * 0.56f, mf * s * 0.95f); path.lineTo(-s * 0.24f, 0f); path.close()
            c.drawPath(path, fill)
            path.reset()
            path.moveTo(-s * 0.68f, 0f); path.lineTo(-s * 0.92f, mf * s * 0.4f)
            path.lineTo(-s * 1.04f, mf * s * 0.4f); path.lineTo(-s * 0.9f, 0f); path.close()
            c.drawPath(path, fill)
        }
        c.restore()
    }

    private fun drawPlaneInPill(c: Canvas, p: Float, w: Float, h: Float, u: Float) {
        val s = u * 0.36f
        val span = w + s * 4f
        val x = if (planeDir > 0) -s * 2f + p * span else w + s * 2f - p * span
        val y = h * 0.5f + sin(p * TWO_PI * 0.8f) * h * 0.06f
        for (i in 0 until 10) {
            val bx = x - planeDir * (s * 1.4f + i * s * 0.55f)
            if (bx < 0f || bx > w) continue
            fill.color = fa(Color.rgb(225, 238, 250), 0.26f * (1f - i / 10f))
            c.drawCircle(bx, y, s * 0.1f * (1f - i * 0.05f), fill)
        }
        drawPlane(c, x, y, s, planeDir, Color.rgb(225, 238, 250), 0.5f)
    }

    // ---------- mancing ----------

    private fun drawFishBody(c: Canvas, x: Float, y: Float, len: Float, ang: Float, tier: Int, alpha: Float, wig: Float) {
        val col = FishModel.kinds[tier].col
        c.save()
        c.translate(x, y)
        c.rotate(ang * 180f / PI.toFloat())
        val tw = sin(wig) * len * 0.22f
        fill.color = fa(mix(col, Color.BLACK, 0.25f), alpha)
        path.reset()
        path.moveTo(-len * 0.8f, 0f); path.lineTo(-len * 1.55f, -len * 0.5f + tw)
        path.lineTo(-len * 1.4f, tw * 0.6f); path.lineTo(-len * 1.55f, len * 0.5f + tw); path.close()
        c.drawPath(path, fill)
        path.reset()
        path.moveTo(-len * 0.2f, -len * 0.32f)
        path.lineTo(len * 0.1f, -len * (if (tier == 4) 1.0f else 0.62f))
        path.lineTo(len * 0.35f, -len * 0.32f); path.close()
        c.drawPath(path, fill)
        fill.color = fa(col, alpha)
        rect.set(-len, -len * 0.38f, len, len * 0.38f)
        c.drawOval(rect, fill)
        fill.color = fa(Color.WHITE, alpha * 0.28f)
        rect.set(-len * 0.85f, len * 0.14f - len * 0.18f, len * 0.85f, len * 0.14f + len * 0.18f)
        c.drawOval(rect, fill)
        fill.color = fa(Color.rgb(15, 22, 30), alpha)
        c.drawCircle(len * 0.58f, -len * 0.08f, max(0.7f, len * 0.08f), fill)
        c.restore()
    }

    private fun drawHook(c: Canvas, x: Float, y: Float, alpha: Float) {
        stroke.color = fa(Color.rgb(225, 238, 248), alpha)
        stroke.strokeWidth = 0.9f
        path.reset()
        path.moveTo(x, y - 1f); path.lineTo(x, y + 3f)
        rect.set(x - 4.4f, y + 0.8f, x, y + 5.2f)
        path.arcTo(rect, 0f, 170f)
        c.drawPath(path, stroke)
    }

    private fun drawFishScene(c: Canvas, now: Long, w: Float, u: Float, k: Float, ax: Float) {
        val f = fish
        val A = f.vis * 0.6f
        c.save()
        c.translate(0f, u - FishModel.PILL_BOTTOM * k)
        c.scale(k, k)
        val px = 0f
        val py = FishModel.PY
        val pw = w / k
        val ph = FishModel.PH
        val surf = FishModel.SURF
        // panel (transparan supaya video di belakangnya masih terlihat)
        c.save()
        path.reset()
        rect.set(px, py, px + pw, py + ph)
        path.addRoundRect(rect, 9f, 9f, Path.Direction.CW)
        c.clipPath(path)
        fill.shader = LinearGradient(0f, py, 0f, surf, fa(Color.rgb(27, 53, 88), A), fa(Color.rgb(74, 130, 174), A), Shader.TileMode.CLAMP)
        c.drawRect(px, py, px + pw, surf + 2f, fill)
        fill.shader = LinearGradient(0f, surf, 0f, py + ph, fa(Color.rgb(31, 120, 180), A), fa(Color.rgb(8, 38, 68), A), Shader.TileMode.CLAMP)
        c.drawRect(px, surf, px + pw, py + ph, fill)
        fill.shader = null
        fill.color = fa(Color.rgb(255, 232, 160), A * 0.9f)
        c.drawCircle(px + pw - 28f, py + 10f, 5f, fill)
        for (i in 0 until 3) {
            fill.color = Color.argb((255 * A * (0.26f - i * 0.05f)).toInt().coerceIn(0, 255), 120 + i * 30, 200 + i * 15, 255)
            path.reset()
            path.moveTo(px, py + ph)
            var x = px
            while (x <= px + pw + 4f) {
                path.lineTo(x, surf + i * 3f + sin(x * 0.05f * (1f + i * 0.3f) + now * 0.0016f * (i + 1) + i * 2f) * (1.8f - i * 0.4f))
                x += 4f
            }
            path.lineTo(px + pw, py + ph); path.close()
            c.drawPath(path, fill)
        }
        for (i in 0 until 6) {
            val gx = px + ((i * 47f + now * 0.012f * (1 + (i % 2))) % pw)
            val gl = 0.5f + 0.5f * sin(now * 0.003f + i * 2f)
            fill.color = fa(Color.WHITE, A * 0.7f * gl)
            c.drawRect(gx, surf + 1f + (i % 3) * 2f, gx + 6f, surf + 1.9f + (i % 3) * 2f, fill)
        }
        fill.color = fa(Color.WHITE, A * 0.25f)
        for (i in 0 until 5) {
            val ph2 = ((now * 0.00025f * (1f + i * 0.2f)) + i * 0.37f) % 1f
            c.drawCircle(px + 20f + i * 52f + sin(ph2 * 9f + i) * 4f, py + ph - ph2 * (ph - 12f), 1.1f + (i % 2) * 0.5f, fill)
        }
        for (s in f.swimmers) {
            drawFishBody(c, s.x, s.y, FishModel.kinds[s.tier].len * 0.8f, if (s.dir > 0) 0f else PI.toFloat(), s.tier, A * 0.5f, now * 0.012f + s.x * 0.2f)
        }
        if (f.active && f.state == FishModel.WAIT) {
            drawFishBody(c, f.targetX, f.targetY, FishModel.kinds[f.tier].len, if (f.targetDir > 0) 0f else PI.toFloat(), f.tier, min(1f, A * 1.4f), now * 0.012f)
        }
        if (f.active && f.state == FishModel.BITE) {
            drawFishBody(
                c, f.hookX - f.targetDir * FishModel.kinds[f.tier].len * 0.9f, f.hookY + 1f, FishModel.kinds[f.tier].len,
                if (f.targetDir > 0) 0f else PI.toFloat(), f.tier, min(1f, A * 1.4f), now * 0.05f
            )
        }
        stroke.strokeWidth = 0.7f
        for (r in f.ripples) {
            val kk = (now - r.t0) / 1400f
            stroke.color = fa(Color.WHITE, A * 0.8f * (1f - kk))
            rect.set(r.x - (4f + kk * 22f), surf + 1f - (1.2f + kk * 3.2f), r.x + (4f + kk * 22f), surf + 1f + (1.2f + kk * 3.2f))
            c.drawOval(rect, stroke)
        }
        // penanda "video laut"
        fill.color = fa(Color.WHITE, min(1f, A * 1.4f))
        path.reset()
        path.moveTo(px + 8f, py + 5f); path.lineTo(px + 8f, py + 12f); path.lineTo(px + 14f, py + 8.5f); path.close()
        c.drawPath(path, fill)
        textPaint.textSize = 7f
        textPaint.color = fa(Color.WHITE, min(1f, A * 1.4f))
        textPaint.textAlign = Paint.Align.LEFT
        c.drawText("Video laut", px + 18f, py + 11f, textPaint)
        c.drawText("Putus ${f.lost}", px + 8f, py + ph - 5f, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        c.drawText("Level air ${f.level + 1}", px + pw - 8f, py + ph - 5f, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
        c.restore()

        // tali, kail, ikan
        val line = Color.rgb(225, 238, 248)
        if (f.active) {
            val t = (now - f.sT0) / 1000f
            val st = f.state
            if (st == FishModel.SNAP && f.snap != null) {
                val s = f.snap!!
                stroke.color = fa(line, 0.9f); stroke.strokeWidth = 0.8f
                path.reset(); path.moveTo(ax, FishModel.PILL_BOTTOM)
                path.quadTo(ax - 3f, (FishModel.PILL_BOTTOM + s.up) / 2f, ax - 6f + sin(t * 6f) * 2f, s.up)
                c.drawPath(path, stroke)
                c.drawLine(s.hx, s.hy, s.hx + 2f, s.hy - 6f, stroke)
                drawHook(c, s.hx, s.hy, 1f)
                drawFishBody(c, s.fx, s.fy, FishModel.kinds[s.tier].len, PI.toFloat() + (if (s.fvx > 0f) 0.3f else -0.3f), s.tier, (1f - t / 2.4f).coerceIn(0.2f, 1f), now * 0.03f)
                if (t < 0.35f) {
                    stroke.color = fa(YELLOW, 1f - t / 0.35f)
                    for (n in 0 until 5) {
                        val an = n * TWO_PI / 5f + 0.3f
                        val r1 = 3f + t * 14f
                        val r2 = r1 + 4f
                        c.drawLine(s.hx + cos(an) * r1, s.hy + sin(an) * r1, s.hx + cos(an) * r2, s.hy + sin(an) * r2, stroke)
                    }
                }
            } else {
                val lc = mix(line, RED, if (st == FishModel.REEL) ((f.tension - 0.5f) * 2f).coerceIn(0f, 1f) else 0f)
                stroke.color = fa(lc, 0.9f); stroke.strokeWidth = 0.8f
                path.reset()
                path.moveTo(ax, FishModel.PILL_BOTTOM)
                if (st == FishModel.WAIT || st == FishModel.BITE) {
                    val dip = if (st == FishModel.BITE) 3f + sin(t * 24f) * 1.6f else sin(now * 0.002f) * 0.5f
                    path.quadTo((ax + f.hookX) / 2f, max(FishModel.PILL_BOTTOM, surf - 16f) + 6f, f.hookX, surf + dip - 2f)
                    c.drawPath(path, stroke)
                    stroke.strokeWidth = 0.5f
                    c.drawLine(f.hookX, surf + dip, f.hookX, f.hookY - 1f, stroke)
                    rect.set(f.hookX - 2.4f, surf + dip - 5f, f.hookX + 2.4f, surf + dip - 0.2f)
                    fill.color = RED
                    c.drawArc(rect, 180f, 180f, true, fill)
                    fill.color = Color.WHITE
                    c.drawArc(rect, 0f, 180f, true, fill)
                } else {
                    val sag = if (st == FishModel.CAST) 8f * (1f - (t / 1.1f).coerceIn(0f, 1f)) else if (st == FishModel.SHOW) 2f else 3f * (1f - f.tension)
                    path.quadTo((ax + f.hookX) / 2f, (FishModel.PILL_BOTTOM + f.hookY) / 2f + sag, f.hookX, f.hookY - 1f)
                    c.drawPath(path, stroke)
                }
                drawHook(c, f.hookX, f.hookY, 1f)
                if (st == FishModel.REEL || st == FishModel.SHOW) {
                    val fl = FishModel.kinds[f.tier].len
                    val struggle = if (st == FishModel.REEL) 0.15f + f.tension * 0.45f else 0.12f
                    drawFishBody(c, f.hookX, f.hookY + fl * 1.05f, fl, -PI.toFloat() / 2f + sin(now * 0.02f * (1f + f.tier * 0.2f)) * struggle, f.tier, 1f, now * 0.03f)
                }
            }
        }
        val d = f.drop
        if (d != null) {
            drawFishBody(c, d.x, d.y, FishModel.kinds[d.tier].len, PI.toFloat() / 2f + sin(now * 0.02f) * 0.3f, d.tier, 1f, now * 0.03f)
        }
        c.restore()
    }

    // ---------- mata ----------

    private fun glow(c: Canvas, color: Int, sw: Float, br: Float) {
        val layers = 3 + (br * 3f).toInt()
        for (k in layers downTo 1) {
            stroke.color = fa(color, 0.09f + 0.04f * br)
            stroke.strokeWidth = sw + sw * 0.45f * k * (1f + br * 0.5f)
            c.drawPath(path, stroke)
        }
        stroke.color = color
        stroke.strokeWidth = sw
        c.drawPath(path, stroke)
    }

    private fun drawEye(
        c: Canvas, look: Look, x: Float, y: Float, color0: Int, ew: Float, eh: Float,
        open: Float, left: Boolean, tilt: Float, br: Float, spin: Float
    ) {
        c.save()
        c.translate(x, y)
        if (tilt != 0f) c.rotate(tilt * 180f / PI.toFloat())
        val color = if (br > 0f) mix(color0, Color.WHITE, br * 0.75f) else color0
        when (look) {
            Look.BAR -> {
                val hh = eh * open
                var bw = ew
                var bh = hh
                var rad = min(ew / 2f, hh / 2f)
                if (shapeIdx == 1) { bw = ew * 1.25f; bh = hh * 0.85f; rad = ew * 0.28f }
                else if (shapeIdx == 2) { bw = ew * 1.8f; bh = max(1f, ew * 1.8f * open); rad = bw / 2f }
                for (k in 3 + (br * 3f).toInt() downTo 1) {
                    fill.color = fa(color, 0.09f + 0.04f * br)
                    val g = ew * 0.22f * k * (1f + br * 0.5f)
                    rect.set(-bw / 2f - g, -bh / 2f - g, bw / 2f + g, bh / 2f + g)
                    c.drawRoundRect(rect, rad + g, rad + g, fill)
                }
                fill.color = color
                rect.set(-bw / 2f, -bh / 2f, bw / 2f, bh / 2f)
                c.drawRoundRect(rect, rad, rad, fill)
            }

            Look.ARC -> {
                val rad = eh * 0.52f
                rect.set(-rad, rad * 0.5f - rad, rad, rad * 0.5f + rad)
                path.reset()
                path.arcTo(rect, 200f, 140f)
                glow(c, color, ew * 0.95f, br)
            }

            Look.SLANT -> {
                val half = ew * 1.35f
                val rise = eh * 0.22f
                val sx = if (left) -1f else 1f
                path.reset(); path.moveTo(sx * half, rise); path.lineTo(-sx * half, -rise)
                glow(c, color, ew * 0.95f, br)
            }

            Look.CHEV -> {
                val s = eh * 0.38f
                val d = if (left) 1f else -1f
                path.reset(); path.moveTo(-d * s, -s); path.lineTo(d * s * 0.7f, 0f); path.lineTo(-d * s, s)
                glow(c, color, ew * 0.9f, br)
            }

            Look.ANGRY -> {
                val half = ew * 1.5f
                val rise = eh * 0.2f
                path.reset()
                if (left) { path.moveTo(-half, -rise); path.lineTo(half, rise) }
                else { path.moveTo(half, -rise); path.lineTo(-half, rise) }
                glow(c, color, ew * 1.05f, br)
            }

            Look.SQUINT -> {
                path.reset(); path.moveTo(-ew * 1.5f, 0f); path.lineTo(ew * 1.5f, 0f)
                glow(c, color, eh * 0.14f, br)
            }

            Look.SPIRAL -> {
                val r = eh * 0.5f
                val turns = TWO_PI * 2.2f
                val dir = if (left) 1f else -1f
                path.reset()
                var a = 0f
                var first = true
                while (a <= turns) {
                    val rr = r * (a / turns)
                    val px = cos(a * dir + spin * 6f * dir) * rr
                    val py = sin(a * dir + spin * 6f * dir) * rr
                    if (first) { path.moveTo(px, py); first = false } else path.lineTo(px, py)
                    a += 0.25f
                }
                glow(c, color, ew * 0.5f, br)
            }

            Look.CAMERA -> drawCamera(c, eh * 1.1f)
        }
        if (br > 0.15f) {
            stroke.color = fa(Color.WHITE, 0.55f * br)
            stroke.strokeWidth = 0.8f
            val l = eh * 0.9f * br
            c.drawLine(-l, 0f, l, 0f, stroke)
            c.drawLine(0f, -l * 0.7f, 0f, l * 0.7f, stroke)
        }
        c.restore()
    }

    private fun drawCamera(c: Canvas, s: Float) {
        fill.color = Color.rgb(232, 238, 244)
        rect.set(-s * 0.5f, -s * 0.3f, s * 0.5f, s * 0.32f)
        c.drawRoundRect(rect, s * 0.1f, s * 0.1f, fill)
        rect.set(-s * 0.22f, -s * 0.44f, s * 0.08f, -s * 0.26f)
        c.drawRoundRect(rect, s * 0.05f, s * 0.05f, fill)
        fill.color = Color.rgb(40, 52, 66)
        c.drawCircle(0f, 0.02f * s, s * 0.22f, fill)
        fill.color = CYAN
        c.drawCircle(0f, 0.02f * s, s * 0.12f, fill)
        fill.color = fa(Color.WHITE, 0.9f)
        c.drawCircle(-s * 0.05f, -s * 0.04f, s * 0.04f, fill)
    }

    // ---------- ikon ----------

    private fun poly(vararg p: Float, s: Float) {
        path.reset()
        var i = 0
        while (i < p.size) {
            if (i == 0) path.moveTo(p[i] * s, p[i + 1] * s) else path.lineTo(p[i] * s, p[i + 1] * s)
            i += 2
        }
        path.close()
    }

    private fun drawIcon(c: Canvas, ic: Ic, w: Float, h: Float, t: Float, u: Float) {
        val s = ic.s
        if (s <= 0.01f) return
        val x = ic.x * w
        val y = ic.y * h + (if (ic.wob) sin(t * 5f) * 1.4f else 0f)
        c.save()
        c.translate(x, y)
        if (ic.rot != 0f) c.rotate(ic.rot * 180f / PI.toFloat())
        val col = fa(ic.col, ic.a.coerceIn(0f, 1f))
        fill.color = col
        stroke.color = col
        when (ic.k) {
            "note" -> {
                c.save(); c.rotate(-20f)
                rect.set(-s * 0.28f, s * 0.15f, s * 0.28f, s * 0.55f); c.drawOval(rect, fill)
                c.restore()
                stroke.strokeWidth = s * 0.11f
                path.reset(); path.moveTo(s * 0.24f, s * 0.3f); path.lineTo(s * 0.24f, -s * 0.5f)
                path.quadTo(s * 0.3f, -s * 0.2f, s * 0.58f, -s * 0.18f)
                c.drawPath(path, stroke)
            }
            "zed" -> {
                stroke.strokeWidth = s * 0.2f
                path.reset(); path.moveTo(-s * 0.4f, -s * 0.4f); path.lineTo(s * 0.4f, -s * 0.4f)
                path.lineTo(-s * 0.4f, s * 0.4f); path.lineTo(s * 0.4f, s * 0.4f)
                c.drawPath(path, stroke)
            }
            "spark" -> {
                poly(0f, -1f, .22f, -.22f, 1f, 0f, .22f, .22f, 0f, 1f, -.22f, .22f, -1f, 0f, -.22f, -.22f, s = s)
                c.drawPath(path, fill)
            }
            "star" -> {
                path.reset()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 1) s * 0.42f else s
                    val a = -PI.toFloat() / 2f + i * PI.toFloat() / 5f
                    if (i == 0) path.moveTo(cos(a) * r, sin(a) * r) else path.lineTo(cos(a) * r, sin(a) * r)
                }
                path.close(); c.drawPath(path, fill)
            }
            "question" -> {
                stroke.strokeWidth = s * 0.2f
                rect.set(-s * 0.3f, -s * 0.55f, s * 0.3f, s * 0.05f)
                path.reset(); path.arcTo(rect, 180f, 279f, true); path.lineTo(0f, s * 0.2f)
                c.drawPath(path, stroke)
                c.drawCircle(0f, s * 0.5f, s * 0.11f, fill)
            }
            "exclaim" -> {
                stroke.strokeWidth = s * 0.26f
                c.drawLine(0f, -s * 0.6f, 0f, s * 0.1f, stroke)
                c.drawCircle(0f, s * 0.46f, s * 0.14f, fill)
            }
            "bolt" -> {
                poly(.15f, -.75f, -.35f, .1f, -.02f, .1f, -.15f, .75f, .35f, -.15f, .02f, -.15f, s = s)
                c.drawPath(path, fill)
            }
            "battery" -> {
                stroke.strokeWidth = s * 0.1f; stroke.color = Color.rgb(220, 230, 240)
                rect.set(-s * 0.5f, -s * 0.28f, s * 0.5f, s * 0.28f); c.drawRoundRect(rect, s * 0.1f, s * 0.1f, stroke)
                fill.color = Color.rgb(220, 230, 240)
                c.drawRect(s * 0.52f, -s * 0.12f, s * 0.62f, s * 0.12f, fill)
                fill.color = col
                c.drawRect(-s * 0.4f, -s * 0.18f, -s * 0.4f + s * 0.8f * (if (ic.lvl > 0f) ic.lvl else 0.2f), s * 0.18f, fill)
            }
            "anger" -> {
                stroke.strokeWidth = s * 0.17f
                for (n in 0 until 4) {
                    c.rotate(90f)
                    rect.set(s * 0.06f, s * 0.06f, s * 0.74f, s * 0.74f)
                    c.drawArc(rect, 180f, 90f, false, stroke)
                }
            }
            "thermo" -> {
                val lv = ic.lvl.coerceIn(0f, 1f)
                stroke.strokeWidth = s * 0.1f; stroke.color = Color.rgb(225, 235, 245)
                rect.set(-s * 0.13f, -s * 0.72f, s * 0.13f, s * 0.23f); c.drawRoundRect(rect, s * 0.13f, s * 0.13f, stroke)
                c.drawCircle(0f, s * 0.5f, s * 0.26f, stroke)
                fill.color = RED
                c.drawCircle(0f, s * 0.5f, s * 0.19f, fill)
                val top = s * 0.4f + (-s * 0.6f - s * 0.4f) * lv
                rect.set(-s * 0.055f, top, s * 0.055f, s * 0.5f); c.drawRoundRect(rect, s * 0.05f, s * 0.05f, fill)
            }
            "fan" -> {
                stroke.strokeWidth = s * 0.07f; stroke.color = fa(ICE, 0.6f)
                c.drawCircle(0f, 0f, s * 0.7f, stroke)
                fill.color = fa(ICE, 0.9f)
                for (n in 0 until 3) {
                    val a = ic.spin + n * TWO_PI / 3f
                    c.save()
                    c.translate(cos(a) * s * 0.32f, sin(a) * s * 0.32f)
                    c.rotate(a * 180f / PI.toFloat())
                    rect.set(-s * 0.3f, -s * 0.13f, s * 0.3f, s * 0.13f); c.drawOval(rect, fill)
                    c.restore()
                }
                fill.color = Color.WHITE
                c.drawCircle(0f, 0f, s * 0.11f, fill)
            }
            "arrow" -> {
                stroke.strokeWidth = s * 0.2f
                c.drawLine(-s * 0.55f, 0f, s * 0.5f, 0f, stroke)
                path.reset(); path.moveTo(s * 0.12f, -s * 0.42f); path.lineTo(s * 0.62f, 0f); path.lineTo(s * 0.12f, s * 0.42f)
                c.drawPath(path, stroke)
            }
            "cw" -> {
                stroke.strokeWidth = s * 0.2f
                rect.set(-s * 0.5f, -s * 0.5f, s * 0.5f, s * 0.5f)
                c.drawArc(rect, -144f, 243f, false, stroke)
                c.save(); c.rotate(99f); c.translate(s * 0.5f, 0f)
                path.reset(); path.moveTo(-s * 0.3f, s * 0.05f); path.lineTo(0f, s * 0.4f); path.lineTo(s * 0.3f, s * 0.05f)
                c.drawPath(path, stroke)
                c.restore()
            }
            "headphone" -> {
                val gp = u * 0.55f
                stroke.strokeWidth = 2.6f * density; stroke.color = Color.rgb(225, 235, 245)
                val half = gp + u * 0.88f
                rect.set(-half, -u * 0.32f, half, u * 0.52f)
                c.drawArc(rect, 180f, 180f, false, stroke)
                fill.color = Color.rgb(225, 235, 245)
                for (px in floatArrayOf(-half, half)) {
                    rect.set(px - 3.6f * density, -u * 0.22f, px + 3.6f * density, u * 0.28f)
                    c.drawRoundRect(rect, 3.4f * density, 3.4f * density, fill)
                }
                fill.color = CYAN
                for (px in floatArrayOf(-half, half)) c.drawRect(px - density, -u * 0.06f, px + density, u * 0.12f, fill)
            }
            "speaker" -> {
                poly(-.5f, -.2f, -.2f, -.2f, .15f, -.5f, .15f, .5f, -.2f, .2f, -.5f, .2f, s = s)
                c.drawPath(path, fill)
                stroke.strokeWidth = s * 0.12f
                for (n in 1..ic.lvl.toInt()) {
                    val rr = s * (.25f + .22f * n)
                    rect.set(s * .15f - rr, -rr, s * .15f + rr, rr)
                    c.drawArc(rect, -52f, 104f, false, stroke)
                }
            }
            "wifi" -> {
                stroke.strokeWidth = s * 0.14f
                for (n in 1..3) {
                    val rr = s * .38f * n
                    rect.set(-rr, s * .5f - rr, rr, s * .5f + rr)
                    c.drawArc(rect, -135f, 90f, false, stroke)
                }
                c.drawCircle(0f, s * .5f, s * .09f, fill)
                if (ic.off) {
                    stroke.color = RED; stroke.strokeWidth = s * .17f
                    c.drawLine(-s * .75f, -s * .6f, s * .75f, s * .7f, stroke)
                }
            }
            "crescent" -> {
                path.reset(); path.addCircle(0f, 0f, s, Path.Direction.CW)
                val cut = Path(); cut.addCircle(s * .4f, -s * .1f, s * .82f, Path.Direction.CW)
                path.op(cut, Path.Op.DIFFERENCE)
                c.drawPath(path, fill)
            }
            "tomato" -> {
                fill.color = Color.rgb(255, 92, 80)
                c.drawCircle(0f, s * .1f, s * .7f, fill)
                fill.color = GREEN
                for (n in 0 until 3) {
                    c.save(); c.rotate(-52f + n * 52f)
                    rect.set(-s * .12f, -s * .9f, s * .12f, -s * .34f); c.drawOval(rect, fill)
                    c.restore()
                }
            }
            "tension" -> {
                val lv = ic.lvl.coerceIn(0f, 1f)
                stroke.strokeWidth = s * 0.1f; stroke.color = Color.rgb(225, 235, 245)
                rect.set(-s * 0.16f, -s * 0.5f, s * 0.16f, s * 0.5f); c.drawRoundRect(rect, s * 0.1f, s * 0.1f, stroke)
                fill.color = mix(GREEN, RED, lv)
                rect.set(-s * 0.09f, s * 0.43f - s * 0.86f * lv, s * 0.09f, s * 0.43f)
                c.drawRoundRect(rect, s * 0.05f, s * 0.05f, fill)
            }
        }
        c.restore()
    }

    private fun drawCentered(c: Canvas, s: String, x: Float, y: Float) {
        val fm = textPaint.fontMetrics
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    companion object {
        private const val PLANE_MS = 3400f
        private val TWO_PI = (2.0 * PI).toFloat()
        private val CYAN = Color.rgb(56, 232, 255)
        private val SAD_BLUE = Color.rgb(90, 168, 255)
        private val GREEN = Color.rgb(61, 255, 139)
        private val ORANGE = Color.rgb(255, 159, 28)
        private val RED = Color.rgb(255, 82, 82)
        private val YELLOW = Color.rgb(255, 214, 64)
        private val ICE = Color.rgb(140, 215, 255)
    }
}
