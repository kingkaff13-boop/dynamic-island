package com.kirnai.dynamicisland

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Pill hitam dengan sepasang mata menyala. Semua ekspresi, ikon, pesawat, dan
 * pemandangan mancing digambar di sini (tanpa emoji bawaan HP).
 */
class RobotView(ctx: Context) : View(ctx) {

    private enum class Look { BAR, ARC, SLANT, CHEV, ANGRY, SQUINT, SPIRAL, CAMERA, HEART, STAR }

    private class Ic(
        val k: String, val x: Float, val y: Float, val s: Float, val col: Int,
        val a: Float = 1f, val wob: Boolean = false, val rot: Float = 0f,
        val lvl: Float = 0f, val spin: Float = 0f, val off: Boolean = false
    )

    /** Tinggi pill saat diam (px). Ukuran mata mengikuti nilai ini. */
    var baseH = 0f

    var colorIdx = 0
    var shapeIdx = 0
    var robotName = "Beepo"
    var prayerName = ""
    var volUp = true
    var focusEndMs = 0L
    var focusActive = false
    var airplane = false
        set(v) {
            field = v
            planeT0 = 0L
            planeNext = SystemClock.uptimeMillis() + 600L
            invalidate()
        }
    var torchOn = false
        set(v) {
            field = v
            invalidate()
        }

    // kaca, robot mati, privasi, bicara
    var glassOn = true
    var booster = false
    var glassLvl = 0.55f
    var offMode = false
        set(v) { field = v; invalidate() }
    var privMode = false
        set(v) { field = v; invalidate() }
    var speaking = false
        set(v) { field = v; invalidate() }
    private var offAmt = 0f

    // jalan-jalan: baterai, mati, bingung
    var roamBat = 100f
    var roamVis = 0f
    var roamDead = false
    var roamConf = false
    /** 0 = bangun, 1 = mengantuk, 2 = tidur */
    var sleepMode = 0
        set(v) { field = v; invalidate() }

    val fish = FishModel()

    // musik
    var musicPulse = 0f
    var musicBpm = 100f
    var musicBeats = 0

    // game (0 = tidak ada, 1 = ikuti mataku, 2 = suit)
    var gameMode = 0
    var gamePhase = ""
    var gamePos = 0
    var gameLen = 0
    var gameScore = 0
    var gameCount = 3
    var gameRobot = 0
    var gameResult = ""
    var gameT0 = 0L

    // kehidupan
    var mood = 60f
    var toss = true

    // nilai pose yang dihaluskan supaya perpindahan antar aksi tidak patah-patah
    private var sDx = 0f
    private var sDy = 0f
    private var sScale = 1f
    private var sTiltL = 0f
    private var sTiltR = 0f
    private var smoothInit = false

    private var act = Act.IDLE
    private var actStart = SystemClock.uptimeMillis()
    private var badgeOverride: String? = null
    private var blinkStart = -1L
    private var gazeX = 0f
    private var gazeY = 0f
    private var targetX = 0f
    private var targetY = 0f
    private var sideAmount = 0f
    private var torchLevel = 0f
    private var lastFrame = 0L
    private var planeT0 = 0L
    private var planeNext = 0L
    private var planeDir = 1
    private val rnd = Random()

    private val density = ctx.resources.displayMetrics.density
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val path = Path()
    private val icons = ArrayList<Ic>()

    fun setAct(a: Act, badge: String? = null) {
        act = a
        badgeOverride = badge
        actStart = SystemClock.uptimeMillis()
        targetX = 0f
        targetY = 0f
        invalidate()
    }

    fun blink() {
        blinkStart = SystemClock.uptimeMillis()
        invalidate()
    }

    fun onBeat() {
        musicPulse = 1f
        musicBeats++
        invalidate()
    }

    fun gamePhaseChanged() {
        gameT0 = SystemClock.uptimeMillis()
        invalidate()
    }

    fun lookAt(x: Float, y: Float) {
        targetX = x
        targetY = y
        invalidate()
    }

    /** Tinggi jendela yang dibutuhkan saat mancing, untuk lebar jendela w (px). */
    fun fishingHeight(w: Float): Int = (baseH + 86f * w / FishModel.PW).toInt()

    fun startFishing() {
        fish.start(SystemClock.uptimeMillis())
        invalidate()
    }

    fun stopFishing() {
        fish.stop()
        invalidate()
    }

    fun fishLevelUp() {
        fish.levelUp(SystemClock.uptimeMillis())
    }

    // ---------- warna ----------

    private fun baseColor(now: Long): Int = when (colorIdx) {
        0 -> CYAN
        1 -> Color.rgb(61, 255, 139)
        2 -> Color.rgb(182, 156, 255)
        3 -> Color.rgb(255, 120, 200)
        4 -> Color.rgb(255, 170, 60)
        5 -> Color.rgb(235, 245, 255)
        else -> Color.HSVToColor(floatArrayOf((now / 18f) % 360f, 0.7f, 1f))
    }

    private fun mix(a: Int, b: Int, f: Float): Int {
        val ff = f.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * ff).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * ff).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * ff).toInt()
        )
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
    private fun fa(color: Int, a: Float): Int = withAlpha(color, (a * 255f).toInt())

    private fun ic(
        k: String, x: Float, y: Float, s: Float, col: Int = Color.WHITE, a: Float = 1f,
        wob: Boolean = false, rot: Float = 0f, lvl: Float = 0f, spin: Float = 0f, off: Boolean = false
    ) {
        icons.add(Ic(k, x, y, s, col, a, wob, rot, lvl, spin, off))
    }

    // ---------- gambar utama ----------

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0.016f else min(0.1f, (now - lastFrame) / 1000f)
        lastFrame = now
        val w = width.toFloat()
        val u = if (baseH > 0f) baseH else height.toFloat()
        val h = u
        val base = baseColor(now)

        // mancing aktif: kerjakan logika dan gambar pemandangan
        val k = w / FishModel.PW
        val ax = (w / k) * 0.78f
        fish.update(now, dt, ax, FishModel.PILL_BOTTOM)
        val t = when (act) {
            Act.FISH -> max(0f, (now - fish.sT0) / 1000f)
            Act.GAME -> max(0f, (now - gameT0) / 1000f)
            else -> max(0f, (now - actStart) / 1000f)
        }
        musicPulse *= exp(-dt * 7f)
        val bt = musicPulse
        if (fish.vis > 0.01f || fish.drop != null) {
            drawFishScene(canvas, now, w, u, k, ax)
        }

        // torch
        val tgtTorch = if (torchOn) 1f else 0f
        torchLevel += (tgtTorch - torchLevel) * min(1f, dt * 6f)
        var needFrames = abs(tgtTorch - torchLevel) > 0.01f
        val br = torchLevel

        // badan pill
        offAmt += ((if (offMode) 1f else 0f) - offAmt) * min(1f, dt * 7f)
        if (abs((if (offMode) 1f else 0f) - offAmt) > 0.01f) needFrames = true
        val bodyH = h + (min(h, u * 0.5f) - h) * offAmt
        val top = (h - bodyH) / 2f
        val bodyW = w + (bodyH - w) * offAmt
        val left = (w - bodyW) / 2f
        val r = min(bodyH / 2f, 26f * density)
        rect.set(left, top, left + bodyW, top + bodyH)
        val bodyA = 1f - 0.45f * offAmt
        if (glassOn && !booster && offAmt < 0.5f) {
            val sheen = ((now % 5200L) / 5200f) * 1.7f - 0.35f
            Glass.draw(canvas, rect, r, glassLvl, bodyA, sheen, density)
            if (!needFrames) postInvalidateDelayed(80L)
        } else {
            bgPaint.alpha = (255f * bodyA).toInt()
            canvas.drawRoundRect(rect, r, r, bgPaint)
            bgPaint.alpha = 255
            if (offAmt > 0.3f) {
                stroke.color = fa(Color.WHITE, 0.25f * offAmt)
                stroke.strokeWidth = density
                canvas.drawRoundRect(rect, r, r, stroke)
            }
        }
        if (br > 0.05f) {
            fill.color = fa(Color.rgb(170, 240, 255), 0.10f * br)
            canvas.drawRoundRect(rect, r, r, fill)
        }

        canvas.save()
        canvas.clipRect(0f, 0f, w, h)

        // pandangan mengejar target dengan halus
        val kg = min(1f, dt * 12f)
        gazeX += (targetX - gazeX) * kg
        gazeY += (targetY - gazeY) * kg
        if (abs(targetX - gazeX) > 0.01f || abs(targetY - gazeY) > 0.01f) needFrames = true

        // pose default
        var lookL = Look.BAR
        var lookR = Look.BAR
        var color = base
        var open = 1f
        var scale = 1f
        var scaleL = 1f
        var scaleR = 1f
        var openL = 1f
        var openR = 1f
        var dx = 0f
        var dy = 0f
        var dyL = 0f
        var dyR = 0f
        var side = 0f
        var tear = false
        var tiltL = 0f
        var tiltR = 0f
        var label: String? = null
        var labelX = 0.8f
        var labelColor = 0
        var flash = 0f
        var spin = 0f
        icons.clear()

        val shown = act
        when (shown) {
            Act.IDLE -> {
                dx = gazeX * u * 0.35f
                dy = gazeY * u * 0.14f
                if (mood < 25f) { color = mix(base, SAD_BLUE, 0.35f); dy += u * 0.04f }
            }

            Act.YAWN -> {
                if (t < 1.1f) { open = 1f - 0.75f * (t / 1.1f); dy = -u * 0.05f * (t / 1.1f) }
                else if (t < 2.4f) { scale = 1.12f; open = 1.45f; dy = -u * 0.02f; tear = t > 1.5f }
                else { open = 0.35f + 0.2f * min(1f, t - 2.4f); dy = u * 0.05f }
            }

            Act.MORNING -> {
                side = 1f; lookL = Look.ARC; lookR = Look.ARC
                dy = -abs(sin(t * 5f)) * u * 0.06f * max(0f, 1f - t / 1.6f)
                ic("sun", .68f, .5f, u * .3f, YELLOW, rot = t * 0.8f)
                label = "Pagi!"; labelX = .88f; labelColor = YELLOW
            }

            Act.MISS -> {
                lookL = Look.SLANT; lookR = Look.SLANT; color = SAD_BLUE; dy = u * .06f; tear = true
                dx = sin(t * .8f) * u * .25f
                ic("heart", .86f, .5f, u * .3f, PINK, a = .45f + .25f * sin(t * 3f))
            }

            Act.REUNION -> {
                side = 1f; lookL = Look.ARC; lookR = Look.ARC
                scale = 1f + .12f * max(0f, 1f - t / .8f)
                dy = -abs(sin(t * 8f)) * u * .1f * max(0f, 1f - t / 3f)
                for (i in 0 until 3) {
                    val ph = ((t * .9f) + i / 3f) % 1f
                    ic("heart", .62f + i * .12f, .8f - ph * .6f, u * (.16f + .05f * i), PINK, a = 1f - ph)
                }
            }

            Act.REST -> {
                side = 1f; lookL = Look.ARC; lookR = Look.ARC
                dy = sin(t * 1.5f) * u * .03f
                ic("cup", .66f, .5f, u * .34f, Color.WHITE)
                label = "Rehat"; labelX = .9f; labelColor = Color.WHITE
            }

            Act.BUG -> {
                val bx = 0.5f + 0.4f * sin(t * 1.7f) * cos(t * 0.6f)
                val by = 0.5f + 0.26f * sin(t * 2.9f)
                if (t < 5.8f) {
                    targetX = ((bx - .5f) * 2.6f).coerceIn(-1f, 1f); targetY = ((by - .5f) * 3f).coerceIn(-1f, 1f)
                    dx = gazeX * u * .5f; dy = gazeY * u * .22f
                    ic("bug", bx, by, u * .2f, Color.rgb(190, 200, 210), spin = t)
                } else {
                    targetX = 0f; targetY = 0f; lookL = Look.ARC; lookR = Look.ARC
                    ic("spark", .5f, .3f, u * .2f, YELLOW, rot = t * 2f)
                }
            }

            Act.BALL -> {
                val bx = .5f + .4f * sin(t * 1.6f)
                val by = .88f - .72f * abs(sin(t * 3.2f))
                if (t < 6.2f) {
                    targetX = ((bx - .5f) * 2.6f).coerceIn(-1f, 1f); targetY = ((by - .5f) * 2f).coerceIn(-1f, 1f)
                    dx = gazeX * u * .5f; dy = gazeY * u * .22f
                    ic("ball", bx, by, u * .18f, ORANGE)
                } else {
                    targetX = 0f; targetY = 0f; lookL = Look.ARC; lookR = Look.ARC
                }
            }

            Act.TOSS -> {
                val f = ((t - 1.3f) / 1.3f).coerceIn(0f, 1f)
                ic("bin", .9f, .55f, u * .34f, ICE)
                if (t < 1.3f) {
                    targetX = -.5f; targetY = 0f; dx = gazeX * u * .5f; openL = .7f; openR = .7f
                    ic("paperball", .1f, .6f, u * .17f, Color.WHITE)
                } else if (t < 2.6f) {
                    targetX = .9f; targetY = -.2f; dx = gazeX * u * .5f
                    val px = .1f + ((if (toss) .88f else .72f) - .1f) * f
                    val py = .6f - .55f * sin(f * PI.toFloat()) + (if (toss) 0f else f * .28f)
                    ic("paperball", px, py, u * .17f, Color.WHITE, rot = t * 8f)
                } else {
                    targetX = 0f; targetY = 0f
                    if (toss) {
                        lookL = Look.ARC; lookR = Look.ARC
                        ic("spark", .76f, .3f, u * .2f, YELLOW, rot = t * 2f)
                    } else {
                        color = Color.rgb(255, 190, 90); openL = .5f; openR = .5f; tiltL = .2f; tiltR = -.2f
                        ic("paperball", .72f, .86f, u * .17f, Color.WHITE)
                        ic("anger", .52f, .3f, u * .2f, ORANGE)
                    }
                }
            }

            Act.TICKLE -> {
                val ph = (t * 1.5f) % 1f
                lookL = Look.CHEV; lookR = Look.CHEV
                dx = sin(t * 38f) * u * .05f; dy = sin(t * 26f) * u * .03f
                ic("heart", .86f, .5f - .1f * ph, u * .2f, PINK, a = 1f - ph)
            }

            Act.CUDDLE -> {
                lookL = Look.ARC; lookR = Look.ARC; color = mix(base, PINK, .35f)
                dx = sin(t * 1.2f) * u * .15f; dy = u * .04f + sin(t * 2.4f) * u * .02f
                for (i in 0 until 2) {
                    val ph = ((t * .5f) + i / 2f) % 1f
                    ic("heart", .82f + i * .08f, .75f - ph * .5f, u * (.17f + .05f * i), PINK, a = 1f - ph)
                }
            }

            Act.WEAK -> {
                color = mix(base, Color.BLACK, .55f); open = .4f; dy = u * .07f
                dx = sin(t * 14f) * u * .015f; side = 1f
                ic("battery", .84f, .5f, u * .6f, RED, lvl = .05f + .03f * sin(t * 5f))
            }

            Act.REVIVE -> {
                side = 1f; lookL = Look.ARC; lookR = Look.ARC
                scale = 1f + .2f * max(0f, 1f - t / .9f)
                dy = -abs(sin(t * 9f)) * u * .12f * max(0f, 1f - t / 2.4f)
                ic("bolt", .82f, .5f, u * .5f, YELLOW, wob = true)
                ic("spark", .94f, .28f, u * .16f, Color.WHITE, rot = t * 3f)
            }

            Act.HAPPY -> {
                lookL = Look.ARC; lookR = Look.ARC
                dy = -abs(sin(t * 7f)) * u * 0.07f * max(0f, 1f - t / 1.6f)
                if (badgeOverride == "bolt") ic("bolt", .84f, .5f, u * .5f, YELLOW, wob = true)
                if (badgeOverride == "wifi") ic("wifi", .84f, .5f, u * .42f, GREEN, wob = true)
            }

            Act.SAD -> {
                lookL = Look.SLANT; lookR = Look.SLANT
                color = SAD_BLUE; dy = u * 0.06f; tear = true
                if (badgeOverride == "battery") ic("battery", .84f, .5f, u * .6f, RED, lvl = .12f)
                if (badgeOverride == "nowifi") ic("wifi", .84f, .5f, u * .42f, Color.rgb(220, 230, 240), off = true)
            }

            Act.ANGRY -> {
                lookL = Look.ANGRY; lookR = Look.ANGRY; color = RED
                dx = sin(t * 45f) * u * 0.02f
                ic("anger", .84f, .46f, u * (0.42f + 0.07f * sin(t * 14f)) * min(1f, t / 0.25f), RED)
            }

            Act.ANNOYED -> {
                color = Color.rgb(255, 190, 90); openL = .42f; openR = .42f; tiltL = .2f; tiltR = -.2f
                dx = sin(t * 3f) * u * 0.1f
                ic("anger", .82f, .46f, u * 0.26f * min(1f, t / 0.3f), ORANGE)
            }

            Act.SURPRISE -> {
                scale = 1f + 0.38f * max(0f, 1f - t / 1.1f)
                dx = sin(t * 40f) * u * 0.015f * max(0f, 1f - t)
                if (t < 1.4f) ic("exclaim", .83f, .5f, u * .5f, YELLOW)
            }

            Act.LAUGH -> {
                lookL = Look.CHEV; lookR = Look.CHEV
                dy = sin(t * 28f) * u * 0.035f
            }

            Act.WINK -> lookR = Look.ARC

            Act.SLEEPY -> {
                open = 0.16f + 0.10f * (0.5f + 0.5f * sin(t * 2.2f))
                dy = u * 0.08f
                color = mix(base, Color.BLACK, 0.42f)
                for (i in 0 until 3) {
                    val ph = ((t * 0.5f) + i / 3f) % 1f
                    ic("zed", .74f + ph * .14f, .66f - ph * .5f, u * (0.14f + 0.09f * i), ICE, a = 1f - ph)
                }
            }

            Act.CONFUSED -> {
                openL = .65f; scaleR = 1.3f; tiltR = -.12f
                dx = sin(t * 2.2f) * u * 0.3f
                ic("question", .82f, .5f, u * .6f, YELLOW, wob = true)
            }

            Act.PEEK -> {
                dy = u * 0.5f; open = 1.15f
                dx = sin(t * 2.2f) * u * 0.55f
            }

            Act.HOT -> {
                lookL = Look.CHEV; lookR = Look.CHEV; color = ORANGE
                dx = sin(t * 34f) * u * 0.02f; side = 1f
                ic("fan", .68f, .5f, u * .46f, spin = t * 12f)
                ic("thermo", .87f, .5f, u * .62f, lvl = (t / 1.8f).coerceIn(0f, 1f) * (0.9f + 0.1f * sin(t * 8f)))
            }

            Act.PHOTO -> {
                side = 1f
                if (t < 2.65f) {
                    lookL = Look.CAMERA; lookR = Look.CAMERA
                    scale = min(1f, t / 0.35f)
                    if (t in 0.5f..2.45f) {
                        label = (3 - floor((t - 0.5f) / 0.65f).toInt()).coerceIn(1, 3).toString()
                        labelColor = Color.WHITE
                    }
                } else {
                    lookL = Look.ARC; lookR = Look.ARC
                    ic("spark", .8f, .5f, u * .34f, YELLOW, rot = t * 2f)
                    ic("spark", .88f, .3f, u * .2f, Color.WHITE, rot = -t * 2f)
                }
                flash = max(0f, 1f - abs(t - 2.55f) / 0.12f)
            }

            Act.DANCE -> {
                val ph = t * 2.2f * TWO_PI
                val bn = abs(sin(ph / 2f))
                dy = -bn * u * 0.14f; open = 1f + 0.2f * bn
                dx = sin(ph / 4f) * u * 0.45f
                color = Color.HSVToColor(floatArrayOf((t * 140f) % 360f, 0.7f, 1f))
                val kk = (t * 2.2f).toInt()
                val fr = (t * 2.2f) % 1f
                ic("note", if (kk % 2 == 1) .86f else .14f, .66f - .34f * fr, u * .5f, Color.WHITE, a = 1f - fr * .6f)
                ic("note", if (kk % 2 == 1) .14f else .86f, .7f - .3f * ((fr + .5f) % 1f), u * .36f, color, a = .7f)
            }

            Act.EXERCISE -> {
                side = 1f; color = GREEN
                val s = t - 2f
                if (t < 2f) {
                    scale = 1f + 0.10f * sin(t * 6f)
                    label = "Ikuti!"
                } else if (t < 22f) {
                    var gx = 0f
                    var gy = 0f
                    var kind = "arrow"
                    var rot = 0f
                    when ((s / 4f).toInt()) {
                        0 -> { gx = -1f; rot = PI.toFloat() }
                        1 -> { gx = 1f }
                        2 -> { gy = -1f; rot = -PI.toFloat() / 2f }
                        3 -> { gy = 1f; rot = PI.toFloat() / 2f }
                        else -> {
                            val a = (s - 16f) / 4f * TWO_PI * 1.5f
                            gx = cos(a); gy = sin(a); kind = "cw"
                        }
                    }
                    targetX = gx; targetY = gy
                    dx = gazeX * u * 0.5f; dy = gazeY * u * 0.22f
                    ic(kind, .72f, .5f, u * .34f, GREEN, rot = rot)
                    label = (20 - floor(s).toInt()).coerceIn(1, 20).toString()
                    labelX = .88f
                } else {
                    lookL = Look.ARC; lookR = Look.ARC
                    label = "Bagus!"
                }
            }

            Act.HEADSET -> {
                lookL = Look.ARC; lookR = Look.ARC
                dy = -abs(sin(t * 5.2f)) * u * 0.08f
                ic("headphone", .5f, .5f, u * 1.43f, rot = 0f)
                ic("note", .5f + (((t * 0.8f) % 1f) - .5f) * .5f, .24f, u * .26f, color, a = .85f)
            }

            Act.VOLUME -> {
                side = 1f
                dy = sin(t * (if (volUp) 9f else 5f)) * u * 0.06f
                ic("speaker", .78f, .5f, u * .5f, lvl = if (volUp) 3f else 1f)
            }

            Act.ADZAN -> {
                side = 1f
                dy = sin(t * 1.6f) * u * 0.04f
                color = mix(base, Color.rgb(255, 235, 180), 0.35f)
                openL = 0.85f + 0.15f * sin(t * 1.6f); openR = openL
                ic("crescent", .64f, .5f, u * .36f, YELLOW)
                ic("star", .74f, .36f, u * .13f, YELLOW, a = .6f + .4f * sin(t * 3f))
                label = prayerName; labelX = .88f; labelColor = YELLOW
            }

            Act.HELLO -> {
                side = 1f
                lookL = Look.ARC; lookR = Look.ARC
                dy = -abs(sin(t * 6f)) * u * 0.06f * max(0f, 1f - t / 1.8f)
                label = robotName; labelX = .76f
                ic("spark", .94f, .3f, u * .16f, YELLOW, rot = t * 2f)
            }

            Act.DIZZY -> {
                lookL = Look.SPIRAL; lookR = Look.SPIRAL; spin = t
                dx = sin(t * 5f) * u * 0.22f; dy = sin(t * 3.3f) * u * 0.04f
                for (i in 0 until 3) {
                    val ang = t * 4f + i * TWO_PI / 3f
                    ic("star", .5f + cos(ang) * (u * 1.05f / w), .2f + sin(ang) * .11f, u * .17f, YELLOW)
                }
            }

            Act.FOCUS -> {
                val rem = max(0L, focusEndMs - now) / 1000L
                side = 1f; openL = .6f; openR = .6f
                if (rem <= 10L) color = ORANGE
                label = String.format("%02d:%02d", rem / 60L, rem % 60L)
                labelX = .86f; labelColor = Color.WHITE
                ic("tomato", .64f, .5f, u * .3f, wob = true)
            }

            Act.GAME -> {
                side = 1f
                if (gameMode == 1) {
                    when (gamePhase) {
                        "show" -> { label = "Lihat!"; dx = gazeX * u * 0.5f; dy = gazeY * u * 0.22f }
                        "input" -> { label = "${gamePos + 1}/$gameLen"; labelColor = Color.WHITE }
                        "cheer" -> {
                            lookL = Look.ARC; lookR = Look.ARC
                            ic("spark", .8f, .5f, u * .3f, YELLOW, rot = t * 2f)
                        }
                        "over" -> {
                            lookL = Look.SLANT; lookR = Look.SLANT; color = SAD_BLUE; tear = true
                            label = "Skor $gameScore"; labelColor = Color.WHITE
                        }
                        else -> label = "Siap?"
                    }
                } else if (gameMode == 2) {
                    val names = arrayOf("rock", "paper", "scissors")
                    if (gamePhase == "count") {
                        label = gameCount.toString(); labelX = .88f; labelColor = Color.WHITE
                        ic("rock", .68f, .5f + sin(t * 14f) * .1f, u * .42f)
                        dx = sin(t * 14f) * u * 0.05f
                    } else if (gamePhase == "reveal") {
                        ic(names[gameRobot.coerceIn(0, 2)], .74f, .5f, u * .5f)
                        if (gameResult == "lose") {
                            lookL = Look.CHEV; lookR = Look.CHEV; dy = sin(t * 28f) * u * 0.03f
                        } else if (gameResult == "win") {
                            lookL = Look.SLANT; lookR = Look.SLANT; color = SAD_BLUE
                        } else {
                            lookL = Look.ARC; lookR = Look.ARC
                        }
                    } else {
                        label = "Suit!"
                    }
                }
            }

            Act.MUSIC_HYPE -> {
                lookL = Look.ARC; lookR = Look.ARC
                dy = -bt * u * 0.16f
                dx = sin(t * (musicBpm / 60f) * PI.toFloat()) * u * 0.4f
                color = Color.HSVToColor(floatArrayOf(190f + 50f * sin(t * 0.8f), 0.75f, 1f))
                val sd = if (musicBeats % 2 == 1) .1f else .9f
                ic("note", sd, .7f - .35f * (1f - bt), u * .5f, color, a = bt * 0.9f + 0.1f)
                ic("note", 1f - sd, .7f - .3f * (1f - bt), u * .34f, Color.WHITE, a = bt * 0.7f)
            }

            Act.MUSIC_SAD -> {
                lookL = Look.SLANT; lookR = Look.SLANT; color = SAD_BLUE; tear = true
                dx = sin(t * 1.2f) * u * 0.3f; dy = u * 0.05f
                val ph = (t * 0.25f) % 1f
                ic("note", .86f, .75f - .5f * ph, u * .45f, SAD_BLUE, a = 1f - ph)
            }

            Act.MUSIC_ODD -> {
                lookL = Look.SQUINT; lookR = Look.SQUINT
                tiltL = sin(t * 1.7f) * 0.18f; tiltR = -sin(t * 1.7f) * 0.18f
                dyR = -u * 0.05f; dx = sin(t * 1.1f) * u * 0.2f
                ic("question", .85f, .48f, u * .6f, YELLOW, wob = true)
            }

            Act.MUSIC_CHILL -> {
                dx = sin(t * 1.6f) * u * 0.3f; dy = -bt * u * 0.05f
                val ph = (t * 0.3f) % 1f
                ic("note", .86f, .72f - .4f * ph, u * .38f, base, a = 1f - ph)
            }

            Act.FISH -> {
                side = 1f; dy = u * 0.08f
                when (fish.state) {
                    FishModel.CAST -> { dy = u * 0.14f; dx = sin(t * 6f) * u * 0.1f }
                    FishModel.WAIT -> {
                        openL = .55f; openR = .55f; dx = sin(t * 0.9f) * u * 0.15f; dy = u * 0.12f
                    }
                    FishModel.BITE -> {
                        scale = 1.22f; dy = u * 0.06f
                        ic("exclaim", .86f, .5f, u * .5f, YELLOW)
                    }
                    FishModel.REEL -> {
                        lookL = Look.CHEV; lookR = Look.CHEV
                        dx = sin(t * 30f) * u * (0.02f + fish.tension * 0.05f)
                        if (fish.tier >= 3) color = ORANGE
                        ic("tension", .87f, .5f, u * .6f, lvl = fish.tension)
                    }
                    FishModel.SHOW -> {
                        lookL = Look.ARC; lookR = Look.ARC
                        dy = -abs(sin(t * 7f)) * u * 0.07f * max(0f, 1f - t / 1.2f)
                        label = FishModel.kinds[fish.tier].name; labelX = .8f; labelColor = Color.WHITE
                    }
                    FishModel.SNAP -> {
                        lookL = Look.SLANT; lookR = Look.SLANT; color = SAD_BLUE; tear = true
                        dy = u * 0.06f; label = "Putus!"; labelX = .8f; labelColor = Color.WHITE
                    }
                }
            }

            Act.PONDER -> {
                side = 1f
                dx = u * .22f + sin(t * 1.6f) * u * .06f; dy = -u * .1f
                openL = .85f; openR = .85f; tiltL = -.1f; tiltR = -.1f
                ic("dots", .84f, .4f, u * .42f, Color.WHITE)
            }

            Act.LOVE -> {
                side = 1f; lookL = Look.HEART; lookR = Look.HEART; color = PINK
                scale = 1f + .1f * sin(t * 9f); dy = sin(t * 2f) * u * .03f
                for (i in 0 until 3) {
                    val ph = ((t * .8f) + i / 3f) % 1f
                    ic("heart", .74f + i * .09f, .8f - ph * .6f, u * (.15f + .04f * i), PINK, a = 1f - ph)
                }
            }

            Act.WOW -> {
                side = 1f; lookL = Look.STAR; lookR = Look.STAR
                color = mix(base, Color.WHITE, .35f)
                scale = 1f + .25f * max(0f, 1f - t / .6f); spin = t * .25f
                ic("spark", .8f, .5f, u * .28f, YELLOW, rot = t * 2f)
                ic("spark", .9f, .3f, u * .17f, Color.WHITE, rot = -t * 2f)
            }

            Act.NOD -> {
                val kk = max(0f, 1f - t / 2.2f)
                dy = sin(t * 10f) * u * .12f * kk
                open = 1f - .3f * abs(sin(t * 10f)) * kk
                color = mix(base, GREEN, .25f)
            }

            Act.SHAKE -> {
                val kk = max(0f, 1f - t / 2.2f)
                dx = sin(t * 11f) * u * .28f * kk
                openL = .75f; openR = .75f
                color = mix(base, ORANGE, .25f)
            }

            Act.SHY -> {
                lookL = Look.ARC; lookR = Look.ARC
                scale = .85f; dy = u * .1f; dx = -u * .12f + sin(t * 1.3f) * u * .04f
                color = mix(base, PINK, .3f)
                ic("blush", .29f, .8f, u * .24f, PINK, a = .8f)
                ic("blush", .71f, .8f, u * .24f, PINK, a = .8f)
            }

            Act.WORRY -> {
                side = 1f; lookL = Look.SLANT; lookR = Look.SLANT
                color = mix(base, SAD_BLUE, .3f)
                dx = sin(t * 3f) * u * .08f; dy = u * .04f
                val ph = (t * .6f) % 1f
                ic("drop", .84f, .28f + ph * .32f, u * .3f, ICE, a = 1f - ph * .5f)
            }

            Act.EXCITED -> {
                side = 1f; scale = 1.18f
                dy = -abs(sin(t * 11f)) * u * .13f
                color = mix(base, Color.WHITE, .3f)
                ic("spark", .8f, .5f, u * .24f, YELLOW, rot = t * 4f)
                ic("spark", .9f, .3f, u * .15f, Color.WHITE, rot = -t * 4f)
            }

            Act.SMUG -> {
                side = 1f; openL = .5f; openR = .8f; tiltL = .15f; dx = u * .2f
                color = mix(base, ORANGE, .15f)
                ic("spark", .84f, .35f, u * .15f, Color.WHITE, a = .5f + .5f * sin(t * 6f), rot = t)
            }

            Act.RELIEF -> {
                side = 1f; color = mix(base, ICE, .3f)
                if (t < 1.9f) { lookL = Look.SQUINT; lookR = Look.SQUINT; dy = u * .03f }
                else { open = min(1f, (t - 1.9f) / .4f); dy = u * .02f }
                val ph = (t * .5f) % 1f
                ic("puff", .84f, .62f - ph * .26f, u * .3f, Color.WHITE, a = (1f - ph) * .8f)
            }

            Act.IDEA -> {
                side = 1f
                scale = 1f + .3f * max(0f, 1f - t / .5f)
                dy = -abs(sin(t * 9f)) * u * .1f * max(0f, 1f - t / 1f)
                ic("bulb", .84f, .56f, u * .5f * min(1f, t / .25f), YELLOW, wob = true)
            }

            Act.AWKWARD -> {
                side = 1f; dx = sin(t * 1.2f) * u * .4f
                openL = .8f; openR = .8f; color = mix(base, ICE, .2f)
                val ph = (t * .7f) % 1f
                ic("drop", .8f, .28f + ph * .3f, u * .3f, ICE, a = 1f - ph * .6f)
            }
        }

        // privasi: tutup mata, tanpa ikon
        if (privMode) {
            lookL = Look.SQUINT; lookR = Look.SQUINT
            icons.clear(); label = null; tear = false
            dx = 0f; dy = u * 0.02f; open = 1f; openL = 1f; openR = 1f; tiltL = 0f; tiltR = 0f
            scale = 1f; scaleL = 1f; scaleR = 1f; spin = 0f; side = 0f
            color = mix(base, Color.BLACK, 0.35f)
        }
        // mengantuk dan tidur
        if (sleepMode == 2 && !privMode && !roamDead) {
            icons.clear(); tear = false
            dx = 0f; dy = u * 0.04f; open = 0.07f; openL = 1f; openR = 1f; tiltL = 0f; tiltR = 0f
            scale = 1f; scaleL = 1f; scaleR = 1f; spin = 0f; side = 1f
            color = mix(base, Color.BLACK, 0.45f)
            label = if (((now / 900L) % 3L) == 0L) "z" else if (((now / 900L) % 3L) == 1L) "zz" else "zzz"
            labelX = .82f; labelColor = ICE
            needFrames = true
        } else if (sleepMode == 1 && !privMode && !roamDead && act == Act.IDLE) {
            open = 0.4f + 0.25f * (0.5f + 0.5f * sin(now / 700f)); dy = u * 0.05f
            color = mix(base, Color.BLACK, 0.2f)
            needFrames = true
        }
        // jalan-jalan: bingung (?) dan mati kehabisan baterai
        if (roamConf && !roamDead && !privMode) { label = "?"; labelX = .86f; labelColor = YELLOW }
        if (roamDead) {
            icons.clear(); label = null; tear = false
            dx = 0f; dy = u * 0.03f; open = 0.07f; openL = 1f; openR = 1f; tiltL = 0f; tiltR = 0f
            scale = 1f; scaleL = 1f; scaleR = 1f; spin = 0f; side = 0f
            color = mix(base, Color.BLACK, 0.7f)
        } else if (roamVis > 0.02f) {
            dx += u * 0.25f * min(1f, roamVis * 1.5f)
            needFrames = true
        }
        // bicara: mata sedikit memantul
        if (speaking && !privMode && !offMode) {
            dy += sin(now * 0.018f) * u * 0.035f
            needFrames = true
        }

        // pesawat di belakang mata
        if (airplane && offAmt < 0.5f) {
            if (planeT0 == 0L) {
                if (now >= planeNext) {
                    planeT0 = now
                    planeDir = if (rnd.nextBoolean()) 1 else -1
                    Sfx.planePass()
                } else {
                    postInvalidateDelayed(max(16L, min(500L, planeNext - now)))
                }
            }
            if (planeT0 != 0L) {
                val p = (now - planeT0) / PLANE_MS
                if (p >= 1f) {
                    planeT0 = 0L
                    planeNext = now + 3500L + rnd.nextInt(3500)
                } else {
                    drawPlaneInPill(canvas, p, w, h, u)
                    needFrames = true
                }
            }
        }

        // kedip
        if (blinkStart >= 0L) {
            val p = (now - blinkStart) / 170f
            if (p >= 1f) {
                blinkStart = -1L
            } else {
                open *= max(0.06f, abs(1f - 2f * p))
                needFrames = true
            }
        }

        // haluskan pose: perubahan mendadak (ganti aksi) jadi meluncur, getaran cepat tetap terasa
        if (!smoothInit) {
            sDx = dx; sDy = dy; sScale = scale; sTiltL = tiltL; sTiltR = tiltR
            smoothInit = true
        }
        val ks = min(1f, dt * 22f)
        sDx += (dx - sDx) * ks
        sDy += (dy - sDy) * ks
        sScale += (scale - sScale) * ks
        sTiltL += (tiltL - sTiltL) * ks
        sTiltR += (tiltR - sTiltR) * ks
        if (abs(dx - sDx) > 0.3f || abs(dy - sDy) > 0.3f || abs(scale - sScale) > 0.005f) needFrames = true
        dx = sDx; dy = sDy; scale = sScale; tiltL = sTiltL; tiltR = sTiltR

        sideAmount += (side - sideAmount) * min(1f, dt * 14f)
        if (abs(side - sideAmount) > 0.01f) needFrames = true
        val cx = w * (0.5f - 0.14f * sideAmount)
        val sc = scale * (1f + 0.12f * br)
        val ew = u * 0.20f * sc
        val eh = u * 0.46f * sc
        val gap = u * 0.55f
        val cy = h / 2f + dy
        val lx = cx - gap + dx
        val rx = cx + gap + dx
        val eyesOn = offAmt < 0.5f
        if (eyesOn && roamVis > 0.02f) drawBatt(canvas, w, h, now)
        if (eyesOn) {
            drawEye(canvas, lookL, lx, cy + dyL, color, ew * scaleL, eh * scaleL, open * openL, true, tiltL, br, spin)
            drawEye(canvas, lookR, rx, cy + dyR, color, ew * scaleR, eh * scaleR, open * openR, false, tiltR, br, spin)
        }

        if (tear && eyesOn) {
            val p = (t * 0.7f) % 1f
            fill.color = fa(Color.rgb(155, 239, 255), 1f - p)
            canvas.drawOval(
                lx - u * 0.12f - u * 0.05f, cy + eh * 0.35f + p * u * 0.3f - u * 0.075f,
                lx - u * 0.12f + u * 0.05f, cy + eh * 0.35f + p * u * 0.3f + u * 0.075f, fill
            )
            needFrames = true
        }

        if (eyesOn) for (i in icons) drawIcon(canvas, i, w, h, t, u)

        if (label != null && eyesOn) {
            textPaint.textSize = u * 0.42f
            textPaint.color = if (labelColor != 0) labelColor else color
            drawCentered(canvas, label, w * labelX, h / 2f)
        }

        if (flash > 0f) {
            fill.color = Color.argb((flash * 235f).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawRect(0f, 0f, w, h, fill)
            needFrames = true
        }
        canvas.restore()

        if (act != Act.IDLE || fish.vis > 0.01f || fish.active || fish.drop != null) needFrames = true
        if (needFrames) postInvalidateOnAnimation()
    }

    private fun drawBatt(c: Canvas, w: Float, h: Float, now: Long) {
        val lv = roamBat / 100f
        val low = roamBat <= 15f
        val col = if (low) RED else if (roamBat <= 40f) ORANGE else GREEN
        val a = min(1f, roamVis * 1.5f) * (if (low) 0.55f + 0.45f * sin(now / 160f) else 1f)
        val bx = w * 0.07f
        val by = h / 2f
        val k = h / 32f
        stroke.color = fa(col, 0.95f * a); stroke.strokeWidth = max(1f, 1.3f * k)
        rect.set(bx, by - 5.4f * k, bx + 19f * k, by + 5.4f * k)
        c.drawRoundRect(rect, 2.4f * k, 2.4f * k, stroke)
        fill.color = fa(col, 0.95f * a)
        rect.set(bx + 20f * k, by - 2.2f * k, bx + 22.5f * k, by + 2.2f * k)
        c.drawRoundRect(rect, 1f * k, 1f * k, fill)
        rect.set(bx + 2.4f * k, by - 3.1f * k, bx + 2.4f * k + max(1.2f, 14.2f * lv * k), by + 3.1f * k)
        c.drawRoundRect(rect, 1.4f * k, 1.4f * k, fill)
        textPaint.textSize = 11.5f * k
        textPaint.color = fa(col, 0.98f * a)
        textPaint.textAlign = Paint.Align.LEFT
        val fm = textPaint.fontMetrics
        c.drawText(Math.round(roamBat).toString() + "%", bx + 26f * k, by - (fm.ascent + fm.descent) / 2f, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
    }

    // ---------- pesawat ----------

    private fun drawPlane(c: Canvas, x: Float, y: Float, s: Float, dir: Int, col: Int, alpha: Float) {
        c.save()
        c.translate(x, y)
        c.scale(dir.toFloat(), 1f)
        fill.color = fa(col, alpha)
        rect.set(-s, -s * 0.17f, s, s * 0.17f)
        c.drawOval(rect, fill)
        for (m in intArrayOf(1, -1)) {
            val mf = m.toFloat()
            path.reset()
            path.moveTo(s * 0.18f, 0f); path.lineTo(-s * 0.32f, mf * s * 0.95f)
            path.lineTo(-s * 0.56f, mf * s * 0.95f); path.lineTo(-s * 0.24f, 0f); path.close()
            c.drawPath(path, fill)
            path.reset()
            path.moveTo(-s * 0.68f, 0f); path.lineTo(-s * 0.92f, mf * s * 0.4f)
            path.lineTo(-s * 1.04f, mf * s * 0.4f); path.lineTo(-s * 0.9f, 0f); path.close()
            c.drawPath(path, fill)
        }
        c.restore()
    }

    private fun drawPlaneInPill(c: Canvas, p: Float, w: Float, h: Float, u: Float) {
        val s = u * 0.36f
        val span = w + s * 4f
        val x = if (planeDir > 0) -s * 2f + p * span else w + s * 2f - p * span
        val y = h * 0.5f + sin(p * TWO_PI * 0.8f) * h * 0.06f
        for (i in 0 until 10) {
            val bx = x - planeDir * (s * 1.4f + i * s * 0.55f)
            if (bx < 0f || bx > w) continue
            fill.color = fa(Color.rgb(225, 238, 250), 0.26f * (1f - i / 10f))
            c.drawCircle(bx, y, s * 0.1f * (1f - i * 0.05f), fill)
        }
        drawPlane(c, x, y, s, planeDir, Color.rgb(225, 238, 250), 0.5f)
    }

    // ---------- mancing ----------

    private fun drawFishBody(c: Canvas, x: Float, y: Float, len: Float, ang: Float, tier: Int, alpha: Float, wig: Float) {
        val col = FishModel.kinds[tier].col
        c.save()
        c.translate(x, y)
        c.rotate(ang * 180f / PI.toFloat())
        val tw = sin(wig) * len * 0.22f
        fill.color = fa(mix(col, Color.BLACK, 0.25f), alpha)
        path.reset()
        path.moveTo(-len * 0.8f, 0f); path.lineTo(-len * 1.55f, -len * 0.5f + tw)
        path.lineTo(-len * 1.4f, tw * 0.6f); path.lineTo(-len * 1.55f, len * 0.5f + tw); path.close()
        c.drawPath(path, fill)
        path.reset()
        path.moveTo(-len * 0.2f, -len * 0.32f)
        path.lineTo(len * 0.1f, -len * (if (tier == 4) 1.0f else 0.62f))
        path.lineTo(len * 0.35f, -len * 0.32f); path.close()
        c.drawPath(path, fill)
        fill.color = fa(col, alpha)
        rect.set(-len, -len * 0.38f, len, len * 0.38f)
        c.drawOval(rect, fill)
        fill.color = fa(Color.WHITE, alpha * 0.28f)
        rect.set(-len * 0.85f, len * 0.14f - len * 0.18f, len * 0.85f, len * 0.14f + len * 0.18f)
        c.drawOval(rect, fill)
        fill.color = fa(Color.rgb(15, 22, 30), alpha)
        c.drawCircle(len * 0.58f, -len * 0.08f, max(0.7f, len * 0.08f), fill)
        c.restore()
    }

    private fun drawHook(c: Canvas, x: Float, y: Float, alpha: Float) {
        stroke.color = fa(Color.rgb(225, 238, 248), alpha)
        stroke.strokeWidth = 0.9f
        path.reset()
        path.moveTo(x, y - 1f); path.lineTo(x, y + 3f)
        rect.set(x - 4.4f, y + 0.8f, x, y + 5.2f)
        path.arcTo(rect, 0f, 170f)
        c.drawPath(path, stroke)
    }

    private fun drawFishScene(c: Canvas, now: Long, w: Float, u: Float, k: Float, ax: Float) {
        val f = fish
        val A = f.vis * 0.6f
        c.save()
        c.translate(0f, u - FishModel.PILL_BOTTOM * k)
        c.scale(k, k)
        val px = 0f
        val py = FishModel.PY
        val pw = w / k
        val ph = FishModel.PH
        val surf = FishModel.SURF
        // panel (transparan supaya video di belakangnya masih terlihat)
        c.save()
        path.reset()
        rect.set(px, py, px + pw, py + ph)
        path.addRoundRect(rect, 9f, 9f, Path.Direction.CW)
        c.clipPath(path)
        fill.shader = LinearGradient(0f, py, 0f, surf, fa(Color.rgb(27, 53, 88), A), fa(Color.rgb(74, 130, 174), A), Shader.TileMode.CLAMP)
        c.drawRect(px, py, px + pw, surf + 2f, fill)
        fill.shader = LinearGradient(0f, surf, 0f, py + ph, fa(Color.rgb(31, 120, 180), A), fa(Color.rgb(8, 38, 68), A), Shader.TileMode.CLAMP)
        c.drawRect(px, surf, px + pw, py + ph, fill)
        fill.shader = null
        fill.color = fa(Color.rgb(255, 232, 160), A * 0.9f)
        c.drawCircle(px + pw - 28f, py + 10f, 5f, fill)
        for (i in 0 until 3) {
            fill.color = Color.argb((255 * A * (0.26f - i * 0.05f)).toInt().coerceIn(0, 255), 120 + i * 30, 200 + i * 15, 255)
            path.reset()
            path.moveTo(px, py + ph)
            var x = px
            while (x <= px + pw + 4f) {
                path.lineTo(x, surf + i * 3f + sin(x * 0.05f * (1f + i * 0.3f) + now * 0.0016f * (i + 1) + i * 2f) * (1.8f - i * 0.4f))
                x += 4f
            }
            path.lineTo(px + pw, py + ph); path.close()
            c.drawPath(path, fill)
        }
        for (i in 0 until 6) {
            val gx = px + ((i * 47f + now * 0.012f * (1 + (i % 2))) % pw)
            val gl = 0.5f + 0.5f * sin(now * 0.003f + i * 2f)
            fill.color = fa(Color.WHITE, A * 0.7f * gl)
            c.drawRect(gx, surf + 1f + (i % 3) * 2f, gx + 6f, surf + 1.9f + (i % 3) * 2f, fill)
        }
        fill.color = fa(Color.WHITE, A * 0.25f)
        for (i in 0 until 5) {
            val ph2 = ((now * 0.00025f * (1f + i * 0.2f)) + i * 0.37f) % 1f
            c.drawCircle(px + 20f + i * 52f + sin(ph2 * 9f + i) * 4f, py + ph - ph2 * (ph - 12f), 1.1f + (i % 2) * 0.5f, fill)
        }
        for (s in f.swimmers) {
            drawFishBody(c, s.x, s.y, FishModel.kinds[s.tier].len * 0.8f, if (s.dir > 0) 0f else PI.toFloat(), s.tier, A * 0.5f, now * 0.012f + s.x * 0.2f)
        }
        if (f.active && f.state == FishModel.WAIT) {
            drawFishBody(c, f.targetX, f.targetY, FishModel.kinds[f.tier].len, if (f.targetDir > 0) 0f else PI.toFloat(), f.tier, min(1f, A * 1.4f), now * 0.012f)
        }
        if (f.active && f.state == FishModel.BITE) {
            drawFishBody(
                c, f.hookX - f.targetDir * FishModel.kinds[f.tier].len * 0.9f, f.hookY + 1f, FishModel.kinds[f.tier].len,
                if (f.targetDir > 0) 0f else PI.toFloat(), f.tier, min(1f, A * 1.4f), now * 0.05f
            )
        }
        stroke.strokeWidth = 0.7f
        for (r in f.ripples) {
            val kk = (now - r.t0) / 1400f
            stroke.color = fa(Color.WHITE, A * 0.8f * (1f - kk))
            rect.set(r.x - (4f + kk * 22f), surf + 1f - (1.2f + kk * 3.2f), r.x + (4f + kk * 22f), surf + 1f + (1.2f + kk * 3.2f))
            c.drawOval(rect, stroke)
        }
        // penanda "video laut"
        fill.color = fa(Color.WHITE, min(1f, A * 1.4f))
        path.reset()
        path.moveTo(px + 8f, py + 5f); path.lineTo(px + 8f, py + 12f); path.lineTo(px + 14f, py + 8.5f); path.close()
        c.drawPath(path, fill)
        textPaint.textSize = 7f
        textPaint.color = fa(Color.WHITE, min(1f, A * 1.4f))
        textPaint.textAlign = Paint.Align.LEFT
        c.drawText("Video laut", px + 18f, py + 11f, textPaint)
        c.drawText("Putus ${f.lost}", px + 8f, py + ph - 5f, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        c.drawText("Level air ${f.level + 1}", px + pw - 8f, py + ph - 5f, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
        c.restore()

        // tali, kail, ikan
        val line = Color.rgb(225, 238, 248)
        if (f.active) {
            val t = (now - f.sT0) / 1000f
            val st = f.state
            if (st == FishModel.SNAP && f.snap != null) {
                val s = f.snap!!
                stroke.color = fa(line, 0.9f); stroke.strokeWidth = 0.8f
                path.reset(); path.moveTo(ax, FishModel.PILL_BOTTOM)
                path.quadTo(ax - 3f, (FishModel.PILL_BOTTOM + s.up) / 2f, ax - 6f + sin(t * 6f) * 2f, s.up)
                c.drawPath(path, stroke)
                c.drawLine(s.hx, s.hy, s.hx + 2f, s.hy - 6f, stroke)
                drawHook(c, s.hx, s.hy, 1f)
                drawFishBody(c, s.fx, s.fy, FishModel.kinds[s.tier].len, PI.toFloat() + (if (s.fvx > 0f) 0.3f else -0.3f), s.tier, (1f - t / 2.4f).coerceIn(0.2f, 1f), now * 0.03f)
                if (t < 0.35f) {
                    stroke.color = fa(YELLOW, 1f - t / 0.35f)
                    for (n in 0 until 5) {
                        val an = n * TWO_PI / 5f + 0.3f
                        val r1 = 3f + t * 14f
                        val r2 = r1 + 4f
                        c.drawLine(s.hx + cos(an) * r1, s.hy + sin(an) * r1, s.hx + cos(an) * r2, s.hy + sin(an) * r2, stroke)
                    }
                }
            } else {
                val lc = mix(line, RED, if (st == FishModel.REEL) ((f.tension - 0.5f) * 2f).coerceIn(0f, 1f) else 0f)
                stroke.color = fa(lc, 0.9f); stroke.strokeWidth = 0.8f
                path.reset()
                path.moveTo(ax, FishModel.PILL_BOTTOM)
                if (st == FishModel.WAIT || st == FishModel.BITE) {
                    val dip = if (st == FishModel.BITE) 3f + sin(t * 24f) * 1.6f else sin(now * 0.002f) * 0.5f
                    path.quadTo((ax + f.hookX) / 2f, max(FishModel.PILL_BOTTOM, surf - 16f) + 6f, f.hookX, surf + dip - 2f)
                    c.drawPath(path, stroke)
                    stroke.strokeWidth = 0.5f
                    c.drawLine(f.hookX, surf + dip, f.hookX, f.hookY - 1f, stroke)
                    rect.set(f.hookX - 2.4f, surf + dip - 5f, f.hookX + 2.4f, surf + dip - 0.2f)
                    fill.color = RED
                    c.drawArc(rect, 180f, 180f, true, fill)
                    fill.color = Color.WHITE
                    c.drawArc(rect, 0f, 180f, true, fill)
                } else {
                    val sag = if (st == FishModel.CAST) 8f * (1f - (t / 1.1f).coerceIn(0f, 1f)) else if (st == FishModel.SHOW) 2f else 3f * (1f - f.tension)
                    path.quadTo((ax + f.hookX) / 2f, (FishModel.PILL_BOTTOM + f.hookY) / 2f + sag, f.hookX, f.hookY - 1f)
                    c.drawPath(path, stroke)
                }
                drawHook(c, f.hookX, f.hookY, 1f)
                if (st == FishModel.REEL || st == FishModel.SHOW) {
                    val fl = FishModel.kinds[f.tier].len
                    val struggle = if (st == FishModel.REEL) 0.15f + f.tension * 0.45f else 0.12f
                    drawFishBody(c, f.hookX, f.hookY + fl * 1.05f, fl, -PI.toFloat() / 2f + sin(now * 0.02f * (1f + f.tier * 0.2f)) * struggle, f.tier, 1f, now * 0.03f)
                }
            }
        }
        val d = f.drop
        if (d != null) {
            drawFishBody(c, d.x, d.y, FishModel.kinds[d.tier].len, PI.toFloat() / 2f + sin(now * 0.02f) * 0.3f, d.tier, 1f, now * 0.03f)
        }
        c.restore()
    }

    // ---------- mata ----------

    private fun glow(c: Canvas, color: Int, sw: Float, br: Float) {
        val layers = 3 + (br * 3f).toInt()
        for (k in layers downTo 1) {
            stroke.color = fa(color, 0.09f + 0.04f * br)
            stroke.strokeWidth = sw + sw * 0.45f * k * (1f + br * 0.5f)
            c.drawPath(path, stroke)
        }
        stroke.color = color
        stroke.strokeWidth = sw
        c.drawPath(path, stroke)
    }

    private fun drawEye(
        c: Canvas, look: Look, x: Float, y: Float, color0: Int, ew: Float, eh: Float,
        open: Float, left: Boolean, tilt: Float, br: Float, spin: Float
    ) {
        c.save()
        c.translate(x, y)
        if (tilt != 0f) c.rotate(tilt * 180f / PI.toFloat())
        val color = if (br > 0f) mix(color0, Color.WHITE, br * 0.75f) else color0
        when (look) {
            Look.BAR -> {
                val hh = eh * open
                var bw = ew
                var bh = hh
                var rad = min(ew / 2f, hh / 2f)
                if (shapeIdx == 1) { bw = ew * 1.25f; bh = hh * 0.85f; rad = ew * 0.28f }
                else if (shapeIdx == 2) { bw = ew * 1.8f; bh = max(1f, ew * 1.8f * open); rad = bw / 2f }
                for (k in 3 + (br * 3f).toInt() downTo 1) {
                    fill.color = fa(color, 0.09f + 0.04f * br)
                    val g = ew * 0.22f * k * (1f + br * 0.5f)
                    rect.set(-bw / 2f - g, -bh / 2f - g, bw / 2f + g, bh / 2f + g)
                    c.drawRoundRect(rect, rad + g, rad + g, fill)
                }
                fill.color = color
                rect.set(-bw / 2f, -bh / 2f, bw / 2f, bh / 2f)
                c.drawRoundRect(rect, rad, rad, fill)
            }

            Look.ARC -> {
                val rad = eh * 0.52f
                rect.set(-rad, rad * 0.5f - rad, rad, rad * 0.5f + rad)
                path.reset()
                path.arcTo(rect, 200f, 140f)
                glow(c, color, ew * 0.95f, br)
            }

            Look.SLANT -> {
                val half = ew * 1.35f
                val rise = eh * 0.22f
                val sx = if (left) -1f else 1f
                path.reset(); path.moveTo(sx * half, rise); path.lineTo(-sx * half, -rise)
                glow(c, color, ew * 0.95f, br)
            }

            Look.CHEV -> {
                val s = eh * 0.38f
                val d = if (left) 1f else -1f
                path.reset(); path.moveTo(-d * s, -s); path.lineTo(d * s * 0.7f, 0f); path.lineTo(-d * s, s)
                glow(c, color, ew * 0.9f, br)
            }

            Look.ANGRY -> {
                val half = ew * 1.5f
                val rise = eh * 0.2f
                path.reset()
                if (left) { path.moveTo(-half, -rise); path.lineTo(half, rise) }
                else { path.moveTo(half, -rise); path.lineTo(-half, rise) }
                glow(c, color, ew * 1.05f, br)
            }

            Look.SQUINT -> {
                path.reset(); path.moveTo(-ew * 1.5f, 0f); path.lineTo(ew * 1.5f, 0f)
                glow(c, color, eh * 0.14f, br)
            }

            Look.SPIRAL -> {
                val r = eh * 0.5f
                val turns = TWO_PI * 2.2f
                val dir = if (left) 1f else -1f
                path.reset()
                var a = 0f
                var first = true
                while (a <= turns) {
                    val rr = r * (a / turns)
                    val px = cos(a * dir + spin * 6f * dir) * rr
                    val py = sin(a * dir + spin * 6f * dir) * rr
                    if (first) { path.moveTo(px, py); first = false } else path.lineTo(px, py)
                    a += 0.25f
                }
                glow(c, color, ew * 0.5f, br)
            }

            Look.CAMERA -> drawCamera(c, eh * 1.1f)

            Look.HEART -> {
                heartPath(eh * 1.0f)
                fill.color = fa(color, .2f); c.drawPath(path, fill)
                heartPath(eh * .78f)
                fill.color = color; c.drawPath(path, fill)
            }

            Look.STAR -> {
                c.save()
                c.rotate(spin * 360f)
                starPath(eh * .8f)
                fill.color = fa(color, .2f); c.drawPath(path, fill)
                starPath(eh * .6f)
                fill.color = color; c.drawPath(path, fill)
                c.restore()
            }
        }
        if (br > 0.15f) {
            stroke.color = fa(Color.WHITE, 0.55f * br)
            stroke.strokeWidth = 0.8f
            val l = eh * 0.9f * br
            c.drawLine(-l, 0f, l, 0f, stroke)
            c.drawLine(0f, -l * 0.7f, 0f, l * 0.7f, stroke)
        }
        c.restore()
    }

    private fun heartPath(s: Float) {
        path.reset()
        path.moveTo(0f, s * .35f)
        path.cubicTo(-s * .95f, -s * .15f, -s * .5f, -s * .85f, 0f, -s * .3f)
        path.cubicTo(s * .5f, -s * .85f, s * .95f, -s * .15f, 0f, s * .35f)
    }

    private fun starPath(s: Float) {
        path.reset()
        for (i in 0 until 10) {
            val r = if (i % 2 == 1) s * 0.42f else s
            val a = -PI.toFloat() / 2f + i * PI.toFloat() / 5f
            if (i == 0) path.moveTo(cos(a) * r, sin(a) * r) else path.lineTo(cos(a) * r, sin(a) * r)
        }
        path.close()
    }

    private fun drawCamera(c: Canvas, s: Float) {
        fill.color = Color.rgb(232, 238, 244)
        rect.set(-s * 0.5f, -s * 0.3f, s * 0.5f, s * 0.32f)
        c.drawRoundRect(rect, s * 0.1f, s * 0.1f, fill)
        rect.set(-s * 0.22f, -s * 0.44f, s * 0.08f, -s * 0.26f)
        c.drawRoundRect(rect, s * 0.05f, s * 0.05f, fill)
        fill.color = Color.rgb(40, 52, 66)
        c.drawCircle(0f, 0.02f * s, s * 0.22f, fill)
        fill.color = CYAN
        c.drawCircle(0f, 0.02f * s, s * 0.12f, fill)
        fill.color = fa(Color.WHITE, 0.9f)
        c.drawCircle(-s * 0.05f, -s * 0.04f, s * 0.04f, fill)
    }

    // ---------- ikon ----------

    private fun poly(vararg p: Float, s: Float) {
        path.reset()
        var i = 0
        while (i < p.size) {
            if (i == 0) path.moveTo(p[i] * s, p[i + 1] * s) else path.lineTo(p[i] * s, p[i + 1] * s)
            i += 2
        }
        path.close()
    }

    private fun drawIcon(c: Canvas, ic: Ic, w: Float, h: Float, t: Float, u: Float) {
        val s = ic.s
        if (s <= 0.01f) return
        val x = ic.x * w
        val y = ic.y * h + (if (ic.wob) sin(t * 5f) * 1.4f else 0f)
        c.save()
        c.translate(x, y)
        if (ic.rot != 0f) c.rotate(ic.rot * 180f / PI.toFloat())
        val col = fa(ic.col, ic.a.coerceIn(0f, 1f))
        fill.color = col
        stroke.color = col
        when (ic.k) {
            "note" -> {
                c.save(); c.rotate(-20f)
                rect.set(-s * 0.28f, s * 0.15f, s * 0.28f, s * 0.55f); c.drawOval(rect, fill)
                c.restore()
                stroke.strokeWidth = s * 0.11f
                path.reset(); path.moveTo(s * 0.24f, s * 0.3f); path.lineTo(s * 0.24f, -s * 0.5f)
                path.quadTo(s * 0.3f, -s * 0.2f, s * 0.58f, -s * 0.18f)
                c.drawPath(path, stroke)
            }
            "zed" -> {
                stroke.strokeWidth = s * 0.2f
                path.reset(); path.moveTo(-s * 0.4f, -s * 0.4f); path.lineTo(s * 0.4f, -s * 0.4f)
                path.lineTo(-s * 0.4f, s * 0.4f); path.lineTo(s * 0.4f, s * 0.4f)
                c.drawPath(path, stroke)
            }
            "spark" -> {
                poly(0f, -1f, .22f, -.22f, 1f, 0f, .22f, .22f, 0f, 1f, -.22f, .22f, -1f, 0f, -.22f, -.22f, s = s)
                c.drawPath(path, fill)
            }
            "star" -> {
                path.reset()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 1) s * 0.42f else s
                    val a = -PI.toFloat() / 2f + i * PI.toFloat() / 5f
                    if (i == 0) path.moveTo(cos(a) * r, sin(a) * r) else path.lineTo(cos(a) * r, sin(a) * r)
                }
                path.close(); c.drawPath(path, fill)
            }
            "question" -> {
                stroke.strokeWidth = s * 0.2f
                rect.set(-s * 0.3f, -s * 0.55f, s * 0.3f, s * 0.05f)
                path.reset(); path.arcTo(rect, 180f, 279f, true); path.lineTo(0f, s * 0.2f)
                c.drawPath(path, stroke)
                c.drawCircle(0f, s * 0.5f, s * 0.11f, fill)
            }
            "exclaim" -> {
                stroke.strokeWidth = s * 0.26f
                c.drawLine(0f, -s * 0.6f, 0f, s * 0.1f, stroke)
                c.drawCircle(0f, s * 0.46f, s * 0.14f, fill)
            }
            "bolt" -> {
                poly(.15f, -.75f, -.35f, .1f, -.02f, .1f, -.15f, .75f, .35f, -.15f, .02f, -.15f, s = s)
                c.drawPath(path, fill)
            }
            "battery" -> {
                stroke.strokeWidth = s * 0.1f; stroke.color = Color.rgb(220, 230, 240)
                rect.set(-s * 0.5f, -s * 0.28f, s * 0.5f, s * 0.28f); c.drawRoundRect(rect, s * 0.1f, s * 0.1f, stroke)
                fill.color = Color.rgb(220, 230, 240)
                c.drawRect(s * 0.52f, -s * 0.12f, s * 0.62f, s * 0.12f, fill)
                fill.color = col
                c.drawRect(-s * 0.4f, -s * 0.18f, -s * 0.4f + s * 0.8f * (if (ic.lvl > 0f) ic.lvl else 0.2f), s * 0.18f, fill)
            }
            "anger" -> {
                stroke.strokeWidth = s * 0.17f
                for (n in 0 until 4) {
                    c.rotate(90f)
                    rect.set(s * 0.06f, s * 0.06f, s * 0.74f, s * 0.74f)
                    c.drawArc(rect, 180f, 90f, false, stroke)
                }
            }
            "thermo" -> {
                val lv = ic.lvl.coerceIn(0f, 1f)
                stroke.strokeWidth = s * 0.1f; stroke.color = Color.rgb(225, 235, 245)
                rect.set(-s * 0.13f, -s * 0.72f, s * 0.13f, s * 0.23f); c.drawRoundRect(rect, s * 0.13f, s * 0.13f, stroke)
                c.drawCircle(0f, s * 0.5f, s * 0.26f, stroke)
                fill.color = RED
                c.drawCircle(0f, s * 0.5f, s * 0.19f, fill)
                val top = s * 0.4f + (-s * 0.6f - s * 0.4f) * lv
                rect.set(-s * 0.055f, top, s * 0.055f, s * 0.5f); c.drawRoundRect(rect, s * 0.05f, s * 0.05f, fill)
            }
            "fan" -> {
                stroke.strokeWidth = s * 0.07f; stroke.color = fa(ICE, 0.6f)
                c.drawCircle(0f, 0f, s * 0.7f, stroke)
                fill.color = fa(ICE, 0.9f)
                for (n in 0 until 3) {
                    val a = ic.spin + n * TWO_PI / 3f
                    c.save()
                    c.translate(cos(a) * s * 0.32f, sin(a) * s * 0.32f)
                    c.rotate(a * 180f / PI.toFloat())
                    rect.set(-s * 0.3f, -s * 0.13f, s * 0.3f, s * 0.13f); c.drawOval(rect, fill)
                    c.restore()
                }
                fill.color = Color.WHITE
                c.drawCircle(0f, 0f, s * 0.11f, fill)
            }
            "arrow" -> {
                stroke.strokeWidth = s * 0.2f
                c.drawLine(-s * 0.55f, 0f, s * 0.5f, 0f, stroke)
                path.reset(); path.moveTo(s * 0.12f, -s * 0.42f); path.lineTo(s * 0.62f, 0f); path.lineTo(s * 0.12f, s * 0.42f)
                c.drawPath(path, stroke)
            }
            "cw" -> {
                stroke.strokeWidth = s * 0.2f
                rect.set(-s * 0.5f, -s * 0.5f, s * 0.5f, s * 0.5f)
                c.drawArc(rect, -144f, 243f, false, stroke)
                c.save(); c.rotate(99f); c.translate(s * 0.5f, 0f)
                path.reset(); path.moveTo(-s * 0.3f, s * 0.05f); path.lineTo(0f, s * 0.4f); path.lineTo(s * 0.3f, s * 0.05f)
                c.drawPath(path, stroke)
                c.restore()
            }
            "headphone" -> {
                val gp = u * 0.55f
                stroke.strokeWidth = 2.6f * density; stroke.color = Color.rgb(225, 235, 245)
                val half = gp + u * 0.88f
                rect.set(-half, -u * 0.32f, half, u * 0.52f)
                c.drawArc(rect, 180f, 180f, false, stroke)
                fill.color = Color.rgb(225, 235, 245)
                for (px in floatArrayOf(-half, half)) {
                    rect.set(px - 3.6f * density, -u * 0.22f, px + 3.6f * density, u * 0.28f)
                    c.drawRoundRect(rect, 3.4f * density, 3.4f * density, fill)
                }
                fill.color = CYAN
                for (px in floatArrayOf(-half, half)) c.drawRect(px - density, -u * 0.06f, px + density, u * 0.12f, fill)
            }
            "speaker" -> {
                poly(-.5f, -.2f, -.2f, -.2f, .15f, -.5f, .15f, .5f, -.2f, .2f, -.5f, .2f, s = s)
                c.drawPath(path, fill)
                stroke.strokeWidth = s * 0.12f
                for (n in 1..ic.lvl.toInt()) {
                    val rr = s * (.25f + .22f * n)
                    rect.set(s * .15f - rr, -rr, s * .15f + rr, rr)
                    c.drawArc(rect, -52f, 104f, false, stroke)
                }
            }
            "wifi" -> {
                stroke.strokeWidth = s * 0.14f
                for (n in 1..3) {
                    val rr = s * .38f * n
                    rect.set(-rr, s * .5f - rr, rr, s * .5f + rr)
                    c.drawArc(rect, -135f, 90f, false, stroke)
                }
                c.drawCircle(0f, s * .5f, s * .09f, fill)
                if (ic.off) {
                    stroke.color = RED; stroke.strokeWidth = s * .17f
                    c.drawLine(-s * .75f, -s * .6f, s * .75f, s * .7f, stroke)
                }
            }
            "crescent" -> {
                path.reset(); path.addCircle(0f, 0f, s, Path.Direction.CW)
                val cut = Path(); cut.addCircle(s * .4f, -s * .1f, s * .82f, Path.Direction.CW)
                path.op(cut, Path.Op.DIFFERENCE)
                c.drawPath(path, fill)
            }
            "tomato" -> {
                fill.color = Color.rgb(255, 92, 80)
                c.drawCircle(0f, s * .1f, s * .7f, fill)
                fill.color = GREEN
                for (n in 0 until 3) {
                    c.save(); c.rotate(-52f + n * 52f)
                    rect.set(-s * .12f, -s * .9f, s * .12f, -s * .34f); c.drawOval(rect, fill)
                    c.restore()
                }
            }
            "blush" -> {
                rect.set(-s * .6f, -s * .32f, s * .6f, s * .32f); c.drawOval(rect, fill)
            }
            "drop" -> {
                path.reset()
                path.moveTo(0f, -s * .55f)
                path.cubicTo(s * .5f, -s * .05f, s * .4f, s * .5f, 0f, s * .5f)
                path.cubicTo(-s * .4f, s * .5f, -s * .5f, -s * .05f, 0f, -s * .55f)
                path.close(); c.drawPath(path, fill)
            }
            "dots" -> {
                for (i in 0 until 3) {
                    val al = (.25f + .75f * max(0f, sin(t * 5f - i * 1.1f))).coerceIn(0f, 1f)
                    fill.color = fa(ic.col, ic.a * al)
                    c.drawCircle((i - 1) * s * .5f, 0f, s * .14f, fill)
                }
            }
            "puff" -> {
                for (i in 0 until 3) {
                    c.drawCircle((i - 1) * s * .28f, if (i == 1) -s * .12f else 0f, s * (if (i == 1) .3f else .22f), fill)
                }
            }
            "bulb" -> {
                c.drawCircle(0f, -s * .12f, s * .36f, fill)
                rect.set(-s * .18f, s * .2f, s * .18f, s * .4f); c.drawRoundRect(rect, s * .05f, s * .05f, fill)
                stroke.strokeWidth = s * .09f
                for (n in 0 until 5) {
                    val a = -PI.toFloat() * (0.17f + n * 0.165f)
                    c.drawLine(cos(a) * s * .55f, sin(a) * s * .55f - s * .12f, cos(a) * s * .8f, sin(a) * s * .8f - s * .12f, stroke)
                }
            }
            "heart" -> {
                path.reset()
                path.moveTo(0f, s * .35f)
                path.cubicTo(-s * .95f, -s * .15f, -s * .5f, -s * .85f, 0f, -s * .3f)
                path.cubicTo(s * .5f, -s * .85f, s * .95f, -s * .15f, 0f, s * .35f)
                c.drawPath(path, fill)
            }
            "sun" -> {
                c.drawCircle(0f, 0f, s * .5f, fill)
                stroke.strokeWidth = s * .14f
                for (n in 0 until 8) {
                    c.save(); c.rotate(n * 45f)
                    c.drawLine(s * .72f, 0f, s * 1.0f, 0f, stroke)
                    c.restore()
                }
            }
            "cup" -> {
                fill.color = fa(ic.col, .9f)
                rect.set(-s * .45f, -s * .1f, s * .25f, s * .5f); c.drawRoundRect(rect, s * .1f, s * .1f, fill)
                stroke.strokeWidth = s * .12f
                rect.set(s * .15f, -s * .02f, s * .55f, s * .38f); c.drawArc(rect, -90f, 180f, false, stroke)
                stroke.color = fa(ICE, .7f); stroke.strokeWidth = s * .08f
                for (n in 0 until 2) {
                    path.reset()
                    path.moveTo(-s * .2f + n * s * .3f, -s * .25f)
                    path.quadTo(-s * .1f + n * s * .3f + sin(t * 4f + n) * s * .1f, -s * .45f, -s * .2f + n * s * .3f, -s * .65f)
                    c.drawPath(path, stroke)
                }
            }
            "bug" -> {
                rect.set(-s * .55f, -s * .38f, s * .55f, s * .38f); c.drawOval(rect, fill)
                c.drawCircle(s * .6f, 0f, s * .22f, fill)
                stroke.strokeWidth = s * .1f
                for (n in 0 until 3) {
                    val o = (n - 1) * s * .28f
                    val w2 = sin(ic.spin * 30f + n * 2f) * s * .12f
                    c.drawLine(o, -s * .3f, o + w2, -s * .7f, stroke)
                    c.drawLine(o, s * .3f, o - w2, s * .7f, stroke)
                }
            }
            "ball" -> {
                c.drawCircle(0f, 0f, s, fill)
                fill.color = fa(Color.WHITE, .55f)
                c.drawCircle(-s * .35f, -s * .35f, s * .25f, fill)
            }
            "paperball" -> {
                c.drawCircle(0f, 0f, s, fill)
                stroke.color = Color.rgb(120, 130, 145); stroke.strokeWidth = s * .14f
                path.reset(); path.moveTo(-s * .5f, -s * .2f); path.lineTo(s * .1f, s * .1f); path.lineTo(-s * .1f, s * .55f)
                c.drawPath(path, stroke)
            }
            "bin" -> {
                stroke.strokeWidth = s * .12f
                path.reset(); path.moveTo(-s * .6f, -s * .5f); path.lineTo(-s * .42f, s * .6f); path.lineTo(s * .42f, s * .6f); path.lineTo(s * .6f, -s * .5f)
                c.drawPath(path, stroke)
                c.drawLine(-s * .75f, -s * .5f, s * .75f, -s * .5f, stroke)
            }
            "rock" -> {
                c.drawCircle(0f, s * .1f, s * .62f, fill)
                stroke.color = Color.rgb(20, 30, 40); stroke.strokeWidth = s * .09f
                for (xx in floatArrayOf(-.28f, 0f, .28f)) c.drawLine(s * xx, -s * .3f, s * xx, s * .05f, stroke)
            }
            "paper" -> {
                rect.set(-s * .5f, -s * .62f, s * .5f, s * .62f); c.drawRoundRect(rect, s * .12f, s * .12f, fill)
                stroke.color = Color.rgb(20, 30, 40); stroke.strokeWidth = s * .09f
                for (yy in floatArrayOf(-.3f, 0f, .3f)) c.drawLine(-s * .28f, s * yy, s * .28f, s * yy, stroke)
            }
            "scissors" -> {
                stroke.strokeWidth = s * .16f
                c.drawLine(-s * .38f, s * .25f, s * .42f, -s * .65f, stroke)
                c.drawLine(s * .38f, s * .25f, -s * .42f, -s * .65f, stroke)
                stroke.strokeWidth = s * .12f
                c.drawCircle(-s * .4f, s * .42f, s * .22f, stroke)
                c.drawCircle(s * .4f, s * .42f, s * .22f, stroke)
            }
            "tension" -> {
                val lv = ic.lvl.coerceIn(0f, 1f)
                stroke.strokeWidth = s * 0.1f; stroke.color = Color.rgb(225, 235, 245)
                rect.set(-s * 0.16f, -s * 0.5f, s * 0.16f, s * 0.5f); c.drawRoundRect(rect, s * 0.1f, s * 0.1f, stroke)
                fill.color = mix(GREEN, RED, lv)
                rect.set(-s * 0.09f, s * 0.43f - s * 0.86f * lv, s * 0.09f, s * 0.43f)
                c.drawRoundRect(rect, s * 0.05f, s * 0.05f, fill)
            }
        }
        c.restore()
    }

    private fun drawCentered(c: Canvas, s: String, x: Float, y: Float) {
        val fm = textPaint.fontMetrics
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    companion object {
        private const val PLANE_MS = 3400f
        private val TWO_PI = (2.0 * PI).toFloat()
        private val CYAN = Color.rgb(56, 232, 255)
        private val SAD_BLUE = Color.rgb(90, 168, 255)
        private val GREEN = Color.rgb(61, 255, 139)
        private val ORANGE = Color.rgb(255, 159, 28)
        private val RED = Color.rgb(255, 82, 82)
        private val YELLOW = Color.rgb(255, 214, 64)
        private val ICE = Color.rgb(140, 215, 255)
        private val PINK = Color.rgb(255, 120, 200)
    }
}
